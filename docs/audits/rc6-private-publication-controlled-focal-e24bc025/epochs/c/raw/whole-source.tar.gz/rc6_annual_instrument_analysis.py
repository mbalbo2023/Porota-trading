"""Lectura anual de performance desde el histórico canónico; solo lectura."""
from __future__ import annotations

import html
import math
import os
import sqlite3
from contextlib import closing
from datetime import date, datetime, time
from pathlib import Path
from statistics import pstdev
from urllib.parse import quote
from zoneinfo import ZoneInfo

import iol_shadow_observation_rc6 as iol_shadow_observation
from cg_paper_workspace import database_path
import er_dashboard_truth_projection_rc6 as truth_projection

TZ = ZoneInfo("America/Argentina/Buenos_Aires")
TABLE = "history_canonical_v2"


def _e(value) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def _history_uri() -> str:
    path = Path(os.getenv("HIST_DB_PATH", "data/market_history.db")).expanduser().resolve()
    return "file:" + quote(str(path), safe="/") + "?mode=ro"


def _connect():
    return _copied_connection(Path(os.getenv("HIST_DB_PATH", "data/market_history.db")))


class _CopiedConnection:
    def __init__(self, context):
        self.context = context
        self.connection = context.__enter__()

    def execute(self, *args, **kwargs):
        return self.connection.execute(*args, **kwargs)

    def close(self):
        if self.context is not None:
            self.context.__exit__(None, None, None)
            self.context = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


def _copied_connection(path):
    from rc6_audit_evidence.sqlite_snapshot import readonly_copy
    from bs_instrument_contracts import register_exact_time_sql
    from time import monotonic
    result = _CopiedConnection(readonly_copy(path.expanduser(), deadline=monotonic() + 1., validate=False))
    register_exact_time_sql(result.connection)
    return result


def _runtime_connect():
    path = Path(database_path()).expanduser().resolve()
    return _copied_connection(path)


def _runtime_rows(sql, params=()):
    try:
        with closing(_runtime_connect()) as connection:
            return [dict(row) for row in connection.execute(sql, params).fetchall()]
    except (sqlite3.Error, OSError, ValueError):
        return []


def _runtime_table(name):
    try:
        with closing(_runtime_connect()) as connection:
            return bool(connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
            ).fetchone())
    except (sqlite3.Error, OSError, ValueError):
        return False


def _catalog():
    with closing(_connect()) as connection:
        tables = {row[0] for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        if TABLE not in tables:
            return []
        return [dict(row) for row in connection.execute(
            f"""SELECT DISTINCT UPPER(instrument_type) AS family, symbol, market, currency, settlement, price_basis
                FROM {TABLE}
                WHERE TRIM(COALESCE(instrument_type,''))<>'' AND TRIM(COALESCE(symbol,''))<>''
                ORDER BY family, symbol, market, currency, settlement, price_basis LIMIT 100""")]


def _families():
    """Read only distinct historical families for the first selector."""
    with closing(_connect()) as connection:
        if not connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (TABLE,)
        ).fetchone():
            return []
        return [
            str(row["family"])
            for row in connection.execute(
                f"""SELECT DISTINCT UPPER(instrument_type) AS family
                    FROM {TABLE}
                    WHERE TRIM(COALESCE(instrument_type,''))<>''
                    ORDER BY family"""
            )
            if row["family"]
        ]


def _identities_for_family(family):
    """Read selector identities for one family only; never materialize all history identities."""
    family=str(family or "").strip().upper()
    if not family:
        return []
    with closing(_connect()) as connection:
        if not connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (TABLE,)
        ).fetchone():
            return []
        return [
            (str(row["symbol"]), str(row["market"]), str(row["currency"]), str(row["settlement"]), str(row["price_basis"]), str(row["adjustment_basis"]))
            for row in connection.execute(
                f"""SELECT DISTINCT symbol,market,settlement,currency,price_basis,adjustment_basis
                    FROM {TABLE}
                    WHERE UPPER(instrument_type)=?
                      AND TRIM(COALESCE(symbol,''))<>''
                    ORDER BY symbol,market,currency,settlement,price_basis,adjustment_basis LIMIT 500""",
                (family,),
            )
        ]


def _identity(value):
    parts = str(value or "").split("|")
    if len(parts) != 7 or not all(parts):
        return None
    return tuple(part.strip() for part in parts)


def _is_on_family(value):
    return str(value or "").strip().upper() in {
        "ON", "OBLIGACIONES", "OBLIGACIONES_NEGOCIABLES",
    }


def _is_fixed_income_family(value):
    return str(value or "").strip().upper() in {
        "BONOS", "BONO", "LETRAS", "LETRA", "TITULOS_PUBLICOS", "ON",
        "OBLIGACIONES", "OBLIGACIONES_NEGOCIABLES",
    }


def _bars(identity, cutoff):
    from rc6_trader_dashboard.history import causal_history_sql
    if len(identity) != 7:
        raise ValueError("ANNUAL_FULL_IDENTITY_AND_BASIS_REQUIRED")
    family, symbol, market, currency, settlement, price_basis, adjustment_basis = identity
    if price_basis == "UNKNOWN_ADJUSTED" or adjustment_basis == "UNKNOWN":
        raise ValueError("ANNUAL_PRICE_ADJUSTMENT_BASIS_UNVERIFIED")
    known_cutoff = (cutoff if isinstance(cutoff, datetime) else datetime.combine(cutoff, time.max, TZ))
    with _connect() as connection:
        cte, args = causal_history_sql(connection.connection, known_cutoff,
            dict(family=family, symbol=symbol, market=market, currency=currency, settlement=settlement,
                 price_basis=price_basis, adjustment_basis=adjustment_basis))
        checks = {"version_id", "last_checked_at"} <= {row["name"] for row in connection.execute("PRAGMA table_info(history_checks_v2)")}
        checked = "CASE WHEN rc6_instant_us(c.last_checked_at)<=rc6_instant_us(?) THEN c.last_checked_at END" if checks else "NULL"
        join = " LEFT JOIN history_checks_v2 c ON c.version_id=h.id" if checks else ""
        rows = [dict(row) for row in connection.execute(cte + f"""SELECT date,open,high,low,close,volume,source,adjusted,
                 currency,price_basis,adjustment_basis,provider_at,observed_at,version_known_at,h.id version_id,
                 {checked} last_checked_at FROM causal_history h{join} ORDER BY date LIMIT 5001""",
                 (*args, *((known_cutoff.isoformat(),) if checks else ())))]
        if len(rows) > 5000:
            raise ValueError("ANNUAL_BAR_ROW_BUDGET_EXHAUSTED")
        return rows


def _number(value):
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def _price(value):
    number = _number(value)
    if number is None:
        return "—"
    return f"{number:,.4f}".replace(",", "_").replace(".", ",").replace("_", ".")


def _pct(value):
    return "—" if value is None else f"{value * 100:+.2f}%".replace(".", ",")


def _count(value):
    try:
        return f"{int(value or 0):,}".replace(",", ".")
    except (TypeError, ValueError, OverflowError):
        return "—"


def _sma(values, count):
    subset = values[-count:]
    return sum(subset) / count if len(subset) == count else None


def _period_return(values, sessions):
    if len(values) <= sessions or values[-sessions - 1] <= 0:
        return None
    return values[-1] / values[-sessions - 1] - 1


def _ema(values, period):
    if len(values) < period:
        return None
    result = sum(values[:period]) / period
    alpha = 2 / (period + 1)
    for value in values[period:]:
        result = alpha * value + (1 - alpha) * result
    return result


def _rsi(values, period=14):
    if len(values) <= period:
        return None
    changes = [values[i] - values[i - 1] for i in range(len(values) - period, len(values))]
    gains = [max(0.0, value) for value in changes]
    losses = [max(0.0, -value) for value in changes]
    avg_gain, avg_loss = sum(gains) / period, sum(losses) / period
    if avg_loss == 0:
        return 100.0 if avg_gain else 50.0
    return 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)


def _atr(rows, period=14):
    ranges = []
    prior_close = None
    for row in rows:
        high, low, close = (_number(row.get(key)) for key in ("high", "low", "close"))
        if high is None or low is None or close is None or high < low:
            prior_close = close
            continue
        true_range = high - low
        if prior_close is not None:
            true_range = max(true_range, abs(high - prior_close), abs(low - prior_close))
        ranges.append(true_range)
        prior_close = close
    return sum(ranges[-period:]) / period if len(ranges) >= period else None


def _metric(label, value, detail=""):
    return ("<article class='paper-card'><h2>" + _e(label) + "</h2><p class='analysis-value'>" +
            _e(value) + "</p>" + (f"<p class='paper-muted'>{_e(detail)}</p>" if detail else "") + "</article>")


def _render_report(identity, bars, year):
    if len(identity) == 7:
        family, symbol, market, currency, settlement, price_basis, adjustment_basis = identity
    elif len(identity) == 6:
        family, symbol, market, currency, settlement, price_basis = identity
    else:
        # Pure legacy diagnostic calls remain readable, but never pretend the
        # old four-part key has a verified currency or comparable price basis.
        family, symbol, market, settlement = identity
        currency = price_basis = "NO_VERIFICADO"
    valid = [(row, _number(row.get("close"))) for row in bars]
    valid = [(row, close) for row, close in valid if close is not None and close > 0]
    if not valid:
        return ("<div class='paper-warning'><b>Sin cierres válidos</b> para esta identidad en el histórico canónico.</div>"
                "<p class='paper-muted'>No se generan precios ni indicadores sintéticos.</p>")
    rows, closes = [item[0] for item in valid], [item[1] for item in valid]
    latest = rows[-1]
    current_year = [i for i, row in enumerate(rows) if str(row.get("date", ""))[:4] == str(year)]
    if not current_year:
        return ("<div class='paper-warning'><b>No hay barras del año calendario "
                + _e(year) + "</b> para este papel.</div>"
                "<p class='paper-muted'>El selector refleja solo series presentes en el almacén canónico v2.</p>")
    first_i, last_i = current_year[0], current_year[-1]
    base_i = first_i - 1 if first_i > 0 else None
    base_close = closes[base_i] if base_i is not None else closes[first_i]
    annual_return = closes[last_i] / base_close - 1 if base_close else None
    year_returns = []
    for i in range(max(1, first_i), last_i + 1):
        if closes[i - 1] > 0:
            year_returns.append(closes[i] / closes[i - 1] - 1)
    volatility = pstdev(year_returns) * math.sqrt(252) if len(year_returns) >= 2 else None
    peak = base_close
    max_drawdown = 0.0
    for close in closes[first_i:last_i + 1]:
        peak = max(peak, close)
        if peak > 0:
            max_drawdown = min(max_drawdown, close / peak - 1)
    analysis_closes = closes[:last_i + 1]
    sma_values = {period: _sma(analysis_closes, period) for period in (20, 50, 200)}
    momentum_values = {sessions: _period_return(analysis_closes, sessions)
                       for sessions in (20, 60, 120, 252)}
    ema12, ema26 = _ema(analysis_closes, 12), _ema(analysis_closes, 26)
    macd = ema12 - ema26 if ema12 is not None and ema26 is not None else None
    is_spot_equity = family in {"ACCIONES", "CEDEARS"}
    latest_close = analysis_closes[-1]
    if is_spot_equity and sma_values[20] is not None and sma_values[50] is not None:
        trend_state = ("Tendencia técnica favorable" if latest_close > sma_values[20] > sma_values[50]
                       else "Tendencia técnica débil" if latest_close < sma_values[20] < sma_values[50]
                       else "Tendencia mixta")
        signal_state = ("No se emite compra/venta: la regla anual aún no tiene validación walk-forward. "
                        "Usar como contexto, no como instrucción operativa.")
    elif is_spot_equity:
        trend_state = "Sin señal de tendencia: faltan barras para medias 20/50"
        signal_state = "Sin sugerencia: cobertura insuficiente para evaluar la tendencia."
    else:
        trend_state = "No aplicable sin valoración propia de la familia"
        signal_state = ("No se emite compra/venta: precio aislado no modela cupón, amortización, "
                        "vencimiento, moneda, crédito ni rendimiento.")
    recent = rows[max(0, last_i - 251):last_i + 1]
    highs = [_number(row.get("high")) for row in recent]
    lows = [_number(row.get("low")) for row in recent]
    highs = [value for value in highs if value is not None]
    lows = [value for value in lows if value is not None]
    adjusted = {row.get("adjusted") for row in rows[first_i:last_i + 1]}
    adjustment = "Ajustado por proveedor" if adjusted == {1} else (
        "Sin ajustar" if adjusted == {0} else "Ajuste mixto o desconocido")
    full_ohlc = sum(1 for row in rows[first_i:last_i + 1]
                    if all(_number(row.get(key)) is not None for key in ("open", "high", "low", "close")))
    sources = sorted({str(row.get("source") or "UNKNOWN") for row in rows[first_i:last_i + 1]})
    base_label = "cierre previo al año" if base_i is not None else "primera barra disponible (serie parcial)"
    end_date = str(latest.get("date") or "—")
    series_first = str(rows[first_i].get("date") or "—")
    high_text = _price(max(highs)) if highs else "—"
    low_text = _price(min(lows)) if lows else "—"
    metrics = [
        _metric(f"Variación de precio {year} (sin flujos)", _pct(annual_return),
                f"Base: {base_label}; último cierre: {end_date}"
                + ("; excluye cupones, amortizaciones, interés corrido y reinversión" if _is_fixed_income_family(family) else "")),
        *([_metric("Retorno total / TIR / interés corrido", "NO_VERIFICADO",
                   "Exige cashflows contractuales efectivos, base limpia/sucia, day-count y reinversión conocidos.")]
          if _is_fixed_income_family(family) else []),
        _metric("Máxima caída del año", _pct(max_drawdown), "Drawdown calculado con cierres diarios desde el máximo acumulado."),
        _metric("Volatilidad realizada anualizada", _pct(volatility), "Desviación de retornos diarios × √252; requiere al menos 2 retornos."),
        _metric("RSI (14)", "—" if _rsi(analysis_closes) is None else _price(_rsi(analysis_closes)), "Promedio simple de ganancias y pérdidas de las últimas 14 ruedas; contextual, no calibrado como gatillo."),
        _metric("Momentum 20 / 60 / 120 / 252 ruedas",
                " / ".join(_pct(momentum_values[n]) for n in (20, 60, 120, 252)),
                "Retorno del cierre actual frente al cierre de N ruedas atrás; si falta historial se muestra —."),
        _metric("MACD (12,26)", _price(macd),
                "Diferencia EMA12−EMA26 sobre cierres diarios; no es señal de compra/venta calibrada."),
        _metric("Lectura de tendencia", trend_state,
                "Regla descriptiva sobre cierre y SMA20/SMA50; no altera el motor operativo."),
        _metric("Sugerencia compra/venta", "No emitida",
                signal_state),
        _metric("ATR (14)", _price(_atr(rows[:last_i + 1])), "Solo se calcula si hay 14 rangos verdaderos con OHLC válido."),
        _metric("Media móvil 20 ruedas", _price(sma_values[20])),
        _metric("Media móvil 50 ruedas", _price(sma_values[50])),
        _metric("Media móvil 200 ruedas", _price(sma_values[200])),
        _metric("Máximo / mínimo 252 barras", f"{high_text} / {low_text}", "Ventana máxima disponible; no representa necesariamente 12 meses completos."),
        _metric("Último cierre", _price(closes[last_i]), f"Fecha: {end_date}"),
    ]
    partial = base_i is None
    note = ("Serie anual parcial: no había cierre previo al 1 de enero." if base_i is None else
            "La variación usa el cierre anterior al primer día del año cuando está disponible.")
    return (
        f"<h2>{_e(symbol)} — {_e(family)}</h2>"
        f"<p class='paper-muted'>Mercado {_e(market)} · Moneda {_e(currency)} · Liquidación {_e(settlement)} · Base {_e(price_basis)} · "
        f"Serie {_e(series_first)} a {_e(end_date)}</p>"
        + ("<div class='paper-warning'><b>" + _e(note) + "</b></div>" if partial else "")
        + "<div class='analysis-grid'>" + "".join(metrics) + "</div>"
        + "<div class='paper-card'><h2>Cobertura y procedencia</h2><p>"
        + f"<b>Barras del año:</b> {last_i - first_i + 1} · <b>OHLC completo:</b> {full_ohlc} · "
        + f"<b>Ajuste:</b> {_e(adjustment)} · <b>Fuentes:</b> {_e(', '.join(sources))}</p>"
        + f"<p class='paper-muted'>Fuente conceptual: history_canonical_v2 · fecha de barra {_e(end_date)} · "
        f"versión conocida {_e(latest.get('version_known_at') or 'NO_VERIFICADO')} · observación de versión "
        f"{_e(latest.get('observed_at') or 'NO_VERIFICADO')} · último chequeo {_e(latest.get('last_checked_at') or 'NO_VERIFICADO')}. "
        "No se mezclan identidad, moneda ni base. Este histórico no prueba el input que usó el motor: "
        "cotización actual = market_snapshots; decisión = decision_evidence_snapshots al decision_at; "
        "ejecución PAPER = fill/lifecycle ledger al filled_at, cada uno con fuente y corte propios.</p></div>"
        + ("<div class='paper-warning'><b>Para renta fija, esta variación de precio no es rendimiento total.</b> "
           "No incorpora cupones cobrados, amortizaciones, interés corrido, ni reinversión de flujos; "
           "la performance económica requiere reconstruir el flujo real del bono y normalizar precio limpio/sucio.</div>"
           if _is_fixed_income_family(family) else "")
        + ("<div class='paper-card'><h2>Validación de Obligaciones Negociables</h2>"
           "<p>La coincidencia de precio entre PPI e IOL sirve para detectar discrepancias, pero no basta para habilitar operatoria. "
           "Antes hacen falta identidad exacta (símbolo, mercado, moneda y liquidación), nominal/unidad de cotización, "
           "valor residual, cupón, calendario de pagos, amortización, vencimiento, convención de rendimiento, "
           "precio limpio/sucio y datos de crédito cuando se calcule rendimiento a vencimiento.</p>"
           "<p class='paper-muted'>La serie de precios de este informe no contiene necesariamente esos términos. "
           "Si falta un dato contractual esencial, el rendimiento/riesgo y la señal se abstienen; se requiere "
           "además un ejecutor especializado y gates de riesgo antes de cualquier operación.</p></div>"
           if _is_on_family(family) else "")
        + "<div class='paper-notice'>Informe histórico informativo. No habilita operatoria, no altera READY/HOLD, "
        "señales, tamaño, gates ni órdenes. Si faltan datos, el indicador se marca como no disponible.</div>"
    )



def _evidence_tone(state):
    state = str(state or "UNKNOWN").upper()
    if state == "READY_SHADOW":
        return "green"
    if state in {"READY_SHADOW_COMPLEMENTED", "READY_SHADOW_PARTIAL", "INSUFFICIENT_EVIDENCE"}:
        return "yellow"
    if state.startswith("BLOCKED"):
        return "red"
    return "gray"


def _evidence_label(state):
    return {
        "READY_SHADOW": "LISTO EN SHADOW",
        "READY_SHADOW_COMPLEMENTED": "SHADOW + COMPLEMENTO IOL",
        "READY_SHADOW_PARTIAL": "SHADOW PARCIAL",
        "BLOCKED_STALE": "BLOQUEADO · DATOS VENCIDOS",
        "BLOCKED_CONFLICT": "BLOQUEADO · CONFLICTO",
        "INSUFFICIENT_EVIDENCE": "EVIDENCIA INSUFICIENTE",
        "UNKNOWN": "SIN EVIDENCIA",
    }.get(str(state or "UNKNOWN").upper(), str(state or "SIN EVIDENCIA").upper())


def _render_reconciliation_evidence(truth=None):
    """Show current IOL/cache and caucion state without redefining readiness."""
    truth = truth or truth_projection.build(_runtime_rows, _runtime_table)
    iol = truth["iol"]
    quote = iol["quotes"]
    family = iol["families"]
    section_rows = "".join(
        "<tr>"
        f"<td><b>{_e(name)}</b></td><td>{_e(item.get('state'))}</td>"
        f"<td>{_e(item.get('raw_source_state'))}</td><td>{_e(item.get('as_of') or '—')}</td>"
        "</tr>"
        for name, item in family.get("sections", {}).items()
    ) or "<tr><td colspan='4'>Sin secciones publicadas; SOURCE_UNAVAILABLE.</td></tr>"
    caucion = truth["caucion"]
    return (
        "<section class='paper-card'><h2>Salud actual de IOL</h2>"
        "<p class='paper-muted'>IOL complementa a PPI. Una falla se limita a la sección afectada; "
        "un cache válido conserva su estado y nunca se presenta como IOL=0.</p>"
        "<div class='analysis-grid'>"
        + _metric("Cotizaciones IOL", quote.get("state"),
                  f"{quote.get('total', 0)} filas · {quote.get('states', {})}")
        + _metric("Familias IOL", family.get("state"),
                  f"LKG {family.get('last_known_good_at') or 'no publicado'}")
        + "</div><table><thead><tr><th>Sección</th><th>Estado visible</th>"
        "<th>Estado de la fuente</th><th>Actualizado</th></tr></thead><tbody>"
        + section_rows + "</tbody></table>"
        "<h3>Caución colocadora PAPER</h3>"
        f"<p><b>Ledger:</b> {_e(caucion.get('ledger_state'))} · "
        f"<b>Fuente:</b> {_e((caucion.get('iol_source') or {}).get('state'))} · "
        f"<b>Último resultado:</b> {_e(caucion.get('allocation_status'))} · "
        f"<b>Motivo HOLD:</b> {_e(caucion.get('hold_reason'))}.</p>"
        "<p class='paper-muted'>La garantía no es un requisito genérico de una colocadora PAPER. "
        "Se muestran únicamente ledger, fuente, asignación y evidencia persistida.</p></section>"
    )


def _family_tone(state):
    return {"READY": "green", "PARTIAL": "yellow", "PENDING": "yellow",
            "BLOCKED": "red"}.get(str(state or "PENDING").upper(), "gray")


def _render_family_readiness(catalog=None, truth=None):
    """Readiness comes only from candidate_identity_v2; catalog/history stay separate."""
    del catalog
    truth = truth or truth_projection.build(_runtime_rows, _runtime_table)
    readiness = truth["readiness"]
    rows = "".join(
        "<tr>"
        f"<td><b>{_e(item.get('family'))}</b></td>"
        f"<td>{_e(item.get('state'))}</td>"
        f"<td>{_count(item.get('runtime_ready'))}/{_count(item.get('candidate_total'))}</td>"
        f"<td>{_count(item.get('catalog_available'))}/{_count(item.get('catalog_total'))}</td>"
        f"<td>{_count(item.get('paused_explicit'))}</td>"
        f"<td>{_e(item.get('readiness_as_of') or '—')}</td>"
        "</tr>"
        for item in readiness.get("families", [])
    ) or "<tr><td colspan='6'>candidate_identity_v2 no está disponible; estado NO_VERIFICADO.</td></tr>"
    strategy = truth["strategy_eligibility"]
    return (
        "<section class='paper-card'><h2>Readiness runtime por familia</h2>"
        f"<p><b>Total READY:</b> {_count(readiness.get('ready'))}/{_count(readiness.get('total'))} · "
        f"<b>Fuente única:</b> candidate_identity_v2 · <b>as of:</b> {_e(readiness.get('as_of') or '—')}.</p>"
        "<p class='paper-muted'>El catálogo histórico de esta pantalla sólo alimenta el selector de series. "
        "No habilita ni deshabilita instrumentos. CONTRACT_READY, RUNTIME_READY y STRATEGY_ELIGIBLE "
        "son etapas distintas.</p>"
        "<table><thead><tr><th>Familia</th><th>Estado</th><th>RUNTIME_READY</th>"
        "<th>Catálogo disponible</th><th>PAUSED_EXPLICIT</th><th>Actualizado</th></tr></thead><tbody>"
        + rows + "</tbody></table>"
        f"<p class='paper-notice'><b>STRATEGY_ELIGIBLE:</b> {_e(strategy.get('state'))}; "
        f"{_e(strategy.get('detail'))} Evaluaciones de hoy: {_e(strategy.get('evaluated_today'))}.</p>"
        "</section>"
    )

def render_page(family="", instrument=""):
    year = datetime.now(TZ).year
    try:
        families = _families()
    except (sqlite3.Error, OSError, ValueError):
        return ("<h1>Análisis anual</h1><div class='paper-warning'><b>Histórico no disponible para lectura.</b> "
                "La pantalla no crea ni repara la base. Revisar ruta/esquema mediante el procedimiento del repositorio.</div>")
    family = str(family or "").strip().upper()
    if family not in families:
        family = ""
    try:
        identities = _identities_for_family(family)
    except (sqlite3.Error, OSError, ValueError):
        identities = []
    wanted = _identity(instrument)
    if wanted and wanted[0].upper() != family:
        wanted = None
    if wanted and wanted[1:] not in identities:
        wanted = None
    family_options = "".join(
        f"<option value='{_e(value)}'{' selected' if value == family else ''}>{_e(value)}</option>"
        for value in families)
    instrument_options = "".join(
        f"<option value='{_e('|'.join((family, symbol, market, currency, settlement, basis, adjustment)))}' "
        f"{'selected' if wanted == (family, symbol, market, currency, settlement, basis, adjustment) else ''}>"
        f"{_e(symbol)} · {_e(market)} · {_e(currency)} · {_e(settlement)} · {_e(basis)} · {_e(adjustment)}</option>"
        for symbol, market, currency, settlement, basis, adjustment in identities)
    form = (
        "<form method='get' action='/analisis' class='paper-card analysis-form'>"
        "<label for='analysis-family'><b>Tipo de instrumento</b></label>"
        f"<select id='analysis-family' name='family' required onchange=\"this.form.elements.instrument.value='';this.form.submit()\">"
        f"<option value=''>Seleccionar tipo</option>{family_options}</select>"
        "<label for='analysis-instrument'><b>Papel</b></label>"
        f"<select id='analysis-instrument' name='instrument' required>"
        f"<option value=''>Seleccionar papel</option>{instrument_options}</select>"
        "<button class='paper-action' type='submit'>Generar informe</button></form>"
        "<p class='paper-notice'>El catálogo del selector se deriva de identidades con barras canónicas; "
        "no representa instrumentos habilitados para operar.</p>"
    )
    report = ""
    if wanted:
        try:
            bars = _bars(wanted, datetime.now(TZ))
            report = _render_report(wanted, bars, year)
        except (sqlite3.Error, OSError, ValueError):
            report = "<div class='paper-warning'><b>No se pudo leer la serie seleccionada.</b> No se modificó el histórico.</div>"
    elif not families:
        report = ("<div class='paper-warning'><b>Sin series canónicas disponibles.</b> "
                  "No se generará un informe a partir de datos ausentes.</div>")
    runtime_truth = truth_projection.build(_runtime_rows, _runtime_table)
    return (
        "<h1>Análisis</h1><p class='paper-muted'>Variación histórica de precios del año calendario "
        + str(year) + " por identidad y base, usando histórico canónico v2; no equivale a retorno total.</p>"
        + form + _render_family_readiness(truth=runtime_truth)
        + _render_reconciliation_evidence(runtime_truth) + report
    )
