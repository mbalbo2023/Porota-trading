"""Reloj de salidas PAPER sin red ni IA; intención persistente separada del fill."""
import json
import os
from dataclasses import dataclass
from decimal import Decimal

from bs_instrument_contracts import aware_datetime, decimal_value, utc_microseconds

EXIT_SUPERVISOR_HEALTHY_RUNTIME_STATES = frozenset({"RUNNING"})


def init_schema(store):
    with store.connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS paper_exit_intents(
          paper_id TEXT PRIMARY KEY REFERENCES paper_positions(paper_id),
          state TEXT NOT NULL, cause TEXT, due_at TEXT, blocked_reason TEXT NOT NULL,
          supervised_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS paper_future_exit_intents(
          lifecycle_id TEXT PRIMARY KEY REFERENCES paper_future_positions(lifecycle_id),
          state TEXT NOT NULL, cause TEXT, due_at TEXT, blocked_reason TEXT NOT NULL,
          supervised_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS paper_supervisor_state(
          id INTEGER PRIMARY KEY CHECK(id=1), heartbeat_at TEXT NOT NULL,
          state TEXT NOT NULL, detail TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS paper_exit_reader_state(
          id INTEGER PRIMARY KEY CHECK(id=1), heartbeat_at TEXT NOT NULL,
          state TEXT NOT NULL, detail TEXT NOT NULL);
        """)


def admission_error(store, at, max_silence_seconds=20):
    with store.connect() as c:
        health = c.execute("SELECT * FROM paper_supervisor_state WHERE id=1").fetchone()
        if not health or health["state"] != "RUNNING":
            return "EXIT_SUPERVISOR_UNAVAILABLE"
        try:
            age = (utc_microseconds(at) - utc_microseconds(health["heartbeat_at"])) / 1_000_000
            if not 0 <= age <= max_silence_seconds:
                return "EXIT_SUPERVISOR_STALE"
        except (ValueError, TypeError):
            return "EXIT_SUPERVISOR_INVALID_CLOCK"
        reader = c.execute("SELECT * FROM paper_exit_reader_state WHERE id=1").fetchone()
        if not reader or reader["state"] != "READY":
            return "EXIT_READER_UNAVAILABLE"
        try:
            age = (utc_microseconds(at) - utc_microseconds(reader["heartbeat_at"])) / 1_000_000
            if not 0 <= age <= max_silence_seconds:
                return "EXIT_READER_STALE"
        except (ValueError, TypeError):
            return "EXIT_READER_INVALID_CLOCK"
        if c.execute("""SELECT 1 FROM paper_positions p LEFT JOIN paper_exit_intents x USING(paper_id)
          WHERE p.status='OPEN' AND (x.state IS NULL OR x.state<>'OPEN') LIMIT 1""").fetchone():
            return "OPEN_POSITION_NEEDS_SUPERVISION_OR_EXIT"
        if c.execute("""SELECT 1 FROM paper_future_positions p
          LEFT JOIN paper_future_exit_intents x USING(lifecycle_id)
          WHERE p.status='ACTIVE' AND (x.state IS NULL OR x.state<>'OPEN') LIMIT 1""").fetchone():
            return "OPEN_FUTURE_NEEDS_SUPERVISION_OR_EXIT"
    return ""


@dataclass(frozen=True)
class Verdict:
    paper_id: str
    state: str
    cause: str | None
    reason: str


class PositionExitSupervisor:
    def __init__(self, broker, *, clock_fn, session_policy=None, max_hold_minutes=180,
                 close_fn=None, telemetry=None):
        self.broker, self.store = broker, broker.store
        self.clock_fn, self.session_policy = clock_fn, session_policy
        if max_hold_minutes <= 0:
            raise ValueError("Permanencia máxima debe ser positiva")
        self.max_hold_minutes = max_hold_minutes
        self.close_fn = close_fn or broker._close
        self.telemetry = telemetry

    def _probe(self, paper_id, stage, at, cause):
        if self.telemetry is not None:
            try:
                self.telemetry.record(paper_id, stage, at, cause)
            except Exception:
                # Diagnostics cannot veto an exit or become a simulated fill.
                import logging
                logging.getLogger(__name__).warning("EXIT_TELEMETRY_DROPPED:stage=%s", stage)

    def heartbeat(self, at, state="RUNNING", detail=""):
        with self.store.connect() as c:
            c.execute("INSERT OR REPLACE INTO paper_supervisor_state VALUES(1,?,?,?)", (at,state,detail))

    def _persist(self, p, verdict, at, attempted=False):
        with self.store.connect() as c:
            c.execute("BEGIN IMMEDIATE")
            actual = c.execute("SELECT status FROM paper_positions WHERE paper_id=?", (p["paper_id"],)).fetchone()
            if not actual:
                return Verdict(p["paper_id"], "WATCH_POSITION_MISSING", verdict.cause,
                               "La posición desapareció antes de conciliar el fill")
            if actual[0] == "CLOSED":
                return Verdict(p["paper_id"], "CLOSED", verdict.cause, "Fill ya registrado")
            if actual[0] != "OPEN":
                verdict = Verdict(p["paper_id"],"WATCH_INVALID_LEDGER",verdict.cause,
                                  "Estado de posición no reconocido; requiere conciliación")
            previous = c.execute("SELECT * FROM paper_exit_intents WHERE paper_id=?", (p["paper_id"],)).fetchone()
            due = previous["due_at"] if previous else None
            cause = (previous["cause"] if previous else None) or verdict.cause
            c.execute("""INSERT INTO paper_exit_intents VALUES(?,?,?,?,?,?,?)
              ON CONFLICT(paper_id) DO UPDATE SET state=excluded.state,cause=excluded.cause,
              due_at=excluded.due_at,blocked_reason=excluded.blocked_reason,
              supervised_at=excluded.supervised_at,attempts=excluded.attempts""",
              (p["paper_id"],verdict.state,cause,due or (at if cause else None),verdict.reason,at,
               (previous["attempts"] if previous else 0) + int(attempted)))
            if not previous or (previous["state"],previous["cause"]) != (verdict.state,cause):
                c.execute("INSERT INTO paper_events VALUES(NULL,?,?,?,?,?)",
                          (at,"PRODUCTION_PAPER","PAPER_EXIT_STATE",p["paper_id"],
                           f"{verdict.state}; {cause or 'NONE'}; {verdict.reason}"))
        if cause and not (previous and previous["cause"]):
            self._probe(p["paper_id"], "INTENT_COMMITTED", self.clock_fn(), cause)
        return Verdict(p['paper_id'],verdict.state,cause,verdict.reason)

    def supervise(self, p, q, at):
        with self.store.connect() as c:
            previous = c.execute("SELECT * FROM paper_exit_intents WHERE paper_id=?", (p["paper_id"],)).fetchone()
        cause = previous["cause"] if previous else None
        def verdict(state, reason):
            if cause and not (previous and previous["cause"]):
                self._probe(p["paper_id"], "CONDITION", self.clock_fn(), cause)
            return self._persist(p, Verdict(p["paper_id"],state,cause,reason), at)
        try:
            age = (utc_microseconds(at) - utc_microseconds(p["opened_at"])) / 60_000_000
            if age < 0:
                return verdict("WATCH_INVALID_CLOCK", "Apertura posterior al reloj")
            if not cause and self.session_policy and self.session_policy.exit_due(p, at):
                # EOD seguro por defecto: el motor queda flat al cierre.
                # CARRY_ELIGIBLE es opt-in y no se activa en este deploy:
                # solo conserva acciones/CEDEARs para una validacion posterior
                # con cotizacion fresca, identidad consistente y riesgo vigente.
                eod_policy = os.getenv("PAPER_EOD_POLICY", "FORCE_CLOSE").upper()
                asset_class = str(p.get("asset_class") or "").upper()
                carry_eligible = (
                    eod_policy == "CARRY_ELIGIBLE"
                    and asset_class in {"ACCIONES", "CEDEARS", "EQUITIES", "CEDEAR"}
                )
                if not carry_eligible:
                    cause = "EOD_PAPER"
            hold_limit = self.max_hold_minutes
            is_scalping = False
            try:
                features = json.loads(p.get("features_json") or "{}")
                is_scalping = features.get("execution_style") == "SCALPING_PAPER"
                if is_scalping:
                    hold_limit = min(hold_limit, int(features.get("scalping_max_hold_minutes") or
                                      os.getenv("PAPER_SCALPING_MAX_HOLD_MINUTES", "30")))
            except (ValueError, TypeError, AttributeError):
                hold_limit = self.max_hold_minutes
            if not cause and age >= hold_limit:
                cause = "SCALPING_MAX_HOLD_PAPER" if is_scalping else "MAX_HOLD_PAPER"
        except (ValueError, TypeError):
            return verdict("WATCH_INVALID_CLOCK", "Fecha de apertura inválida")
        prefix = "EXIT_PENDING_" if cause else "WATCH_"
        if self.session_policy:
            error = self.session_policy.execution_error(p, at)
            if error:
                return verdict(prefix + "MARKET_CLOSED", error)
        if q is None:
            return verdict(prefix + "NO_QUOTE", "Sin libro del instrumento")
        try:
            identity = q.monetary_identity()
        except (ValueError, TypeError):
            return verdict(prefix + "IDENTITY_MISMATCH", "Moneda o mercado sin confirmar")
        try:
            if ((q.symbol,q.asset_class,q.settlement,*identity) !=
                    tuple(p[k] for k in ("symbol","asset_class","settlement","currency","market"))):
                return verdict(prefix + "IDENTITY_MISMATCH", "Libro incompatible con el fill original")
            error = q.time_error(at, max_age_seconds=self.broker.quote_max_age_seconds)
            if error:
                return verdict(prefix + "STALE_QUOTE", error)
            if utc_microseconds(q.book_at) < utc_microseconds(p["opened_at"]):
                return verdict(prefix + "STALE_QUOTE", "Libro anterior a la apertura")
            bid = decimal_value(q.bid, "bid", positive=True)
            ask = decimal_value(q.ask, "ask", positive=True)
            size = decimal_value(q.bid_size, "bid_size", nonnegative=True)
            if ask < bid:
                return verdict(prefix + "INVALID_BOOK", "Libro cruzado")
        except (ValueError, TypeError):
            return verdict(prefix + "NO_LIQUIDITY", "Puntas inválidas o sin precio")
        # El stop puede dispararse con precio y cantidad cero: decide salir y
        # conserva la intención; la ejecución todavía exige profundidad.
        # Take Profit shadow: evalúa neto/costos/impuesto configurado sin
        # cambiar el disparador vigente ni cerrar por sí mismo.
        if not cause and bid >= Decimal(p["target_price"]):
            try:
                import rc6_cost_settlement_takeprofit_shadow as shadow_costs
                features = json.loads(p.get("features_json") or "{}")
                factor = Decimal(str(features.get("contract_cash_multiplier", "1")))
                diagnostic = shadow_costs.net_take_profit(
                    p["entry_price"], bid, p["quantity"], factor,
                    p["entry_cost"], "0")
                self.store.event("TAKE_PROFIT_SHADOW",
                                 json.dumps({"paper_id": p["paper_id"],
                                             "bid": str(bid),
                                             "diagnostic": diagnostic},
                                            ensure_ascii=False)[:1000])
            except Exception as exc:
                self.store.event("TAKE_PROFIT_SHADOW_ERROR",
                                 f"{p['paper_id']}: {type(exc).__name__}")
        if not cause and bid <= Decimal(p["stop_price"]):
            cause = "STOP_PAPER"
        elif not cause and bid >= Decimal(p["target_price"]):
            cause = "TAKE_PROFIT_PAPER"
        if not cause:
            return verdict("OPEN", "Dentro de parámetros")
        if size * self.broker.participation <= 0:
            return verdict("EXIT_PENDING_NO_LIQUIDITY", "Sin profundidad de salida")
        verdict("EXIT_DUE", "Salida decidida; pendiente de fill")
        reason = "El ejecutor no confirmó un cierre"
        try:
            self.close_fn(p, q, cause, as_of=at)
            # La devolución del callback no sustituye la evidencia del ledger.
            with self.store.connect() as c:
                actual = c.execute("SELECT status,closed_at FROM paper_positions WHERE paper_id=?", (p["paper_id"],)).fetchone()
            if actual and actual[0] == "CLOSED":
                self._probe(p["paper_id"], "FINAL_FILL", actual[1], cause)
                return Verdict(p["paper_id"],"CLOSED",cause,"Venta simulada registrada")
            with self.store.connect() as c:
                from cd_spot_ledger import partition
                row = c.execute('SELECT * FROM paper_positions WHERE paper_id=?',(p['paper_id'],)).fetchone()
                remaining = partition(c,row)[0] if row else None
            if remaining and Decimal(remaining['quantity']) < Decimal(p['quantity']):
                return Verdict(p['paper_id'],'EXIT_PARTIAL',cause,
                               'Fill parcial registrado; remanente '+remaining['quantity'])
        except Exception as exc:
            reason = "Error del ejecutor: " + type(exc).__name__
        return self._persist(p, Verdict(p["paper_id"],"EXIT_PENDING_EXECUTION",cause,reason),at,attempted=True)

    def tick(self, quotes=None):
        at = aware_datetime(self.clock_fn()).isoformat()
        settlement_error = ''
        try:
            self.broker.settle_cauciones(at)
        except ValueError:
            # Caución no conciliada: no acreditar ni admitir entradas, pero
            # conservar la supervisión/venta de tenencias spot válidas.
            settlement_error = 'CAUCION_SETTLEMENT_BLOCKED; requiere conciliación. '
        if self.broker.daily_risk:
            self.broker.daily_risk.evaluate(at)
        verdicts = []
        positions, invalid = self.store.exit_positions()
        if invalid:
            settlement_error += f'SPOT_LEDGER_BLOCKED; {len(invalid)} abiertas requieren conciliación. '
        for p, error in invalid:
            verdicts.append(self._persist(p,Verdict(p['paper_id'],'WATCH_INVALID_LEDGER',None,error),at))
        for p in positions:
            key = tuple(p[k] for k in ("symbol","asset_class","settlement","currency","market"))
            try:
                q = quotes.get(key) if quotes is not None else self.store.latest_quote(p)
                verdicts.append(self.supervise(p,q,at))
            except Exception as exc:
                verdicts.append(self._persist(p,Verdict(p["paper_id"],"WATCH_ERROR",None,
                                                        type(exc).__name__),at))
        self.heartbeat(at,state='DEGRADED' if settlement_error else 'RUNNING',
                       detail=settlement_error+f"{len(verdicts)} posiciones supervisadas; sin red ni IA")
        return verdicts
