"""Cache-only IOL SHADOW quality and counterfactual fragment for RC6 /validacion.

Presentation only. It reads the latest isolated IOL cache through
observation.collect and cannot invoke IOL, change PPI data, READY/HOLD, signals,
sizing, or any order path. Unknown or incomplete cache fields remain explicit.
"""
from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from typing import Any

import bg_paper_dashboard as bg
import iol_shadow_observation_rc6 as observation

MAX_ROWS = 10
DECISION_FRESHNESS_SECONDS = 120
UNKNOWN = "UNKNOWN"
INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"


def _number(value: Any, suffix: str = "") -> str:
    try:
        return f"{float(value):,.2f}{suffix}"
    except (TypeError, ValueError):
        return "—"


def _text(value: Any, fallback: str = "—") -> str:
    text = str(value or "").strip()
    return text if text else fallback


def _card_state(value: Any) -> str:
    state = _text(value, UNKNOWN).upper()
    if state in {"READY", "ALIGNED", "VERIFIED", "COMPLETE", "GOOD"}:
        return "green"
    if state in {"DEGRADED", "DIVERGENCE", "STALE", "IN_PROGRESS", INSUFFICIENT_EVIDENCE}:
        return "yellow"
    return "gray"


def _metric(data: dict[str, Any], name: str) -> Any:
    telemetry = data.get("telemetry") if isinstance(data.get("telemetry"), dict) else {}
    metrics = data.get("metrics") if isinstance(data.get("metrics"), dict) else {}
    return telemetry.get(name, metrics.get(name))


def _progress(data: dict[str, Any]) -> dict[str, Any]:
    value = data.get("progress") if isinstance(data.get("progress"), dict) else {}
    scheduled = value.get("scheduled", value.get("target"))
    completed = value.get("completed")
    if scheduled is None or completed is None:
        return {"state": UNKNOWN, "label": "Sin plan de ingesta publicado"}
    try:
        scheduled_n, completed_n = int(scheduled), int(completed)
    except (TypeError, ValueError):
        return {"state": INSUFFICIENT_EVIDENCE, "label": "Progreso no verificable"}
    if scheduled_n <= 0:
        return {"state": INSUFFICIENT_EVIDENCE, "label": "Universo objetivo inválido"}
    pct = min(100, max(0, round(completed_n * 100 / scheduled_n)))
    source = _text(value.get("universe_source"), UNKNOWN)
    fresh = value.get("provider_fresh", value.get("fresh"))
    timestamped = value.get("provider_timestamped")
    capture_recent = value.get("capture_recent")
    cached = value.get("cache_symbols")
    recent_label = ""
    if fresh is not None:
        try:
            denominator = int(cached) if cached is not None else scheduled_n
            recent_label = (f" · precio con timestamp ≤120s: {max(0, int(fresh))}/{max(0, denominator)}")
            if timestamped is not None:
                recent_label += f" · timestamp disponible: {max(0, int(timestamped))}/{max(0, denominator)}"
            if capture_recent is not None:
                recent_label += f" · capturas recientes: {max(0, int(capture_recent))}/{max(0, denominator)}"
        except (TypeError, ValueError):
            recent_label = " · frescura IOL no verificable"
    fallback = source in {"EMERGENCY_FALLBACK_8", "CONFIGURED_FALLBACK_SUBSET"}
    state = "DEGRADED" if fallback else ("COMPLETE" if completed_n >= scheduled_n else "IN_PROGRESS")
    label = f"{completed_n}/{scheduled_n} instrumentos · {pct}% · fuente: {source}{recent_label}"
    if fallback:
        label += " · cobertura de catálogo degradada"
    return {"state": state, "label": label}

def _row_quality(row: dict[str, Any]) -> tuple[str, str]:
    """Prefer provider timestamp; fall back to visibly unverified capture age."""
    quote = row.get("quote") if isinstance(row.get("quote"), dict) else {}
    provider_time = quote.get("provider_observed_at")
    freshness = ""
    if provider_time:
        try:
            observed = datetime.fromisoformat(str(provider_time).replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - observed.astimezone(timezone.utc)).total_seconds()
            freshness = ("SOURCE_FRESH" if 0 <= age <= DECISION_FRESHNESS_SECONDS else
                         "SOURCE_AGING" if DECISION_FRESHNESS_SECONDS < age <= 900 else
                         "SOURCE_STALE" if age > 900 else UNKNOWN)
        except (TypeError, ValueError):
            freshness = UNKNOWN
    else:
        try:
            captured = datetime.fromisoformat(str(row.get("captured_at") or "").replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - captured.astimezone(timezone.utc)).total_seconds()
            freshness = ("CAPTURE_RECENT_SOURCE_TIME_UNKNOWN" if 0 <= age <= DECISION_FRESHNESS_SECONDS else
                         "CAPTURE_AGING_SOURCE_TIME_UNKNOWN" if DECISION_FRESHNESS_SECONDS < age <= 900 else
                         "STALE" if age > 900 else UNKNOWN)
        except (TypeError, ValueError):
            freshness = UNKNOWN
    quality = _text(row.get("data_quality") or row.get("quality"), "").upper()
    if not quality:
        quality = "VALID" if _text(row.get("state"), UNKNOWN).upper() == "READY" and quote.get("last") is not None else UNKNOWN
    return freshness, quality

def _counterfactual(row: dict[str, Any]) -> tuple[str, str]:
    value = row.get("counterfactual") if isinstance(row.get("counterfactual"), dict) else {}
    evidence = _text(value.get("evidence_state"), INSUFFICIENT_EVIDENCE).upper()
    candidate = _text(value.get("candidate_id"), "")
    original = _text(value.get("original_paper_decision"), "")
    outcome = _text(value.get("shadow_outcome"), "")
    rationale = _text(value.get("rationale"), "")
    if evidence != "VERIFIED" or not candidate or not original or not outcome:
        return (INSUFFICIENT_EVIDENCE,
                "Sin candidato, decisión PAPER original y evidencia temporal verificable; no se infiere un resultado.")
    return (outcome, f"Candidato {candidate}; PAPER original: {original}. {_text(rationale, 'Sin detalle adicional.')}")


def _field_counts(row: dict[str, Any]) -> tuple[int, int]:
    quote = row.get("quote") if isinstance(row.get("quote"), dict) else {}
    fields = {
        "quote.last": quote.get("last"),
        "quote.bid": quote.get("bid"),
        "quote.ask": quote.get("ask"),
        "quote.spread_pct": quote.get("spread_pct"),
        "quote.variation_pct": quote.get("variation_pct"),
        "quote.cash_volume": quote.get("cash_volume"),
        "asset_type": row.get("asset_type"),
        "currency": row.get("currency"),
        "units_per_lot": row.get("units_per_lot"),
    }
    present = sum(value is not None and (not isinstance(value, str) or bool(value.strip()))
                  for value in fields.values())
    return present, len(fields)


def _comparison(row: dict[str, Any]) -> tuple[str, Any]:
    value = row.get("primary_comparison")
    if isinstance(value, dict):
        return _text(value.get("state"), UNKNOWN).upper(), value.get("difference_pct")
    return _text(value, UNKNOWN).upper(), row.get("difference_pct", row.get("ppi_iol_difference_pct"))

def _summary(rows: list[dict[str, Any]]) -> tuple[int, int, int, int]:
    states = [_comparison(row)[0] for row in rows]
    aligned = sum(state in {"MATCH", "BACKGROUND_ALIGNED"} for state in states)
    divergent = sum(state in {"PRICE_DIVERGENCE", "BACKGROUND_DIVERGENCE"} for state in states)
    incomplete = sum(state in {"BACKGROUND_COMPARISON_INCOMPLETE", UNKNOWN} for state in states)
    unavailable = sum(_text(row.get("state"), UNKNOWN).upper() != "READY" for row in rows)
    return aligned, divergent, incomplete, unavailable


def render() -> str:
    """Render bounded cache evidence only; no network, refresh, or decision calls."""
    data = observation.collect()
    rows = [row for row in (data.get("symbols") or []) if isinstance(row, dict)]
    state = _text(data.get("state"), UNKNOWN).upper()
    aligned, divergent, incomplete, unavailable = _summary(rows)
    fresh_rows = sum(_row_quality(row)[0] == "SOURCE_FRESH" for row in rows)
    capture_recent_rows = sum(_row_quality(row)[0] == "CAPTURE_RECENT_SOURCE_TIME_UNKNOWN" for row in rows)
    progress = _progress(data)
    call_count = _metric(data, "calls_total")
    rate_limited = _metric(data, "calls_429")
    errors = _metric(data, "errors_total")
    cache_hits = _metric(data, "cache_hits")
    cache_label = (
        f"llamadas: {_number(call_count)} · 429: {_number(rate_limited)} · "
        f"errores: {_number(errors)} · cache hits: {_number(cache_hits)}"
        if any(value is not None for value in (call_count, rate_limited, errors, cache_hits))
        else ("Collector pendiente: métricas MCP aún no publicadas." if not rows
              else f"Último lote: {_number(_metric(data, 'last_batch_size') or _metric(data, 'batch_symbols'))} · cache: {len(rows)} instrumentos")
    )
    primary_contract = data.get("primary_comparison_contract") if isinstance(data.get("primary_comparison_contract"), dict) else {}
    primary_state = _text(primary_contract.get("state"), UNKNOWN).upper()
    cache_note = (
        "No hay cache IOL válida. La ausencia de IOL no bloquea ni degrada PAPER."
        if state in {"UNAVAILABLE", UNKNOWN} else
        "Lectura local cacheada: esta página no consulta IOL ni PPI. La cobertura corresponde al ciclo activo."
    )
    cards = "".join((
        bg._card("Estado IOL", state, cache_note, _card_state(state)),
        bg._card("Progreso de ingesta", progress["label"],
                 "Plan publicado por collector; nunca inicia una consulta desde esta vista.", _card_state(progress["state"])),
        bg._card("Calidad MCP", cache_label,
                 "Las métricas se muestran sólo si fueron registradas en el cache aislado.", "gray"),
        bg._card("Reconciliación PPI/IOL", f"{aligned} alineados · {divergent} divergentes · {incomplete} sin base comparable",
                 "Divergencia = diagnóstico background, nunca HOLD/READY.", "yellow" if divergent or incomplete else "green"),
        bg._card("No disponibles", unavailable,
                 "Faltantes y errores se mantienen visibles; no se completan con supuestos.", "gray"),
    ))
    contribution = "".join((
        bg._card("Cobertura para análisis", progress["label"],
                 "IOL amplía el contexto del universo completo del catálogo; no crea ni descarta señales.", _card_state(progress["state"])),
        bg._card("Cotizaciones IOL con timestamp reciente", f"{fresh_rows}/{len(rows)} filas visibles",
                 f"frescos para decisión: {capture_recent_rows + fresh_rows}/{len(rows)} según captura local; timestamp de proveedor fresco: {fresh_rows}/{len(rows)} (≤120 s). Las capturas sin timestamp de proveedor no se presentan como fuente verificada.", "green" if fresh_rows else "yellow"),
        bg._card("Contraste con fuente primaria", f"{aligned} coinciden · {divergent} difieren · contrato {primary_state}",
                 "Sólo se compara con un cache primario con fuente, mercado y timestamp verificables. Una divergencia jamás cambia PAPER.", "yellow" if divergent or incomplete or primary_state != "READY" else "green"),
        bg._card("Efecto en el motor", "INFORMATIVO",
                 "Expone cotización, liquidez observada e identidad del instrumento para revisión SHADOW. No altera señales ni gates PAPER.", "green"),
    ))
    rendered_rows = []
    for row in rows[:MAX_ROWS]:
        quote = row.get("quote") if isinstance(row.get("quote"), dict) else {}
        freshness, quality = _row_quality(row)
        comparison, difference = _comparison(row)
        what_if, what_if_detail = _counterfactual(row)
        reason = _text(row.get("reason"), "")
        present_fields, total_fields = _field_counts(row)
        identity = f"{_text(row.get('asset_type'), UNKNOWN)} · {_text(row.get('currency'), UNKNOWN)} · lote {_number(row.get('units_per_lot'))}"
        quote_summary = f"Último {_number(quote.get('last'))}<br>Bid {_number(quote.get('bid'))} · Ask {_number(quote.get('ask'))}"
        extra_quote = (f"Spread {_number(quote.get('spread_pct'), '%')} · Var. {_number(quote.get('variation_pct'), '%')}<br>"
                       f"Vol. dinero {_number(quote.get('cash_volume'))}")
        rendered_rows.append(
            "<tr>"
            f"<td><b>{escape(_text(row.get('symbol')))}</b></td>"
            f"<td>{escape(_text(row.get('market')))}</td>"
            f"<td>{escape(identity)}<br><span class='paper-muted'>{present_fields}/{total_fields} campos IOL</span></td>"
            f"<td>{escape(_text(row.get('state'), UNKNOWN))}</td>"
            f"<td>{quote_summary}</td>"
            f"<td>{extra_quote}</td>"
            f"<td>{escape(freshness)} · {escape(quality)}</td>"
            f"<td>{escape(comparison)} · {_number(difference, '%')}</td>"
            f"<td>{escape(what_if)}<br><span class='paper-muted'>{escape(what_if_detail)} {escape(reason)}</span></td>"
            "</tr>"
        )
    rows_html = "".join(rendered_rows) or (
        "<tr><td colspan='9' class='paper-muted'>Aún no hay evidencia IOL cacheada. "
        "Se mostrará progreso, calidad y reconciliación cuando el collector publique datos.</td></tr>"
    )
    return (
        "<section class='paper-card'>"
        "<h2>IOL — evidencia SHADOW: calidad, reconciliación y contrafactual</h2>"
        "<div class='paper-warning'><b>Observación únicamente.</b> PPI conserva la autoridad primaria. "
        "Esta evidencia no puede cambiar READY/HOLD, señales, tamaños, entradas, salidas ni órdenes.</div>"
        f"<p class='paper-muted'>Fuente: {escape(_text(data.get('source'), 'IOL_MCP'))} · "
        f"modo: {escape(_text(data.get('mode'), 'SHADOW'))} · "
        f"efecto: {escape(_text(data.get('decision_effect'), 'OBSERVE_ONLY'))} · "
        f"última cache: {escape(_text(data.get('refreshed_at'), 'pendiente'))}</p>"
        f"<div class='paper-grid'>{cards}</div>"
        "<h3>Aporte de IOL al análisis del motor</h3>"
        f"<div class='paper-grid'>{contribution}</div>"
        "<div class='paper-table-wrap'><table><thead><tr>"
        "<th>Especie</th><th>Mercado</th><th>Tipo · moneda · lote</th><th>Estado</th><th>Último · bid · ask</th>"
        "<th>Spread · variación · volumen</th><th>Frescura de fuente · calidad</th><th>PPI/IOL</th><th>Qué habría pasado</th>"
        "</tr></thead><tbody>" + rows_html + "</tbody></table></div>"
        f"<p class='paper-muted'>Se muestran los 10 instrumentos más recientes de un cache de {len(rows)} filas; la cobertura se calcula sobre el ciclo activo, no sobre filas antiguas. “Qué habría pasado” sólo se muestra como VERIFIED cuando existe el candidato, "
        "la decisión PAPER original y evidencia temporal comparable. En cualquier otro caso figura "
        "INSUFFICIENT_EVIDENCE. Es explicación posterior; jamás reescribe la decisión histórica ni ejecuta acciones.</p>"
        "</section>"
    )
