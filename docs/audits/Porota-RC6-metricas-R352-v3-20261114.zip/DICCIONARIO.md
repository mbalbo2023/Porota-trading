# Diccionario de archivos

Los CSV conservan encabezados y registros del extracto de origen. Los JSON contienen la estructura completa de las mediciones. Los Markdown de métodos acompañan a cada frente.

| Archivo | Filas de datos CSV | Uso |
|---|---:|---|
| [pr-lifecycle.csv](./datos/pr-lifecycle.csv) | 1.049 | Una fila por PR con estado, fechas y refs del proveedor. |
| [pr-analysis.json](./datos/pr-analysis.json) | — | Distribuciones y ventanas comparables con su cobertura. |
| [pr-scope-review-sample.json](./datos/pr-scope-review-sample.json) | — | Archivos, primer commit y reviews históricos de la muestra revisada. |
| [pr-local-commit-evidence.json](./datos/pr-local-commit-evidence.json) | — | Corroboración de fechas por historia Git disponible. Ver cobertura por PR. |
| [pr-incremental-delta.json](./datos/pr-incremental-delta.json) | — | Actualización entre los cortes de PR, detalles adicionales e indicadores de review. |
| [pr-detail-pending.csv](./datos/pr-detail-pending.csv) | 0 | PR con dimensiones de detalle pendientes, identificados individualmente. |
| [pr-detail-coverage.json](./datos/pr-detail-coverage.json) | — | Cobertura completa de fechas de primer commit y reviews, fuentes y límites del corte. |
| [pr-review-submissions.csv](./datos/pr-review-submissions.csv) | 10 | Todos los envíos de review formal observados antes del corte, sin identidades ni textos. |
| [pr-method.md](./metodos/pr-method.md) | — | Selección de cohortes, evidencia de desarrollo y definiciones de PR. |
| [actions-runs.csv](./datos/actions-runs.csv) | 9.347 | Un registro por run visible, con los datos de su último intento. |
| [actions-attempts.csv](./datos/actions-attempts.csv) | 9.587 | Un registro por par run e intento, incluidos los intentos históricos. |
| [actions-workflows.csv](./datos/actions-workflows.csv) | 1.209 | Cobertura, resultados y cuantiles por workflow. |
| [actions-comparisons.csv](./datos/actions-comparisons.csv) | 1.560 | Antes y después por ventana, workflow, evento y subcohorte. |
| [actions-summary.json](./datos/actions-summary.json) | — | Agregados del repositorio y cortes temporales. |
| [actions-coverage.json](./datos/actions-coverage.json) | — | Consultas por intervalos, paginación, duplicados y cobertura de intentos. |
| [actions-method.md](./metodos/actions-method.md) | — | Definiciones de tiempo, denominadores y límites de la API de Actions. |
| [production-runs.csv](./datos/production-runs.csv) | 177 | Un registro por run histórico de Promote V2. |
| [production-attempts.csv](./datos/production-attempts.csv) | 185 | Todos los intentos visibles de los runs de Promote V2. |
| [production-stages.csv](./datos/production-stages.csv) | 3.802 | Pasos por run, intento y job con conclusión y tiempo cuando se ejecutaron. |
| [production-stage-summary.csv](./datos/production-stage-summary.csv) | 96 | Frecuencia y distribución por paso y conclusión. |
| [production-release-traces.csv](./datos/production-release-traces.csv) | 114 | Recibos de releases históricas. La columna evidence_plane identifica su origen. |
| [production-metrics.md](./metodos/production-metrics.md) | — | Métricas de Promote y evidencia física histórica de R1 y R2. |
| [ci-c0-baseline.json](./datos/ci-c0-baseline.json) | — | Veinte runs de main, cinco del candidato y detalle de las pruebas A/B/D. |
| [ci-r350-delivery.json](./datos/ci-r350-delivery.json) | — | Entrega R350 posterior al corte de Actions. Incluye PR, jobs y métodos locales. |
| [ci-efficiency-report.md](./metodos/ci-efficiency-report.md) | — | Evidencia de caché, tests nativos y auditoría histórica de retiro de código. |
| [ci-c1-superseded-pr-baseline.json](./datos/ci-c1-superseded-pr-baseline.json) | — | Jobs de los 34 pares de SHA consecutivos con posible solapamiento en CI general. |
| [ci-c1-c3-delta.md](./metodos/ci-c1-c3-delta.md) | — | Propuesta y exposición de runner observada, con precedentes de modularización y retiro. |

## Claves y denominadores

| Campos o sección | Definición y uso |
|---|---|
| `number`, `base_ref`, `head_sha`, `merged_at`, `observed_at_utc` | Número de PR, rama base exacta, SHA observado, instante de merge y corte de lectura. Cada PR abierta conserva edad al corte. Un registro de PR cerrado mantiene sus referencias históricas. |
| `first_commit_listed_*`, `formal_review_*`, `path_class`, campos de cobertura | Consultar cobertura antes de agregar. Un commit lleva fechas del autor y committer. La primera revisión formal sólo recoge un envío registrado por la API de Pull Requests. La clase de paths describe la lista del PR. El clasificador ejecutado por CI tiene reglas propias. |
| `id`, `run_attempt`, `workflow_id`, `workflow_path`, `event` | Clave de run, número de intento empezando en uno, identificador/ruta de workflow y evento. El mismo run puede tener varios intentos y jobs. Para unir Actions con producción usar el par `id/run_attempt`. Para etapas usar `run_id/run_attempt/job_id/step_no`. |
| `created_at`, `run_started_at`, `updated_at`, `status`, `conclusion` | Fechas y estados observados en GitHub. La última actualización del run es un límite de metadatos. Un run pendiente puede tener conclusión vacía. En intentos previos la API puede devolver inicios registrados hasta seis segundos antes de su `created_at`. |
| `*_s` y `*_sec` | Segundos. El censo principal de Actions compara inicio registrado a última actualización en intentos completados. El C0 de jobs compara creación a fin del último job ejecutado. Una cifra de excepción lleva la definición en su fila o fuente. |
| `*_runs`, `*_completed`, `*_success`, `*_pct_all`, `*_pct_decisive` | Población de runs, completados, éxitos. La primera tasa usa toda la cohorte. La segunda usa success + failure + startup_failure. El número de casos válidos para cada estimador puede variar. |
| `main_runs`, `main_control_plane_receipts`, `failed_job_pytest_summaries` | En C0, los 20 runs tienen SHA/branch/fechas/steps/URL. Los recibos asocian cache y pruebas por run. Los subtests de las dos ejecuciones fallidas se recuperaron de sus resúmenes pytest. |
| `candidate_last5`, `individual_native_samples`, `paired_native_comparison` | Cinco últimas ejecuciones de la rama candidata al corte C0. Sólo tres corresponden al SHA exacto estudiado. Las cinco muestras A/B/D llevan marcas de cada etapa y objetos públicos de artefacto cuando existen. A+B incluye dos tiempos de runner y un solo lapso cronológico de extremo a extremo. |
| `step_result`, `duration_s`, `n_timed`, `p90_nearest_rank_s` | Resultado y duración del paso, cantidad de pasos efectivamente cronometrados y percentil 90 por rango superior. Los pasos omitidos quedan identificados por estado. |
| `release`, `evidence_plane`, `observed_start_utc`, `observed_end_utc`, `source` | Identidad del release histórico, clase de evidencia, instante inicial/final que el recibo sustenta y fuente primaria. Una etapa de Actions, un artefacto y un recibo físico documentan hechos diferentes. |
| `bytes`, `size_in_bytes`, `restored_bytes` | Tamaños en bytes reportados del objeto concreto. Una restauración de caché puede leer el mismo objeto repetidas veces. El historial carece de factura o tarifa completa. |

## Cómo interpretar faltantes y estados

Los CSV mantienen los campos vacíos de los extractos y los JSON conservan `null`. Se leen junto con cobertura, estado y campo de referencia. Una muestra vacía tiene conteo cero y duración indefinida. `NO_VERIFICADO` indica que la evidencia disponible no alcanza para la afirmación solicitada. `failure` es una conclusión literal de Actions. En una prueba diseñada para detenerse antes de subir material privado, el informe C0 distingue ese HOLD del resultado de las pruebas nativas.

Las fechas con `Z` representan UTC. Buenos Aires utiliza UTC−03:00 en este período. Los percentiles de Actions/C0 utilizan rango más próximo superior. En Promote, el p50 usa la mediana y el p90 usa ese rango. Para los PR se conservan los percentiles de su método de extracción. Los métodos individuales definen inicio, fin y población antes de comparar dos valores.
