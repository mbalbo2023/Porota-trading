# Tiempos de desarrollo, revisión y cierre de PR

Al 13 de noviembre de 2026 a las 23:29:38 ART, GitHub registraba **1.049 PR**. De ellos, 773 llegaron a merge, 274 cerraron sin merge y dos seguían abiertos. La mediana de apertura a merge fue de **3 min 43 s** y el P90 fue de **59 min 52 s**. Para los cierres sin merge fueron **57 h 25 min** y **22 días 12 h 43 min**, respectivamente.

## Cobertura de los eventos

| Observación | Cobertura | Resultado verificable |
|---|---:|---|
| PR, timestamps, estado y refs al corte | 1.049/1.049 | La población se verificó con lista paginada y búsqueda independiente |
| Primer commit comparable | 1.049/1.049 | 812 primeros commits listados por GitHub y 237 PR con un único commit en el grafo exacto recuperado |
| Historial formal de revisiones | 1.049/1.049 | 10 envíos en 8 PR. En 1.041 la lista al corte quedó vacía |
| Estados de las revisiones enviadas | 10 | 10 con estado `COMMENTED` |
| Archivos modificados por PR | 37/1.049 | Listas completas para la muestra de alcance; la clasificación usa nombres de archivo |
| Comentarios en líneas del diff | Repositorio al corte | Ocho comentarios en cinco PR. La revisión formal de #39 registró un envío sin comentario en esa lista |

El primer commit registrado precedió a la apertura con mediana **27 s** y P90 **8 min 1 s**. Hubo 2 PR con un intervalo negativo que indica un primer commit listado posterior a la apertura. La primera revisión formal llegó desde la apertura en mediana **20 min 36 s** y P90 **1 h 13 min 29 s** entre los 8 PR que registraron ese evento. El estado `CHANGES_REQUESTED` se observó en 0 PR. La dedicación de programación y revisión requiere un registro de trabajo activo. El tiempo de reloj entre dos eventos incluye también esperas y actividad paralela.

## Antes y después

Las dos semanas contiguas abarcan del 31 de octubre al 7 de noviembre y del 7 al 14 de noviembre UTC, con límite de las 01:56:01. Esta comparación usa el mismo calendario del informe de Actions. La asignación se hace por creación de PR. Cada celda muestra mediana / P90; la columna de observaciones cuenta únicamente los intervalos cuya marca inicial y final constan en la fuente.

| Medida | Observaciones antes / después | Antes, mediana / P90 | Después, mediana / P90 |
|---|---:|---:|---:|
| Primer commit a apertura, todas las ramas | 257 / 80 | 33 s / 2 min 57 s | 39,5 s / 3 min 10 s |
| Apertura a primera revisión formal, todas las ramas | 1 / 4 | 41 min 23 s / 41 min 23 s | 2 min 22 s / 24 min 10 s |
| Apertura a merge, todas las ramas | 173 / 43 | 7 min 11 s / 1 h 19 min 49 s | 6 min 11 s / 34 min 2 s |
| Apertura a cierre sin merge, todas las ramas | 84 / 35 | 2 d 5 h 10 min / 6 d 15 h 50 min | 3 d 2 h 16 min / 4 d 1 h 6 min |
| Apertura a merge a main, ±24 h de R266 | 10 / 10 | 6 min 15 s / 22 min 41 s | 6 min 24 s / 1 h 15 min 44 s |
| Apertura a merge a main, ±24 h de R269 | 11 / 9 | 7 min 24 s / 50 min 32 s | 4 min 59 s / 1 h 15 min 44 s |

Las cohortes R266 y R269 se superponen. R266 toma el recibo público de la integración selectiva en el candidato del 12 de noviembre a las 19:44:40 UTC. R269 toma el merge a `main` a las 20:57:07 UTC del mismo día. En R350 #1116 el primer commit precedió a la apertura por 47 s y el merge llegó 4 min 30 s después de abrir el PR. El corte fijado para el censo es posterior al merge por 14 min 2,882 s. En ese lapso se crearon cero PR. El tamaño y la composición de los grupos limitan la atribución de cambios de duración. [R266](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6834127995) · [R269](https://github.com/mbalbo2023/Porota-trading/pull/1104) · [R350](https://github.com/mbalbo2023/Porota-trading/pull/1116)

## Construcción del censo

1. Se obtuvo `GET /repos/mbalbo2023/Porota-trading/pulls?state=all&per_page=100&sort=created&direction=desc`. A las 02:05:53.839 UTC del 14 de noviembre, las páginas rindieron diez grupos de 100, uno de 48 y otro vacío. La búsqueda independiente `repo:mbalbo2023/Porota-trading is:pr` contó 1.048 con `incomplete_results=false`. La actualización ordenada por `updated` hasta cruzar el corte inicial incorporó #1116 y actualizó #1113. Lista y búsqueda quedaron en 1.049 al corte de las 02:29:38.882 UTC. La secuencia de números se comparte con issues.
2. La primera pasada inspeccionó 36 PR, todos los creados desde un día antes del commit R266, el candidato previo aún abierto y un representante por combinación histórica de mes y familia destino. Se incorporaron los cuatro PR adicionales descubiertos en la lista paginada completa de comentarios en líneas y #1116. Este paso conserva 41 primeras respuestas de commit y review y 37 listas completas de archivos en `pr-scope-review-sample.json`.
3. Se buscó el par exacto base/head en el repositorio local con `git --no-lazy-fetch`, una base común única y el conjunto introducido con sus padres. Se excluyeron pares faltantes, grafos con un límite superficial y raíces ambiguas. Se conservan 547 casos con raíz única como dato separado. La comparación con la primera fila de commits REST tuvo coincidencia exacta en 309 de 310 pares disponibles. Para unir fuentes únicamente se incorporaron grafos de introducción de un solo commit. Los restantes primeros commits se obtuvieron con `GET /repos/mbalbo2023/Porota-trading/pulls/{number}/commits?per_page=1&page=1`.
4. Las revisiones se consultaron con `GET /repos/mbalbo2023/Porota-trading/pulls/{number}/reviews?per_page=100&page={page}` hasta una página corta. La hora del primer `submitted_at` y los estados del listado producen los intervalos formales. Se conserva la proyección de estado que GitHub devuelve al momento de leer. Un cambio a `DISMISSED` puede ocultar el estado anterior. Se excluyeron 0 filas sin `submitted_at` y 0 envíos posteriores al corte de población. El registro de los `review_id` quedó limitado a las respuestas de la pasada incremental. La solicitud de cuentas y cuerpos de comentarios queda fuera de la extracción.
5. La pasada final procesó la cola de 1.008 listas de revisiones y 771 primeros commits con un máximo de dos lecturas concurrentes, desde 2026-11-14T02:44:35.985Z hasta 2026-11-14T02:53:17.115Z. Se guardaron 56 lotes y se verificaron 1.779 parejas PR/endpoint distintas en 8 min 41 s. Se registraron 0 respuestas de error. `pr-detail-pending.csv` queda con su encabezado y cero pendientes. `pr-detail-coverage.json` documenta ambos cortes.

## Definiciones y reproducción

`pr-lifecycle.csv` conserva la rama y SHA de ambos lados devueltos por GitHub, la marca de draft durante el censo y sus timestamps originales en UTC. Los dos PR abiertos se censuran al corte. Los campos de duración conservan segundos y su signo. Un valor negativo en `first_formal_review_to_merge_signed_sec` indica que el envío llegó después del merge. La distribución de cierre de una ventana sólo agrega PR con evento observado, por lo que los períodos cortos favorecen las finalizaciones rápidas. Los límites de cada intervalo son inclusivo al comienzo y exclusivo al final. P50 y P90 usan interpolación lineal tipo 7. Una muestra vacía conserva conteo cero y percentiles nulos.

`pr-review-submissions.csv` documenta cada envío formal hasta el corte, con PR, estado observado y timestamp. Una lista de revisiones vacía puede coexistir con revisiones por otro canal. `pr-analysis.json` presenta distribuciones por rama exacta, cohortes de creación y ventanas centradas en R266, R269, el plan R350 y su merge. `first_known_commit_source` permite desglosar evidencia REST y grafo individual. Un rebase o nuevo commit puede cambiar el primer commit visible de la rama.

La clasificación por alcance conserva las 37 observaciones completas de nombres de archivo. Reconoce documentación (`.md`, `.rst`, `.adoc`), pruebas, `.github` y el conjunto scripts/pruebas/`.github`. Para certificar un job omitido se usa la ejecución correspondiente de Actions. Al refrescar una población futura, paginar PR ordenados por `updated` hasta cruzar este corte, reconciliar la búsqueda independiente e invalidar observaciones de commits y archivos tras un cambio de head. La revisión histórica de un PR puede cambiar si se envía o descarta una revisión. Cada nueva extracción debe conservar su instante.
