# Porota RC6 · tiempos y resultados de Deploy V2

**Último despliegue con runtime acreditado** — R1, producto `eefcf6d8c93f3eddfc23bd471d9d5b41d9a31a9f`, cerró el 6 de noviembre de 2026 a las 09:14:32 ART. El job duró 17:59 y el workflow 18:03. La comprobación física independiente terminó con `PAPER=0` y marcador `VALIDATED_RUNTIME`. El recibo documentó cero órdenes y rutas reales sin invocar. [Deploy R1](https://github.com/mbalbo2023/Porota-trading/actions/runs/42213911331) · [Cierre físico R1](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6684666632)

**Último intento productivo** — R2, producto `7ac6e368bd42137817e3271839c35f579bdbbbbe`, terminó con error el mismo día a las 14:18:59 ART, tras 3:03. Alcanzó la instalación de 591 archivos y la carga de imagen. Falló la recuperación COLD y luego la recuperación de schedulers. El diagnóstico posterior encontró el marcador de R1, observer/dashboard detenidos y approval activo. Es una observación histórica acotada. El estado actual del runtime y una mejora de producción atribuible a R350 siguen `NO_VERIFICADO`. [Deploy R2](https://github.com/mbalbo2023/Porota-trading/actions/runs/42260034260) · [Recibo POSTFAIL](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6691085538) · [Segundo diagnóstico A724](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6691677444)

## Cobertura

Corte de la consulta productiva el **14 de noviembre de 2026 a las 02:12:48 UTC**, 13 de noviembre 23:12:48 ART. Se inspeccionaron las cinco páginas de 472 runs por push de la rama productiva, con registros desde el primer Deploy V2 del 26 de septiembre. El filtro exacto de workflow `367852515`, path `.github/workflows/porota-deploy-v2-promote.yml` y rama `deploy/rc6-pr69-isolated-20260915` dio 177 runs de promoción. La secuencia global va del 1 al 180. Los números 42, 43 y 44 se ejecutaron en `fix/ws-disk-07-pretransfer-metrics-20261001` y están fuera del universo productivo. Se recuperaron los jobs para los 177 runs, incluyendo todos los reintentos. [Workflow de producto en el SHA exacto](https://github.com/mbalbo2023/Porota-trading/blob/7ac6e368bd42137817e3271839c35f579bdbbbbe/.github/workflows/porota-deploy-v2-promote.yml) · [42](https://github.com/mbalbo2023/Porota-trading/actions/runs/36888944417) · [43](https://github.com/mbalbo2023/Porota-trading/actions/runs/36888968617) · [44](https://github.com/mbalbo2023/Porota-trading/actions/runs/36889008544)

| Unidad de medida | Total | Success | Failure | Skipped |
|---|---:|---:|---:|---:|
| Run único, conclusión de su último intento | 177 | 49 | 128 | 0 |
| Intento de Deploy, un job por intento | 185 | 49 | 136 | 0 |
| Registros de pasos, 50 nombres distintos según la versión | 3.802 | 2.544 | 156 | 1.102 |

Ocho runs tuvieron un segundo intento. Tres segundos intentos pasaron y cinco fallaron de nuevo. La primera etapa roja de 95 de los 136 intentos fallidos fue `Promote exact frozen candidate and verify`. En otros once fue la clasificación de la sesión PAPER y en siete la guarda dinámica de disco. Son puntos del pipeline donde se manifestó el fallo. Sólo se verificó la causa física de R2 con sus registros de host. Los 49 éxitos describen resultados de Actions. El vínculo con evidencia física se detalla aquí para R1/R2. [Carril de Deploy V2](https://github.com/mbalbo2023/Porota-trading/actions/workflows/porota-deploy-v2-promote.yml)

## Comparaciones observadas

Dos runs productivos exitosos recientes tienen los mismos 34 nombres y conclusiones de pasos, incluidas las omisiones. El primero es del 1 de noviembre y el segundo corresponde a R1 el 6 de noviembre. Las dos mediciones pertenecen a candidatos distintos. [Run 41267349231](https://github.com/mbalbo2023/Porota-trading/actions/runs/41267349231) · [Run 42213911331](https://github.com/mbalbo2023/Porota-trading/actions/runs/42213911331)

| Tramo | 1 nov., exitoso | 6 nov., R1 exitoso | Diferencia R1 |
|---|---:|---:|---:|
| Workflow completo | 17:39 | 18:03 | +24 s |
| Descargar y verificar artefacto | 16 s | 14 s | −2 s |
| Guarda de disco previa a transferencia | 2 s | 2 s | 0 s |
| Transferir artefacto | 13 s | 13 s | 0 s |
| Promover candidato y verificar | 15:11 | 15:46 | +35 s |
| Finalizar marcador | 3 s | 3 s | 0 s |
| Verificar PAPER independiente al final | 4 s | 4 s | 0 s |

Para todos los intentos, la mediana de workflow es 21:15 y el p90 58:51 en los 49 exitosos. Entre los 136 fallidos la mediana es 4:48,5 y el p90 58:27. En la serie de éxitos, septiembre tuvo 11 casos (mediana 7:01), octubre 36 (23:48,5) y noviembre dos (17:51). Cambiaron los pasos y el contenido de las releases durante ese período. El histórico no permite atribuir esos cambios a una optimización concreta.

## R1 y R2 desde Predeploy hasta POST

| Proceso observado | R1 | R2 |
|---|---:|---:|
| Predeploy V2, duración total | 24:35 · SUCCESS | 23:37 · SUCCESS |
| Descubrimiento y ejecución de tests | 5:29 · 6.671/6.671 | 5:58 · 6.727/6.727 |
| Build único del candidato | 3:16 | 2:34 |
| Prueba nativa de sizing y catálogo en imagen | 12:15 | 12:29 |
| Predeploy finalizado → comentario GO exacto | 10:51:41 | 1:14 |
| Comentario GO exacto → inicio del Deploy | 6:08 | 21 s |
| RAMA/PR de producto | #1014 · `eefcf6d8` | #1021 · `7ac6e368` |
| Duración Deploy / job | 18:03 / 17:59 | 3:03 / 2:59 |
| Guardia de disco / transferencia | 2 s / 13 s | 2 s / 13 s |
| Promoción y verificación del candidato | 15:46 · SUCCESS | 58 s · FAILURE |
| Verificación de sesión PAPER tras restart | 4 s · SUCCESS | SKIPPED |
| Restauración / comprobación de schedulers | 6 s / 6 s · SUCCESS | SKIPPED |
| Retiro de backups acotados | 5 s · SUCCESS | SKIPPED |
| Marcador / comprobación independiente | 3 s / 4 s · SUCCESS | SKIPPED |
| Cleanup de fallo | SKIPPED, cierre normal auditado | 12 s · FAILURE, staging recuperado |
| Reclamación de imágenes huérfanas tras fallo | SKIPPED | SKIPPED |

El tiempo entre Predeploy y GO incluye espera humana y de coordinación. El reloj del workflow R2 se detuvo por el error y dejó fases sin ejecutar. Un benchmark de R350 en host requiere otro candidato desplegado y sus propios recibos.

* R1 congeló el candidato `f32db99ce9bbe417a3b41dc219e6b0bb39affec3`, árbol `73670c2babc54325fce8067742f5a7da6468b06f`. Artefacto `13467267881`, digest de ZIP `sha256:2c51691f1aae4c21f379b3083aa645b1dc8bd5e18fe858ebcf81afe5a6ad1e80`. [Predeploy R1](https://github.com/mbalbo2023/Porota-trading/actions/runs/42137763312) · [GO #624 R1](https://github.com/mbalbo2023/Porota-trading/issues/624#issuecomment-6684143832) · [Recibo #732](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6684666632)
* R2 congeló el candidato `a16a31c7bc4634362870c731273e084eea9d357d`, árbol `dca87d7dde4c03163e8f2e320008b85f72fcca10`. Artefacto `13525010530`, digest de ZIP `sha256:f06590b389e18fd247868e03983d1b3864ebe077d65895bf2b991952b2dccc40`. Los dos GO exactos tienen `created_at == updated_at` y vinculaban sus propios SHA/árbol. [Predeploy R2](https://github.com/mbalbo2023/Porota-trading/actions/runs/42256134344) · [GO #624 R2](https://github.com/mbalbo2023/Porota-trading/issues/624#issuecomment-6690840240) · [Recibo A728](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6690882956)

### Instalación, recuperación y evidencia de producción

En R1 la guarda midió 5.104.541.696 B libres contra 4.080.021.559 B requeridos. El host verificó/instaló 591 archivos y aplicó 44 units. La identidad en ejecución quedó GREEN a las 11:59:39 UTC. La reconciliación completa cerró a las 12:03:23 UTC, seguida de cuatro auditorías de runtime, cinco observaciones del guard exit139 y la condición `CLOSED_IDLE`. La limpieza final documentó auditoría con cero bytes recuperados, 5.105.750.016 B libres y 91,338126 % de inodos libres. La verificación independiente del marcador terminó a las 12:14:26 UTC. La frescura de fuentes y readiness por instrumento tuvieron alcance separado. [Log del job R1](https://github.com/mbalbo2023/Porota-trading/actions/runs/42213911331/job/127879050788) · [Cierre #732](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6684666632)

En R2 la guarda midió 4.831.924.224 B libres contra 4.080.648.522 B requeridos. El host instaló 591 archivos a las 17:17:50 UTC y cargó la imagen a las 17:18:18 UTC. A las 17:18:42 UTC apareció `COLD_ARCHIVED_RECOVERY_NOT_PROVEN`. La limpieza recuperó 293.736.448 B de staging, pero `SCHEDULER_STOPPED_CLOSED_FLAT_RED` conservó la barrera. El diagnóstico de 18 s observó 3.370.762.240 B libres y dos imágenes sin identidad suficiente para borrar. El diagnóstico A724 de 21 s encontró 15 timers inactivos y el guard IOL activo. El recibo conservó `real_orders_sent=0` y `ppi_watch_accessed=false`. La prueba directa de libro DB flat quedó `NO_VERIFICADO`. [Log del job R2](https://github.com/mbalbo2023/Porota-trading/actions/runs/42260034260/job/128037233727) · [Diagnóstico de capacidad](https://github.com/mbalbo2023/Porota-trading/actions/runs/42261242780) · [Diagnóstico A724](https://github.com/mbalbo2023/Porota-trading/actions/runs/42265610943)

La rama de control y la rama candidata pueden generar CI, simulaciones y HOLD sin generar un evento de promoción productiva. El Predeploy del candidato `0e7577fc`, run 43537395716 del 14 de noviembre UTC, salió con HOLD79 en R252 por falta de D/E exactos. El checkpoint de #1093 y el runbook documentan ese estado. R350 actúa en autorización del plano de control y el censo no registra otro Deploy V2 productivo tras R2 al corte. [Predeploy HOLD](https://github.com/mbalbo2023/Porota-trading/actions/runs/43537395716) · [Checkpoint #1093](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6868776432) · [Runbook R349](https://github.com/mbalbo2023/Porota-trading/blob/11a1767c4c381da15744207333fa18f612b3f60c/docs/governance/RC6_NIGHT_AUTONOMOUS_EXECUTION_20261113.md)

## Archivos y método

* `production-runs.csv` contiene el último intento de cada run y el primer paso fallido de ese intento. Para la serie de fechas del run, `created_at` es la creación del run original.
* `production-attempts.csv` contiene todos los intentos. `duration_start_to_updated_s` usa `run_started_at` y `updated_at` del intento. `job_wall_s` mide el job de runner y excluye cola y cierre de Actions.
* `production-stages.csv` contiene los 3.802 registros con nombres de Actions, job, intento, fechas UTC y conclusión. Un paso omitido lleva `duration_s` vacío. Un paso ejecutado puede medir cero segundos con la resolución del API.
* `production-stage-summary.csv` agrega por nombre literal y estado. Incluye denominadores, mediana, p90 por rango más próximo (posición `ceil(0,90 × n)`), mínimo y máximo. Se excluyen los omitidos de los cálculos temporales. Los workflows históricos incorporaron o retiraron pasos.
* `production-release-traces.csv` contiene 76 registros de pasos Predeploy, dos GO, dos recibos de artefacto, dos diagnósticos POSTFAIL y 32 hitos cotejados con logs de los dos Deploy. Las marcas puntuales miden cuándo apareció cada recibo. Los intervalos incluyen tiempos de espera del host o del runner. Las filas de evidencia son observaciones distintas dentro de una misma ejecución y no se suman.

No se recolectaron latencias de trading, disponibilidad actual, geografía de red ni movimientos de disco por cada una de las 177 promociones. La cobertura de pasos de Actions es completa para la rama y el workflow declarados. Los recibos físicos detallados corresponden sólo a las dos últimas releases. Todos los tiempos del API se conservan en UTC. ART es UTC−03:00.
