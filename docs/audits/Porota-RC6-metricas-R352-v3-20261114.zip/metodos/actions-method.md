# Censo de GitHub Actions de Porota Trading

El repositorio se creó el 18 de agosto de 2026 a las 17:40:13 UTC (14:40:13 ART). El censo incluye todos los runs accesibles creados hasta el 14 de noviembre de 2026 a las 01:56:00 UTC (13 de noviembre a las 22:56:00 ART). El primer run visible empezó a registrarse el 21 de agosto a las 01:33:39 UTC (20 de agosto a las 22:33:39 ART). El último se creó el 14 de noviembre a las 01:36:43 UTC (13 de noviembre a las 22:36:43 ART). Los registros que GitHub haya borrado o dejado de exponer quedan fuera del denominador. [API del repositorio](https://api.github.com/repos/mbalbo2023/Porota-trading)

## Cobertura

| Registro | Cobertura verificada |
|---|---:|
| Runs accesibles al corte | 9.347 |
| Ventanas UTC disjuntas, contiguas y con hasta 887 runs cada una | 17 |
| Páginas, con hasta 100 filas cada una | 103 |
| IDs de run duplicados | 0 |
| Workflows distintos, por ID y ruta | 1.209 |
| Runs que tuvieron al menos un reintento | 149 |
| Intentos anteriores recuperados individualmente | 240 de 240 |
| Intentos totales con metadatos | 9.587 |
| Runs todavía en cola al corte | 2 |

La API de Actions devolvió 2.500 como total de la consulta sin subdividir. La suma de los totales de las siete primeras ventanas fue 9.347. Se subdividieron sucesivamente las ventanas con más registros para paginar por completo cada consulta. Se verificaron las fechas de todos los registros, las longitudes de todas las páginas y la unicidad dentro y entre ventanas. Cada par `id, run_attempt` esperado desde 1 hasta el último intento publicado quedó conciliado. Ningún registro de la exportación tenía un `updated_at` posterior al corte. Las 103 consultas exactas y sus conteos figuran en `actions-coverage.json`. Se leyó exclusivamente metadata de runs e intentos. [Endpoint de runs](https://api.github.com/repos/mbalbo2023/Porota-trading/actions/runs)

| Estado | Último intento de cada run | Todos los intentos |
|---|---:|---:|
| success | 6.057 | 6.210 |
| failure | 2.570 | 2.655 |
| cancelled | 556 | 558 |
| skipped | 155 | 155 |
| startup_failure | 7 | 7 |
| queued | 2 | 2 |
| Total | 9.347 | 9.587 |

De los 149 IDs reintentados, 23 pasaron de failure inicial a success final y 8 de success inicial a failure final. Hay 9.198 IDs de un intento, 110 de dos, 16 de tres, 9 de cuatro, 6 de cinco, 3 de seis, 4 de siete y 1 de nueve. Por evento, la API registró 4.851 `pull_request`, 4.091 `push`, 244 `workflow_dispatch`, 123 `schedule`, 37 `workflow_run` y 1 `dynamic`. Para los dos queued, status y marcas de tiempo se conservan tal como las devuelve GitHub. [Predeploy en cola](https://github.com/mbalbo2023/Porota-trading/actions/runs/43098410093) · [R163 en cola](https://github.com/mbalbo2023/Porota-trading/actions/runs/43098410234)

## Tiempos y ventanas

Cada porcentaje de éxito sobre todos los runs usa el denominador de la cohorte completa, incluidos cancelados, omitidos y pendientes. El porcentaje sobre resultados decisivos usa `success + failure + startup_failure`. El p50 y el p90 usan el rango más próximo superior (`ceil(n × p)`). Una cohorte vacía conserva el conteo cero y deja su estimación de tiempo en blanco.

- **Duración observada del último intento** usa `updated_at − run_started_at` de un run completado. `updated_at` es la última actualización de metadatos registrada. Sólo los estados completados tienen un intervalo terminal. Se ofrecen también percentiles sólo para intentos exitosos.
- **Tiempo transcurrido del run** usa `updated_at − created_at` en el listado de runs. Un run reintentado puede incluir horas entre intentos. Por eso se publican ambas duraciones con distintos nombres.
- **Demora hasta el inicio registrado** usa `run_started_at − created_at` sólo en los runs completados de intento 1. Esta marca puede preceder al arranque del primer job. Para medir espera del runner, tiempo facturado o solapamiento de jobs se necesitan sus fuentes específicas.
- En 95 de los 240 recibos históricos de intentos, GitHub devolvió `run_started_at` entre uno y seis segundos antes del `created_at` de ese recibo. Se conservaron ambas marcas originales. Los percentiles comparativos usan la ficha de run del último intento, en la que las 9.347 cronologías resultaron ordenadas.
- La duración de etapas de build/test, caché, facturación y push hasta todos los checks obligatorios no se deduce de las marcas de un run. La métrica previa A222 ya define cinco etapas a partir de timestamps de steps; el baseline C0 de 20 CI más 5 del candidato conserva su medición de jobs por separado. [Métrica A222 del candidato](https://github.com/mbalbo2023/Porota-trading/blob/0e7577fc6112406794ffbc392c902904481f8ca0/scripts/rc6_ci_phase_metrics.py)

## Antes y ahora

Se eligieron dos ventanas de siete días consecutivos de igual duración. La primera abarca desde `2026-10-31T01:56:01Z` inclusive hasta `2026-11-07T01:56:01Z` exclusive. La segunda comienza en ese instante y termina en `2026-11-14T01:56:01Z` exclusive. En Argentina los límites son 30 de octubre, 6 de noviembre y 13 de noviembre a las 22:56:01 ART. La agrupación conserva ID, ruta, nombre visible y evento de cada workflow, incluso cuando una o ambas ventanas carecen de ejecuciones. El resumen del repositorio mezcla distintas cargas y tipos de resultado.

| Cohorte | Runs antes / ahora | p50 antes / ahora | p90 antes / ahora |
|---|---:|---:|---:|
| Repositorio completo | 1.636 / 551 | 17 s / 11 s | 131 s / 178 s |
| CI — Porota Trading, PR | 227 / 60 | 28 s / 36 s | 42 s / 46 s |
| CI — Porota Trading, push | 101 / 42 | 28 s / 36 s | 43 s / 44 s |
| Checkpoint attestation, PR | 512 / 139 | 10 s / 9 s | 18 s / 11 s |
| Predeploy V2, PR | 298 / 98 | 119 s / 9 s | 343 s / 1.387 s |
| Deploy V2 promote, push | 7 / 0 | 950 s / sin muestra | 1.083 s / sin muestra |

En Predeploy V2, los 298 runs anteriores incluyeron 202 exitosos, 18 fallidos, 25 omitidos y 53 cancelados. De los 98 posteriores, 12 fueron exitosos, 37 fallaron, 48 se omitieron y 1 seguía en cola. La mediana de los exitosos pasó de 130 a 1.413 segundos. El cambio en la mezcla de resultados hace que la mediana de todos los completados y la mediana de los exitosos se muevan en sentidos opuestos. [Predeploy V2](https://github.com/mbalbo2023/Porota-trading/actions/workflows/porota-predeploy-v2.yml)

La comparación específica de CI alrededor de R269 usa dos ventanas de 28 h 58 min 54 s, con corte en el merge de #1104 a main el `2026-11-12T20:57:07Z` (17:57:07 ART). En el mismo workflow y evento de PR hubo 13 runs antes y 17 después. El p50 fue 37 s y 45 s, y el p90 40 s y 50 s. La asignación es temporal. Diferencias de branch, diff y mezcla de jobs impiden aislar el efecto causal de R269 con esta comparación. [PR #1104](https://github.com/mbalbo2023/Porota-trading/pull/1104)

## Archivos

| Archivo | Contenido |
|---|---|
| actions-runs.csv | 9.347 filas con ID, intento actual, workflow y ruta, evento, branch, SHA, tres timestamps, estado, conclusión y URL. |
| actions-attempts.csv | Las mismas columnas para los 9.587 intentos. Cada intento anterior proviene de su endpoint individual. |
| actions-coverage.json | 17 ventanas, las páginas y sus totales, límites del filtro amplio, cronología y cotejo de intentos. |
| actions-workflows.csv | 1.209 filas, una por ID/ruta, con nombres observados, eventos, estados, ejemplos y tiempos del historial completo. |
| actions-comparisons.csv | 1.542 cohortes exactas de workflow/nombre/evento en las dos ventanas, 16 grupos de etapa o función, el agregado del repositorio y una comparación de R269. |
| actions-summary.json | Totales y percentiles, resultados de reintentos, cohortes por etapa, mes, comparación y queued pendientes. |

La tabla de etapas clasifica explícitamente 5.300 runs en flujos conocidos. Los otros 4.047 quedan disponibles con su ruta exacta y en el total general. El mismo workflow `rc6-r163-postrun-trusted-main.yml` tuvo 26 runs bajo el auditor R163 y 5 bajo el publicador R206 B, distinguidos por el nombre ejecutado. La clasificación de flujos registra su función declarada. Los pasos que efectivamente se ejecutaron, el despliegue en el droplet y el uso de CPU o dinero requieren evidencias adicionales por run.
