# R350 — CI y retiro de código: recuperación del trabajo previo y delta READ_ONLY

**Dictamen PM/ENG: GO al plan R350 y al brief de seis rutas de autoridad.** R305/R321/R340 y sus tres suites no cambian CI, dependencias, Docker, reglas PAPER ni la autorización de host. El brief preserva la verificación de GO/expiración/original RESUME, captura identidad antes de callbacks y deniega ambos repos extranjeros/malformados del PR. El GO se limita a desarrollo focal y revisión independiente; no acredita instalación, release o runtime. C0 y las filas históricas de retiro no son un veto P0 ni solicitan trabajo nuevo.

**Fuentes reconciliadas:** main `11a1767c4c381da15744207333fa18f612b3f60c`, [candidato #1087](https://github.com/mbalbo2023/Porota-trading/pull/1087) `0e7577fc6112406794ffbc392c902904481f8ca0`, base product `7ac6e368bd42137817e3271839c35f579bdbbbbe`. GET de refs/PR/Actions y blobs; ningún workflow, build, test o acción física iniciados en esta auditoría. No cambios en repositorio/GitHub ni ownership adquirido.

## Auditorías de retiro recuperadas: decisiones que ya existen

La auditoría transversal comprobada es [#599, wiring/deprecación](https://github.com/mbalbo2023/Porota-trading/issues/599#issuecomment-6220526827) y su [censo suplementario](https://github.com/mbalbo2023/Porota-trading/issues/599#issuecomment-6220620479), publicados 2026-10-16T16:58:48Z y 17:04:13Z (13:58:48 y 14:04:13 ART). Owner histórico de auditoría: `AUDIT-RC6-PREOPEN-20261016`, READ_ONLY. Sobre producto `fa751eb1f985b55f6aeb6729704452150c93c5e4`, 158/260 módulos Python raíz tenían traza estática; los otros 102 quedaron en REVIEW. El denominador completo de aquel tree era 1123 blobs, 260 Python raíz, 410 Python anidados, 288 archivos de pruebas, 166 workflows YAML y 67 units. El censo no observó 260 procesos ni autorizó 102 bajas.

La [orden #600](https://github.com/mbalbo2023/Porota-trading/issues/600#issuecomment-6220937682) pidió por fila path/SHA, consumidor/efecto/owner y KEEP/WIRE/REVIEW/DEPRECATE. La [matriz publicada](https://github.com/mbalbo2023/Porota-trading/blob/0e7577fc6112406794ffbc392c902904481f8ca0/docs/releases/RC6_ISSUE600_20261016.md#Wiring-y-censo-clasificaci%C3%B3n-antes-de-limpiar) está aún en el candidato SHA exacto. El [JSON de evidencia](https://github.com/mbalbo2023/Porota-trading/blob/0e7577fc6112406794ffbc392c902904481f8ca0/docs/releases/RC6_ISSUE600_EVIDENCE_20261016.json) referencia ambos comentarios originales. Owner de implementación entonces: `WS-RC6-POSTCLOSE-CONSOLIDATED-20261016`, alcance reclamado en #600, no un lease vigente en este turno.

| Clasificación histórica recuperada | Disposición y hecho verificable |
|---|---|
| ACTIVE_RUNTIME | KEEP/WIRE: observer, dashboard, worker SHADOW y lector. La existencia de paths no equivale a despliegue actual. |
| OFFLINE/TEST_ONLY | KEEP: replays, benchmarks, pruebas, análisis sin autoridad; no reactivar como trabajo web/operacional. |
| INTENTIONALLY_RETIRED | KEEP: tombstones GDELT/BCRA, IA intradía OFF, unidades retiradas; se preserva evidencia. `rc6_gdelt_shadow.py` y `rc6_macro_risk_shadow.py` siguen como tombstones en el candidato. |
| QUARANTINED | KEEP: job/timer de historia externa prohibido por preopen; no ejecutar ni confundirlo con código muerto. |
| DISCONNECTED_REGRESSION | WIRE con contratos: CURRENT/reader, contrafácticos y vista anual perdidos en migración. [#602](https://github.com/mbalbo2023/Porota-trading/pull/602) MERGED al producto en `65f0eb277398500f6b799348496bacf5d806fdd9` (2026-10-16T23:22:51Z, 20:22:51 ART), monitor [#601](https://github.com/mbalbo2023/Porota-trading/pull/601) MERGED aparte a main. Persisten regresiones específicas de aliases/vista anual/auth/datos en `tests/test_rc6_issue600_dashboard_adenda.py`; no reimplementarlas. |
| NO_VERIFICADO | REVIEW: 102 módulos sin traza estática, uso real de workflows desconocido. La matriz dice explícitamente que no se eliminó ninguno. Manifiesto exhaustivo que cierre cada fila con cero consumidores y aval actual: NO_VERIFICADO; no concluir que no existe en otro ref/artefacto. |

Los 288 PASS focales históricos reportados en la matriz no certifican todo el repositorio, los 102 módulos, ni el runtime de hoy. La tabla posterior de disposición de [#603](https://github.com/mbalbo2023/Porota-trading/issues/603) mantiene las seis clases y el seguimiento de imports dinámicos, CLI/Actions/systemd/Docker. El archivo [RC4_MODULE_INVENTORY.md](https://github.com/mbalbo2023/Porota-trading/blob/0e7577fc6112406794ffbc392c902904481f8ca0/RC4_MODULE_INVENTORY.md) ya conserva una matriz anterior AST/referencias por módulo; 155 módulos y 20 colisiones en su snapshot. [RC4_SCRIPT_INVENTORY.md](https://github.com/mbalbo2023/Porota-trading/blob/0e7577fc6112406794ffbc392c902904481f8ca0/RC4_SCRIPT_INVENTORY.md) clasificó 38 scripts. Son antecedentes de otro corte, no clasificación RC6 actual. El [censo A637](https://github.com/mbalbo2023/Porota-trading/issues/909#issuecomment-6616443072) ya distinguía main/product/candidate; un conteo posterior no constituye auditoría de retiro.

**Delta por casos, sin propuestas nuevas:**

- **Yahoo:** [R182](https://github.com/mbalbo2023/Porota-trading/issues/909#issuecomment-6812216492), [R209](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6815246138), [R315c](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6842887719) ya documentaron import legacy vs egreso. [#1088 R94](https://github.com/mbalbo2023/Porota-trading/pull/1088) se fusionó al candidato en `5b8394dbd772625c4b8233b1a97c66b929b3efd1` (2026-11-10T23:21:29Z, 20:21:29 ART). Sus dos blobs aún son idénticos en el actual: `e_technical_engine.py=2afee67f52f700575b2623d2d09c0882750542c9`, `tests/test_rc6_yahoo_operational_guard.py=256c6815b126327bc51899aaaf708bd8fe9fc4d0`. R94 conserva el bloqueo en PAPER previo a caché/red; siete casos focales bajo el owner histórico `RC6_A1115_R94_YAHOO_PAPER`. `requirements.txt` aún declara >=0.2.40 y lock fija 1.7.0; el OCI legacy entrypoint→j_main→e_technical_engine todavía importa yfinance y A lo usa en import-smoke. Disposición ya aprobada: no agregar ni retirar pin a ciegas; eventual desacople necesita demostrar import/egreso/no-red por capa y exact-image en su propio scope. No se verificó tráfico Yahoo físico.
- **DATA912:** [R63](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6774295840) verificó wiring, prohibió deprecarlo infundadamente o declararlo READY; [R90](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6780350877) dejó refresh/fallback default OFF y opt-in. [R221](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6823515943) distingue GDELT tombstone de DATA912 condicionado y mantiene las fuentes con evidencia única. No reabrir ni eliminar.
- **Control-plane:** [#330](https://github.com/mbalbo2023/Porota-trading/pull/330) sí fue MERGED `a8fdccef80590688045d9c7c8d3cefab09fa7459`: API de files acredita 32 workflows retirados y tres archivos de gobierno añadidos. No volver a proponer su retiro. [#44 cierre físico histórico](https://github.com/mbalbo2023/Porota-trading/issues/44#issuecomment-6364139009): la sonda 39948288067 verificó entonces ausencia de units legacy, no la situación física actual. PRs [#436](https://github.com/mbalbo2023/Porota-trading/pull/436) y [#455](https://github.com/mbalbo2023/Porota-trading/pull/455) están CLOSED_UNMERGED; sus textos no son por sí solos prueba de integración.
- **Custodia de código faltante en refs:** [triage #909](https://github.com/mbalbo2023/Porota-trading/issues/909#issuecomment-6813684778) y [R221](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6823515943) diferenciaron material duplicado/diferente/ausente de capacidades y separaron código asociado a tests, auxiliares diferidos y rutas transitorias reales, preservando heads. No confundir las 140/144 rutas ausentes en sus diferentes cortes con los 102 módulos no trazados del producto de octubre.
- **CI:** [R292](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6837104256), [R296](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6837636683) y [R315c](https://github.com/mbalbo2023/Porota-trading/issues/1093#issuecomment-6842887719) ya comprobaron pip/BuildKit/one RELEASE y rechazaron crear un fast-path de dashboard en main: código UI sólo presente en producto, y genera rutas/contratos Python. No presentar ese atajo rechazado como idea nueva.

## C0: medida nueva frente al punto de partida, sin reconstrucción

**Muestra:** últimos 20 runs `event=pull_request` del workflow «CI — Porota Trading»: 20 SHA, 14 ramas, 40 jobs, todos CONTROL_PLANE_ONLY y run_attempt=1; desde 2026-11-12T18:16:19Z / 15:16:19 ART hasta 2026-11-14T01:31:13Z / 13-Nov 22:31:13 ART. Wall = creación del run→fin real de último job no omitido. Cola = creación→primer job. P50/P90 por nearest rank. Se midieron jobs/steps, no las esperas humanas ni Attestation independiente. Cobertura UI/DB/business no representada: NO_VERIFICADO. Linux hosted `ubuntu-latest` (Ubuntu 26.04/Python 3.11.18 en dos logs examinados), vs A/B/D `ubuntu-24.04`.

| Métrica main C0 | Resultado |
|---|---:|
| Estados y reintentos | 18 SUCCESS, 2 FAILURE, ningún attempt 2 |
| Wall p50 / p90 / rango | 42 s / 48 s / 30–52 s |
| Cola p50 / p90 | 3 s / 3 s |
| Paso «Run mandatory control-plane tests», p50 / p90 | 20 s / 22 s |
| Tiempo de runner sumado (proxy de uso; no factura) | 733 s, 12m13s |
| Primer paso fallido (dos runs) | Test de control-plane a +42 s y +46 s |
| Build/stack de aplicación ejecutados | **0/20** |

Evidencia representativa: [último CI, PR #1115](https://github.com/mbalbo2023/Porota-trading/actions/runs/43540990779), [primer fallo](https://github.com/mbalbo2023/Porota-trading/actions/runs/43463988874), [segundo fallo](https://github.com/mbalbo2023/Porota-trading/actions/runs/43494742410), [primero de la muestra](https://github.com/mbalbo2023/Porota-trading/actions/runs/43278074910). R349 modificó AGENTS/gobierno; FULL_REQUIRED deliberado y no comparable con texto editorial no sensible. El último CI reportó 3280 casos con subtests, 0 omitidos. No hay estimación monetaria, ahorro porcentual causal ni declaración de checks de rama exhaustivos.

**Últimos cinco de la rama candidata, sólo tres del SHA exacto:**

| Run | SHA | Evento / resultado | Wall hasta último job |
|---|---|---|---:|
| [43537395716](https://github.com/mbalbo2023/Porota-trading/actions/runs/43537395716) | 0e7577fc | Predeploy R252 HOLD; exact-artifact job omitido | 11s |
| [43537395711](https://github.com/mbalbo2023/Porota-trading/actions/runs/43537395711) | 0e7577fc | Candle SUCCESS; no release | 7s |
| [43537395700](https://github.com/mbalbo2023/Porota-trading/actions/runs/43537395700) | 0e7577fc | A PROBE; 1 imagen, native 1520/0, R205 privacy HOLD intencional | 20m40s |
| [43315157473](https://github.com/mbalbo2023/Porota-trading/actions/runs/43315157473) | 4fe14abd (anterior) | Predeploy HOLD rápido | 12s |
| [43292787072](https://github.com/mbalbo2023/Porota-trading/actions/runs/43292787072) | 4fe14abd (anterior) | Candle SUCCESS; no release | 10s |

Los tres runs actuales se crearon 2026-11-14T00:55:56Z / 13-Nov 21:55:56 ART. A terminó 01:16:36Z / 22:16:36 ART (workflow se actualizó un segundo después).

| Frontera | Build de image | Suite native | Condición |
|---|---:|---:|---|
| [A actual](https://github.com/mbalbo2023/Porota-trading/actions/runs/43537395700/job/132270220296) | 29s | 1043s (17m23s) | 1 PROBE efímera, 12 capas CACHED; HOLD antes de upload. |
| [B actual](https://github.com/mbalbo2023/Porota-trading/actions/runs/43539601176/job/132276792657) | 87s | 1097s (18m17s) | 1 PROBE independiente, sin caché, source 0e7577fc/upstream A43537395700, main productor db957b69. |
| [D histórico](https://github.com/mbalbo2023/Porota-trading/actions/runs/43301355473/job/131473091028) | 63s | 1041s (17m21s) | 1 RELEASE, suite ligada a ese mismo image ID. **Otro** candidato 4fe14abd y main 7718e1ed; no reutilizar para el actual. |

Main pip: 17 HIT y 1 MISS entre 18 jobs con caché, más 2 anteriores sin caché configurada. Cada HIT restauró 8.425.619 B (143.235.523 B sumados; reutilización, no ahorro causal facturado); A actual restauró 205.794.519 B. En los 18 SUCCESS se publicaron 52.960 ejecuciones acumuladas incluyendo subtests, rango 2.569–3.280 por SHA y 0 omitidos. Los dos FAIL carecen de marcador GREEN. Su resumen pytest registra, respectivamente, 1.800 PASS + 1.257 subtests PASS + 1 SKIP (guard de cero skips correctamente RED) y 1.862 PASS + 1.398 subtests PASS + 1 FAIL (aserción del contrato R321 de permisos). El denominador completo de los 20 es **59.279 resultados** acumulados incluyendo subtests: 59.277 PASS, 1 FAIL, 1 SKIP; no son casos únicos. El build A anterior tomó 214s vs 29s del actual: dos SHA/ejecuciones distintos, sin prueba controlada del ahorro neto. No confundir PROBE A/B con duplicación de la RELEASE D. [C actual](https://github.com/mbalbo2023/Porota-trading/actions/runs/43541616957/job/132283231773) falló `POSTCOMPLETION_EVENT_MISMATCH` a 01:36:47Z / 22:36:47 ART; C corrió en main11a1767, después del merge documental durante B. El texto del error es evidencia; la RCA exacta debe trazarse en su validador antes de asignarle una causa exclusiva.

## Auditoría A1115 de procedencia Python (más reciente que el censo de octubre)

[Delegación R35](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6772818980): el validador existente y su suite quedaron en scope histórico `RC6_A1115_P1_PYTHON_ARTIFACT` exclusivamente; la petición fue **cablear la función ya escrita**, no crear otro auditor. [R78](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6775770257) documentó el experimento OFFHOST de empaquetado sin tests y a su responsable histórico de cableado Python. La clasificación REVIEW_REQUIRED se conservó. [R93](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6781576814) constató el clasificador y **cero huérfanos probados**. Sus 997 Python corresponden a un corte anterior al siguiente.

La auditoría operativa que debe reutilizarse es [R110](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6783724646), afirmada por [R117](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6785050794) y [R120](https://github.com/mbalbo2023/Porota-trading/issues/732#issuecomment-6795056584). En R110, 2026-11-11T00:57:46Z / 10-Nov 21:57:46 ART, #1087 estaba en `7739379ba2f7be25bdb32c31d79f185b6b4ac942`. Recorrió únicamente entradas concretas, por instrucción explícita de no hacer una nueva auditoría masiva. Método y disposiciones:

| Universo histórico del R110/R120 | Recuento / decisión |
|---|---|
| Clasificador automático | 998 = 253 DEPENDENCY_DECLARED + 2 ENTRYPOINT_DECLARED + 4 HOST_ENTRYPOINT_DECLARED + 218 REVIEW_REQUIRED + 520 TEST_ONLY + 1 CI_ONLY. |
| Frontera PAPER/split | 245 alcanzables estáticamente; 259 al añadir host/source-cycle. |
| Entradas indirectas revisadas | 29 antes REVIEW: 14 CLI Docker/systemd, 6 contratos, 5 histórico/legacy, 4 compatibilidad. Unión dirigida = **288 conectables**. |
| Pendientes reales en esa fotografía | 189 REVIEW_REQUIRED sin profundizar, 13 wrappers de ACTIVE_SERVICE sin resolución automática. Los 710 restantes no son 710 bajas ni 710 módulos inútiles. |
| Evidencia física | Cero procesos certificados por esta auditoría estática; **0 huérfanos demostrados**. No usar el número de archivos como readiness ni autoridad para retirar. |

[Implementación en SHA actual](https://github.com/mbalbo2023/Porota-trading/blob/0e7577fc6112406794ffbc392c902904481f8ca0/scripts/porota_validate_deploy_artifact.py#L440): `python_source_provenance` se invoca en el flujo del mismo validador (L967) con [regresiones existentes](https://github.com/mbalbo2023/Porota-trading/blob/0e7577fc6112406794ffbc392c902904481f8ca0/tests/test_porota_validate_deploy_artifact.py#L145). No se reejecutó el clasificador ni sus tests aquí. La lectura del tree actual (1046 .py, 558 en tests/, 123 en scripts/) es sólo contraste de alcance con 998 del otro SHA, no reemplaza el mapa original ni transforma las 189 dudas en un mandato de trabajo. El criterio se conserva: comenzar por la frontera afectada y su evidencia previa, **no barrer 1046 paths**.

## C0 antes/ahora con A/B/D comparables

Par observado: candidato previo `4fe14abd` vs actual `0e7577fc`; A en PR y B en main para ambos; mismo Python 3.11/Ubuntu 24.04 y mismo denominador A de 9 suites/1520 ejecutados/0 omitidos. Sólo una observación por condición. Las dos fuentes y los trusted-main no son iguales; no se atribuye un ahorro causal total a caché.

| Misma etapa | Antes: 12-Nov | Ahora: 14-Nov UTC | Diferencia observada |
|---|---:|---:|---:|
| [A antes](https://github.com/mbalbo2023/Porota-trading/actions/runs/43292787056) / A ahora, wall | 25m39s | 20m40s | −4m59s |
| A pip, cierre/instalación+import | miss; 54s | hit 205.794.519 B; 37s | −17s |
| A BuildKit | 0 pasos CACHED observados; 214s | 12 pasos CACHED; 29s | −185s |
| A suite nativa | 1123s | 1043s | −80s |
| [B antes](https://github.com/mbalbo2023/Porota-trading/actions/runs/43297125572) / B ahora, wall | 20m27s | 19m58s | −29s |
| B build sin caché por contrato | 71s | 87s | **+16s** |
| B suite nativa | 1138s | 1097s | −41s |
| A→B elapsed (creación A a fin último job B) | 46m11s | 40m43s | −5m28s; −11,8% observado |
| A+B tiempo sumado de runner | 45m58s | 40m31s | −5m27s |
| Artifact público B / conteo A | 8101 B / 0 | 8106 B / 0 | +5 B en B; A mantiene salida privada bloqueada |

Antes: 2026-11-12T19:41:46Z–20:27:57Z / 16:41:46–17:27:57 ART. Ahora: 2026-11-14T00:55:56Z–01:36:39Z / 13-Nov 21:55:56–22:36:39 ART. En la cadena anterior que **sí** llegó a D, A+B+D sumaron **348s (5m48s) de build, 3302s (55m02s) de suites nativas**. A+B actual: 116s de build, 2140s de nativo, sin D comparable. El orden de magnitud confirma R292/R296/R315c, no un descubrimiento nuevo. **No puede medirse tiempo del ciclo completo actual a D/E, deploy o runtime:** no hay ese recibo para el par nuevo.

El D histórico devolvió un release, artifact ID 13982961716, 273.263.487 B, REST digest `sha256:65fc878e62e116a4e93b508b1bd36e015f53a21b6fcba351303c5aac9abb4a0d`. El E de ese mismo par retornó artifact ID 13984065411, 1064 B; no crea otra imagen. El B actual probe de 8106 B es artifact ID 14091332920, `sha256:2ae3b4f5172be23f0c28922cf2f2835e7eb43c3929af8d51b62b1ff7c7e8fc34`. Es metadata de GitHub, no descarga/validación propia de bytes ni autorización de reuso. Los D/E históricos tienen expiración REST 2026-11-19T20:51:47Z y 20:52:13Z (17:51:47 y 17:52:13 ART); el B actual 2026-11-21T01:36:36Z (20-Nov 22:36:36 ART).

La muestra contiene los 20 runs principales, cinco de la rama candidata y los tiempos de jobs y pasos de las pruebas A/B/D estudiadas. Detalla los intentos, aciertos y fallos de caché, bytes, SHA, artefactos y límites. [Datos C0 de CI](../datos/ci-c0-baseline.json) No es censo de todos los runs del repositorio, del ciclo de PR ni del coste facturado.

## Reconciliación de CI con código ya integrado

- [R269 #1104](https://github.com/mbalbo2023/Porota-trading/pull/1104) MERGED a main. `.github/workflows/ci.yml`, `scripts/rc6_main_ci_scope.py`, `.github/requirements-control-ci.txt`, `tests/test_rc6_main_ci_scope.py`: comparador del primer padre trusted con fallback FULL; CACHE pip; omite imagen/stack/WAL en APPLICATION + DOCS_ONLY, conserva tests y attestation. No generalizarlo como «todo docs sin pytest» ni extender por mero nombre de archivo.
- [R266 #1101](https://github.com/mbalbo2023/Porota-trading/pull/1101) quedó CLOSED_UNMERGED, **ambos blobs del PR idénticos** a los del candidato actual: A workflow `b9f4fbca6d48cc27ccfdb71a839853be3f04b8c5`, test `79948d63382377e28b5cf22344e0a967f0fe0ae2`. La prueba A tiene pip por lock, cache BuildKit por PR, trigger que evita rebuild por READY y cancela pruebas de HEAD supersedido. [#1102](https://github.com/mbalbo2023/Porota-trading/pull/1102) repinó B/C/D/E.
- B autentica previamente los pasos de A incluido HOLD intencional y exige reproducción propia; la lógica R251 verifica que la RELEASE se testea/guarda por su ID. Eliminar A nativo o aceptar cache de PR en B cambiaría fronteras de confianza; el tiempo mayor es de ejecución nativa, no de build. La propuesta de refactor semántico posterior ya existe en R315c: no se repropone ni implementa en R350.
- **Disposición:** conservar C1/C2 aplicados, reusar la auditoría y su decisión NO_CHANGE para el fast-path; C3 fuera del P0. Ninguna limpieza/remoción aprobada por esta evidencia. Se preservan PAPER/SHADOW, fail-closed, independencia de publisher y release, host pin y mutex global sin cancelación. No se acredita `ARTEFACTO_VALIDADO` para el nuevo par candidato/main ni `DESPLEGADO/VALIDADO_RUNTIME`.
