from pathlib import Path
import hashlib, json, os, re, stat, subprocess, sys, time
import xml.etree.ElementTree as ET
import yaml

root = Path(sys.argv[1]).resolve(strict=True)
label = sys.argv[2]
prefix = Path('/tmp') / ('rc6_governed_' + label)
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args]).decode().strip()
sha, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
def inventory():
    records = {}
    for item in subprocess.check_output(['git', '-C', str(root), 'ls-files', '-z']).split(b'\0'):
        if not item: continue
        name = item.decode()
        path = root / name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, name
        records[name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'mode': stat.S_IMODE(info.st_mode)}
    return records
assert git('status', '--porcelain', '--untracked-files=no') == ''
before = inventory()
policy = yaml.safe_load((root / 'ops/policy/test-policy.yaml').read_bytes())
scope = policy['productive_scope']
assert scope['roots'] == ['.']
assert policy['test_governance']['automatic_discovery_required'] is True
assert policy['test_governance']['manual_test_file_allowlist_as_primary_ci'] is False
args, exclusions = list(scope['roots']), []
for item in scope.get('exclusions', []):
    assert all(item.get(key) for key in ('classification', 'reason', 'owner'))
    assert (root / item['path']).is_file() and (root / item['successor']).is_file()
    args.append('--ignore=' + item['path'])
    exclusions.append('|'.join((item['path'], item['classification'], item['successor'])))
env = dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTHONPATH', None)
started = time.time()
with prefix.with_suffix('.collection.txt').open('xb') as output:
    collection_rc = subprocess.run([sys.executable, '-m', 'pytest', '--collect-only', '-q', *args], cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT).returncode
collection = prefix.with_suffix('.collection.txt').read_text()
discovered = sum(int(n) for n in re.findall(r': (\d+)$', collection, re.MULTILINE))
print(json.dumps({'phase': 'COLLECTED', 'candidate_sha': sha, 'discovered': discovered, 'rc': collection_rc}), flush=True)
if collection_rc: raise SystemExit(collection_rc)
junit = prefix.with_suffix('.xml')
assert not junit.exists()
with prefix.with_suffix('.execution.log').open('xb') as output:
    execution_rc = subprocess.run([sys.executable, '-m', 'pytest', '-q', *args, '--junitxml=' + str(junit)], cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT).returncode
doc = ET.parse(junit)
cases, suites = list(doc.iter('testcase')), list(doc.iter('testsuite'))
assert len(suites) == 1
failures = sum(c.find('failure') is not None for c in cases)
errors = sum(c.find('error') is not None for c in cases)
skips = list(doc.iter('skipped'))
xfail = sum(n.get('type') == 'pytest.xfail' for n in skips)
skipped = len(skips) - xfail
after = inventory()
changes = [name for name in before if before[name] != after.get(name)]
duplicate_count = len(cases) - len({(c.get('classname'), c.get('name')) for c in cases})
clean = git('status', '--porcelain', '--untracked-files=no') == '' and not changes
proof = {'schema_version': 1, 'scope': 'repository-root automatic pytest discovery', 'discovered': discovered, 'executed': len(cases), 'skipped': skipped, 'xfail': xfail, 'failures': failures, 'errors': errors, 'exclusions': exclusions, 'pytest_exit_code': execution_rc, 'status': 'GREEN' if execution_rc == 0 and discovered == len(cases) > 0 and not any((failures, errors, skipped, xfail, duplicate_count)) and clean else 'RED'}
prefix.with_suffix('.json').write_text(json.dumps(proof, sort_keys=True, indent=2) + '\n')
receipt = {**proof, 'candidate_sha': sha, 'candidate_tree': tree, 'acceptance': 'INTERMEDIATE_DIAGNOSTIC', 'python': sys.version, 'executable': sys.executable, 'elapsed_seconds': time.time() - started, 'tracked_files': len(before), 'source_unchanged': clean, 'source_changes': changes, 'duplicate_cases': duplicate_count, 'junit_sha256': hashlib.sha256(junit.read_bytes()).hexdigest(), 'junit_bytes': junit.stat().st_size}
prefix.with_suffix('.receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps(receipt, sort_keys=True), flush=True)
raise SystemExit(0 if proof['status'] == 'GREEN' else 1)
