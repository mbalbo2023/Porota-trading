import hashlib, importlib.metadata, json, os, pathlib, platform, re, sys, time
import xml.etree.ElementTree as ET

source = pathlib.Path('/workspace/rc6-packed-scalar-270242dd-source')
pin_path = pathlib.Path('/tmp/rc6-packed-scalar-270242dd-source-raw/source.index.json')
raw = pathlib.Path('/tmp/rc6-packed-scalar-270242dd-guards-raw')
os.umask(0o022)
pin = json.loads(pin_path.read_bytes())
installed, required, locks = {}, {}, {}
normalize = lambda name: re.sub(r'[-_.]+', '-', name).lower()
for distribution in importlib.metadata.distributions():
    name = normalize(distribution.metadata['Name'])
    assert name not in installed
    installed[name] = distribution.version
for name in ('requirements.lock.txt', 'requirements.build.lock.txt'):
    contents = (source / name).read_bytes()
    count = 0
    for line in contents.decode().splitlines():
        content = line.strip().removesuffix('\\').strip()
        match = re.fullmatch(r'([A-Za-z0-9_.-]+)==([^\s;]+)', content)
        if match is None:
            assert '==' not in content or content.startswith('#')
            continue
        key, version = normalize(match[1]), match[2]
        assert key not in required
        required[key] = version
        count += 1
    locks[name] = {'sha256': hashlib.sha256(contents).hexdigest(), 'pins': count}
assert sys.executable == '/workspace/venv_rc6_frozen311/bin/python'
assert platform.python_version() == '3.11.16'
assert len(installed) == len(required) == 157 and installed == required
assert locks['requirements.lock.txt']['pins'] == 154
assert locks['requirements.build.lock.txt']['pins'] == 3
assert pin['source_sha'] == '270242ddd9e1f1fc8c158835304dd2ca186208f2'
assert pin['overlay_count'] == 0 and type(pin['overlay_count']) is int
assert os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] == '1'
assert os.environ['PYTHONDONTWRITEBYTECODE'] == '1'
preflight = {'passed': True, 'interpreter': sys.executable, 'python': platform.python_version(),
    'distribution_count': len(installed), 'locks': locks,
    'distributions': [{'name': name, 'version': version} for name, version in sorted(installed.items())],
    'scope': 'OWN_LOCK_NAMES_AND_VERSIONS_NOT_DISTRIBUTION_BYTE_PROOF'}
(raw / 'entry-preflight.json').write_text(json.dumps(preflight, sort_keys=True, indent=2) + '\n')
sys.path.insert(0, str(source))
from scripts import rc6_capture_restore_diagnostic as diagnostic
before = diagnostic._source_inventory(source, pin)
nodes = ['tests/test_rc6_packed_scalar_dispatch.py', 'tests/test_rc6_packed_volatile_scalars.py', 'tests/test_rc6_packed_small_container.py', 'tests/test_rc6_packed_capture_allocations.py', 'tests/test_rc6_packed_storage.py',
         'tests/test_rc6_funnel_storage_codec.py']
pytest_argv = ['-q', '-p', 'no:cacheprovider', *nodes,
    '--basetemp=/workspace/rc6-packed-scalar-270242dd-fixtures', '--junitxml=' + str(raw / 'guards.xml')]
print(json.dumps({'event': 'START_NATIVE_GUARDS', 'pid': os.getpid(),
    'source_sha': pin['source_sha'], 'nodes': nodes, 'distribution_count': 157}, sort_keys=True), flush=True)
started = time.monotonic()
with diagnostic._offline(pathlib.Path('/workspace/rc6-canonical-400a677c-big')) as attempts:
    import pytest
    returncode = pytest.main(pytest_argv)
elapsed = time.monotonic() - started
imports, alien = [], []
for name, module in sorted(sys.modules.items()):
    path = getattr(module, '__file__', None)
    if not path:
        continue
    path = pathlib.Path(path).resolve()
    expected = source.joinpath(*name.split('.'))
    if path.is_relative_to(source) or expected.with_suffix('.py').is_file() or (expected / '__init__.py').is_file():
        record = {'module': name, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        imports.append(record)
        if not path.is_relative_to(source):
            alien.append(record)
        else:
            assert record['sha256'] == pin['files'][str(path.relative_to(source))]
after = diagnostic._source_inventory(source, pin)
xml = ET.parse(raw / 'guards.xml')
counts = {key: sum(int(suite.attrib[key]) for suite in xml.iter('testsuite'))
          for key in ('tests', 'failures', 'errors', 'skipped')}
result = {'schema': 'rc6.packed-scalar-dispatch-native-focal.v1', 'source_sha': pin['source_sha'],
    'source_tree': pin['source_tree'], 'source_files': len(before), 'source_tar_sha256': pin['tar_sha256'],
    'source_index_sha256': hashlib.sha256(pin_path.read_bytes()).hexdigest(), 'source_unchanged': before == after,
    'source_binding': 'EVERY_GIT_FILE_SHA256_MODE_AND_BLOB_ID', 'overlay_count': 0,
    'preflight': preflight, 'returncode': int(returncode), 'elapsed_seconds': elapsed,
    'argv': sys.argv, 'pytest_argv': pytest_argv, 'pid': os.getpid(), 'attempts': attempts,
    'imports': imports, 'alien_imports': alien, 'junit': counts,
    'junit_sha256': hashlib.sha256((raw / 'guards.xml').read_bytes()).hexdigest(),
    'scope': 'EXACT_SCALAR_TERMINAL_OPERATIONS_ORDER_CUTS_WIRE_AND_EXISTING_NATIVE_WRITER_READER_PROJECTION_GUARDS',
    'data400_opened': False, 'publisher_performance_measured': False, 'acceptance_complete': False}
(raw / 'receipt.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('source_sha', 'source_files', 'source_unchanged',
    'returncode', 'elapsed_seconds', 'pid', 'attempts', 'alien_imports', 'junit', 'junit_sha256')}, sort_keys=True), flush=True)
raise SystemExit(int(returncode != 0 or before != after or bool(alien) or any(attempts.values())))
