from pathlib import Path
p=Path('/workspace/scratch/88594b90c2a3/diag3-624/.github/workflows/rc6-market-watch-readonly.yml')
s=Path('/workspace/scratch/88594b90c2a3/old-ab-workflow624.yml').read_text()
s=s.replace('timeout-minutes: 20','timeout-minutes: 35',1)
s=s.replace('202e49c750ab0a69b5ba6790fcb14cc0c0d9039f','7ce63ec6b3b65a0d39a93c11968d97dc510f1c02').replace('d1bd3127d051f1a01fe57f742fbded1a4f216a48','889c7b4dd50b0ac7dcf18acef109ac7aab126f5a')
s=s.replace('1425a3824ce6a4bf25b910013eed4adda998ef27','b18f770a5a64067389e51f7373b3304c4975ceeb').replace('12123121595','12132052630').replace('511a06390863d6a987958e057d696a301614ba539d9d006f2fe729941e1208f7','3d4599677ca814bd05a7249f78380e705bdd742dbb1a7bf7c86a689492021312').replace('f3ddca733e40649c4e2605f69d5b7ec59dd839e8','df970bae3415333d43c7c6a30442f6962188ae26')
a=s.index('          cmp baseline624/');b=s.index('          install -d -m777',a)
s=s[:a]+'''          cp "${native[0]}" baseline624/rc6_shadow_runtime/
          mkdir -p "$RUNNER_TEMP/ab624-build"
          docker build --target rc6-json-bound-build --iidfile "$RUNNER_TEMP/ab624-build/image-id.txt" \\
            --tag "rc6-a3-codec-control:$GITHUB_RUN_ID" candidate624 > "$RUNNER_TEMP/ab624-build/build.log" 2>&1
          cid="$(docker create "rc6-a3-codec-control:$GITHUB_RUN_ID")"
          trap 'docker rm -f "$cid" >/dev/null 2>&1 || true' EXIT
          docker cp "$cid:/out/." "$RUNNER_TEMP/ab624-build/"
          docker rm "$cid" >/dev/null
          trap - EXIT
          cp "$RUNNER_TEMP/ab624-build/_rc6_json_bound.so" candidate624/rc6_shadow_runtime/
          test "$(sha256sum baseline624/rc6_shadow_runtime/_rc6_json_bound.so | cut -d' ' -f1)" != "$(sha256sum candidate624/rc6_shadow_runtime/_rc6_json_bound.so | cut -d' ' -f1)"
          cmp baseline624/requirements.lock.txt candidate624/requirements.lock.txt
''' + s[b:]
s=s.replace("paths += [str(p.relative_to(root))", "paths += ['rc6_shadow_runtime/_rc6_json_bound.c','Dockerfile','requirements.lock.txt']\n              paths += [str(p.relative_to(root))")
s=s.replace('          docker run --rm --pull never --memory 512m', '          name="rc6-ab624-focal-$GITHUB_RUN_ID"\n          docker create --name "$name" --pull never --memory 512m',1)
s=s.replace('--network none --read-only --cap-drop ALL --security-opt no-new-privileges --user 1000:1000 \\\n            --tmpfs', '--network none --read-only --cap-drop ALL --security-opt no-new-privileges --user 1000:1000 \\\n            --pids-limit 128 -e PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 -e TMPDIR=/evidence/focal-tmp \\\n            --tmpfs',1)
s=s.replace('          python3 -c \'import shutil,sys;', '          install -d -m777 "$RUNNER_TEMP/ab624-evidence/focal-tmp"\n          python3 -c \'import shutil,sys;',1)
s=s.replace('            tests/test_rc6_deploy_generation_gate.py tests/test_rc6_deploy_quiescence.py\n', '''            tests/test_rc6_deploy_generation_gate.py tests/test_rc6_deploy_quiescence.py \\
            tests/test_rc6_shadow_cold_audit.py tests/test_rc6_postdeploy_stress_contract.py \\
            tests/test_rc6_shadow_full_catalog.py tests/test_bv_paper_runtime.py
          set +e
          timeout 900 docker start -a "$name" > "$RUNNER_TEMP/ab624-evidence/focal.log" 2>&1
          rc=$?
          set -e
          docker inspect "$name" > "$RUNNER_TEMP/ab624-evidence/focal-container.json"
          cat "$RUNNER_TEMP/ab624-evidence/focal.log"
          test "$rc" -eq 0
          docker rm "$name" >/dev/null
''')
s=s.replace('--tmpfs /tmp:rw,nosuid,nodev,size=64m --workdir /experiment -e PYTHONHASHSEED=0', '--pids-limit 128 -e PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 -e TMPDIR=/tmp \\\n                --tmpfs /tmp:rw,nosuid,nodev,size=64m --workdir /experiment -e PYTHONHASHSEED=0')
s=s.replace("values=[json.loads((root/(prefix+arm+'-container.json')).read_text())[0] for prefix in ('','legacy-') for arm in ('baseline','candidate')]", "values=[json.loads((root/(prefix+arm+'-container.json')).read_text())[0] for prefix in ('','legacy-') for arm in ('baseline','candidate')]\n          values += [json.loads((root/'focal-container.json').read_text())[0]]")
s=s.replace("assert h['NetworkMode']=='none'", "assert h['PidsLimit']==128 and set(h['CapDrop'])=={'ALL'}\n              assert h['NetworkMode']=='none'")
s=s.replace('name: rc6-progressive624-controlled-ab-', 'name: rc6-a3-624-singlepass-abi-ab-')
s=s.replace('            ${{ runner.temp }}/ab624-validated/byte-validation.json','''            ${{ runner.temp }}/ab624-validated/byte-validation.json
            ${{ runner.temp }}/ab624-build/
            baseline624/ab624-source-manifest.json
            candidate624/ab624-source-manifest.json''')
s=s.replace('run: docker rm -f "rc6-ab624-baseline-', 'run: docker rm -f "rc6-ab624-focal-$GITHUB_RUN_ID" "rc6-ab624-baseline-')
s=s.replace('if: false # bounded native202e RCA39096006422 captured; no repeated host observation', 'if: false # A3 OFFHOST ABI control only; no Droplet action')
p.write_text(s)
