"""Finite whole-worker A/B: actual immutable inputs; no local host certificate."""
import gc,gzip,hashlib,importlib.util,json,os,resource,shutil,sys,time
from pathlib import Path
from datetime import timedelta
root,database,output,binary=map(lambda x:Path(x).resolve(),sys.argv[1:5])
deferred,legacy=sys.argv[5:7]==['deferred','legacy'],sys.argv[6]=='legacy'
deferred=sys.argv[5]=='deferred'
sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('rc6_shadow_runtime._rc6_json_bound',binary)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);sys.modules[spec.name]=module
from rc6_shadow_runtime import worker as runtime
from rc6_shadow_runtime.persistence import read_committed_generation,EvidenceFiles,digest
from tests.test_rc6_shadow_runtime_wiring import PRE
assert Path(runtime.__file__).resolve().is_relative_to(root)
output.mkdir(exist_ok=False)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while b:=stream.read(65536):h.update(b)
 return h.hexdigest()
manifest={str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*.py'))}
manifest['rc6_shadow_runtime/_rc6_json_bound.c']=sha(root/'rc6_shadow_runtime/_rc6_json_bound.c')
(output/'source-manifest.json').write_text(json.dumps(manifest,sort_keys=True)+'\n')
r={'schema':'rc6.a3-worker-local-controlled.v1','scope':'LOCAL_AB_NOT_EXACT_RELEASE_ABI_OR_HOST_CGROUP_CERTIFICATE',
 'root':str(root),'deferred':deferred,'legacy':legacy,'database':str(database),'database_inode':database.stat().st_ino,
 'database_sha256':sha(database),'python':sys.version,'backend_sha256':sha(binary),'backend_source_sha256':manifest['rc6_shadow_runtime/_rc6_json_bound.c'],'ticks':[]}
if legacy:
 seed=Path('/workspace/scratch/88594b90c2a3/paired-progressive-cpu624-baseline/shadow')
 assert (seed/'checkpoint.json.gz').read_bytes()[:4]==b'\x1f\x8b\x08\x00'
 r['legacy_seed_sha256']={p.name:sha(p) for p in seed.iterdir() if p.is_file()}
 shutil.copytree(seed,output/'shadow')
kwargs={'spool_audit':True}
if deferred:kwargs['defer_audit']=True
worker=runtime.ShadowRuntime(database,evidence_root=output/'shadow',source_roots=[],**kwargs)
for offset in ((86460,86490,172860,172890) if legacy else (0,30,86400,86430)):
 at=PRE+timedelta(seconds=offset)
 wall,cpu=time.monotonic(),time.process_time();report=worker.tick(at)
 cut=read_committed_generation(worker.root)
 hot_cpu,hot_wall=time.process_time()-cpu,time.monotonic()-wall
 row={'source_as_of':at.isoformat(),'hot_cpu':hot_cpu,'hot_wall':hot_wall,'timing':cut['status']['generation_timing'],
  'ready_count':cut['status']['catalog_ready_count'],'engines':len(report['engines']),
  'funnel':{'checkpoint_sha256':report['operational_funnel']['checkpoint_sha256'],
            'sessions':report['operational_funnel']['sessions_retained']}}
 computed=cut['report']['computed_report'];del report,cut
 cold_cpu=cold_wall=0
 if deferred:
  from rc6_shadow_runtime.cold_audit import drain,prune_completed,Directory
  cw,cc=time.monotonic(),time.process_time()
  with worker.files as files:
   complete=drain(files);prune_completed(files)
   with Directory(files) as d:
    queue=d.read('queue.json');m=d.read('manifest-'+queue['snapshot_id']+'.json')
    row['snapshot_bytes']=m['pack_bytes']
  cold_cpu,cold_wall=time.process_time()-cc,time.monotonic()-cw
  assert complete['state']=='COMPLETE' and complete['source_as_of']==at.isoformat()
  computed=complete['computed_report'];row['completion']=complete
 row.update(cold_cpu=cold_cpu,cold_wall=cold_wall,cpu=hot_cpu+cold_cpu,wall=hot_wall+cold_wall,computed=computed,
            peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
 # Independent actual full bytes for EACH cut, outside measured worker time.
 h,n=hashlib.sha256(),0
 with gzip.open(worker.root/computed['file'],'rb') as stream:
  while b:=stream.read(65536):h.update(b);n+=len(b)
 assert n==computed['raw_bytes'] and n>100*1024**2 and h.hexdigest()==computed['sha256']
 row['raw_independent_verification']={'bytes':n,'sha256':h.hexdigest()}
 h=hashlib.sha256()
 with gzip.open(worker.root/'checkpoint.json.gz','rb') as stream:
  while b:=stream.read(65536):h.update(b)
 row['checkpoint_raw_sha256']=h.hexdigest()
 with worker.files as files:
  latest=files.read('latest.json.gz');latest['computed_report']=computed
  row['normalized_operational_sha256']=digest(latest)
  del latest
 assert row['ready_count']==9902 and row['engines']==2
 gc.collect();row['idle']=runtime.release_idle_heap()
 r['ticks'].append(row);(output/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:row[k] for k in ['source_as_of','hot_cpu','cold_cpu','cpu','peak_rss_kib']}),flush=True)
assert r['database_sha256']==sha(database)
assert manifest=={**{str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*.py'))},'rc6_shadow_runtime/_rc6_json_bound.c':sha(root/'rc6_shadow_runtime/_rc6_json_bound.c')}
