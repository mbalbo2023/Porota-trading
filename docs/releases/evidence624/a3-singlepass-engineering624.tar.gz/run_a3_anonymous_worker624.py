import json,os,subprocess,sys
from pathlib import Path
root=Path('/workspace/scratch/88594b90c2a3');results=[]
for legacy in (False,True):
 receipts=[]
 for arm,code,binary in [('baseline','fix9-624','fix6-624/rc6_shadow_runtime/_rc6_json_bound.so'),('candidate','fix10-624','a3-product-native312624.so')]:
  mode='legacy' if legacy else 'fresh';out=root/f'a3-worker-anonymous-{mode}-{arm}624';assert not out.exists()
  with (root/(out.name+'.log')).open('w') as log:
   p=subprocess.run([sys.executable,'-B',str(root/'bench_a3_worker624.py'),str(root/code),str(root/'shared624.db'),str(out),str(root/binary),'deferred' if arm=='candidate' else 'sync',mode],env=dict(os.environ,PYTHONHASHSEED='0'),stdout=log,stderr=subprocess.STDOUT)
  if p.returncode:print(json.dumps({'arm':arm,'mode':mode,'exit':p.returncode}),flush=True);raise SystemExit(p.returncode)
  receipts.append(json.loads((out/'receipt.json').read_text()));print(json.dumps({'arm':arm,'mode':mode,'cuts':len(receipts[-1]['ticks'])}),flush=True)
 b,a=receipts
 assert all(b[k]==a[k] for k in ('database','database_inode','database_sha256','python','legacy'))
 if legacy:assert b['legacy_seed_sha256']==a['legacy_seed_sha256']
 for x,y in zip(b['ticks'],a['ticks']):
  assert all(x[k]==y[k] for k in ('source_as_of','ready_count','engines','funnel','raw_independent_verification','checkpoint_raw_sha256','normalized_operational_sha256'))
  assert x['computed']==y['computed']
 hot=sum(x['hot_cpu'] for x in a['ticks'])/sum(x['cpu'] for x in b['ticks'])
 total=sum(x['cpu'] for x in a['ticks'])/sum(x['cpu'] for x in b['ticks'])
 peak=max(x['peak_rss_kib'] for x in a['ticks']);cold=max(x['cold_wall'] for x in a['ticks'])
 result={'mode':'legacy' if legacy else 'fresh','hot_cpu_ratio':hot,'total_cpu_ratio':total,'candidate_peak_rss_kib':peak,'maximum_cold_wall':cold,
  'admitted':hot<=.80 and total<=1.30 and peak<=192*1024 and cold<=30,'exact_full_hash_checkpoint_and_business_parity':True}
 results.append(result);print(json.dumps(result),flush=True)
summary={'schema':'rc6.a3-whole-worker-local-admission.v1','limits':{'hot_cpu_ratio':.8,'total_cpu_ratio':1.3,'rss_kib':192*1024,'cold_wall_seconds':30},'status':'GREEN_LOCAL_ONLY' if all(x['admitted'] for x in results) else 'RED_ADMISSION','native_host_acceptance':False,'local_docker_limit_certificate':False,'results':results}
(root/'a3-worker-anonymous-summary624.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
raise SystemExit(0 if summary['status']=='GREEN_LOCAL_ONLY' else 2)
