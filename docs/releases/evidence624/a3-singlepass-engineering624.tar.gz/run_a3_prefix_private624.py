"""One isolated process tree. Export immutable evidence only after workers stop."""
import hashlib,json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path('/workspace/scratch/88594b90c2a3')
PRIVATE=Path(tempfile.mkdtemp(prefix='rc6-a3-prefix-private-',dir='/tmp'))
EXPORT=ROOT/'a3-prefix-private-export624'
assert not EXPORT.exists(),'NO_PRIOR_OUTPUT_REUSE'
assert PRIVATE.stat().st_mode&0o077==0
assert PRIVATE.stat().st_dev==ROOT.stat().st_dev,'FILESYSTEM_DEVICE_MISMATCH'
results=[];receipts={};failure=None
limits={'hot_cpu_ratio':.8,'total_cpu_ratio':1.3,'rss_kib':192*1024,'cold_wall_seconds':30}
started=time.monotonic()
try:
 for legacy in (False,True):
  mode='legacy' if legacy else 'fresh';pair=[]
  for arm,code,binary in [('baseline','fix9-624','fix6-624/rc6_shadow_runtime/_rc6_json_bound.so'),('candidate','fix10-624','a3-prefix-native312624.so')]:
   output=PRIVATE/f'{mode}-{arm}';logfile=PRIVATE/f'{mode}-{arm}.log'
   command=[sys.executable,'-B',str(ROOT/'bench_a3_worker624.py'),str(ROOT/code),str(ROOT/'shared624.db'),str(output),str(ROOT/binary),'deferred' if arm=='candidate' else 'sync',mode]
   with logfile.open('w') as log:
    process=subprocess.Popen(command,env=dict(os.environ,PYTHONHASHSEED='0'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
    for line in process.stdout:
     log.write(line);log.flush()
     try:row=json.loads(line)
     except json.JSONDecodeError:continue
     print(json.dumps({'phase':'CUT_COMPLETE','mode':mode,'arm':arm,**row}),flush=True)
    process.wait()
   if process.returncode:
    failure={'mode':mode,'arm':arm,'exit':process.returncode,'log':logfile.name}
    raise RuntimeError('PRIVATE_CONTROL_CHILD_FAILED')
   receipt=json.loads((output/'receipt.json').read_text());assert len(receipt['ticks'])==4
   pair.append(receipt);receipts[mode+'-'+arm]=receipt
   print(json.dumps({'phase':'ARM_COMPLETE','mode':mode,'arm':arm,'cuts':len(receipt['ticks'])}),flush=True)
  baseline,candidate=pair
  for key in ('database','database_inode','database_sha256','python','legacy'):
   assert baseline[key]==candidate[key],('CONTROL_MISMATCH',key)
  if legacy:assert baseline['legacy_seed_sha256']==candidate['legacy_seed_sha256']
  for old,new in zip(baseline['ticks'],candidate['ticks']):
   for key in ('source_as_of','ready_count','engines','funnel','raw_independent_verification','checkpoint_raw_sha256','normalized_operational_sha256'):
    assert old[key]==new[key],('EQUIVALENCE_MISMATCH',key)
   assert old['computed']==new['computed'],'FULL_AUDIT_METADATA_MISMATCH'
  baseline_cpu=sum(x['cpu'] for x in baseline['ticks'])
  hot=sum(x['hot_cpu'] for x in candidate['ticks'])/baseline_cpu
  total=sum(x['cpu'] for x in candidate['ticks'])/baseline_cpu
  peak=max(x['peak_rss_kib'] for x in candidate['ticks']);cold=max(x['cold_wall'] for x in candidate['ticks'])
  result={'mode':mode,'hot_cpu_ratio':hot,'total_cpu_ratio':total,'candidate_peak_rss_kib':peak,'maximum_cold_wall':cold,
    'admitted':hot<=limits['hot_cpu_ratio'] and total<=limits['total_cpu_ratio'] and peak<=limits['rss_kib'] and cold<=limits['cold_wall_seconds'],
    'exact_full_hash_checkpoint_and_business_parity':True}
  results.append(result);print(json.dumps({'phase':'MODE_COMPLETE',**result}),flush=True)
except Exception as exc:
 failure={**(failure or {}),'error_class':type(exc).__name__,'error':str(exc)}
finally:
 summary={'schema':'rc6.a3-private-local-admission.v1','scope':'LOCAL_SAME_DEVICE_PRIVATE_TMP_SERIAL_EXECUTION_NOT_HOST_OR_DOCKER_CERTIFICATE',
  'status':'RED_EXECUTION' if failure else 'GREEN_LOCAL_ONLY' if len(results)==2 and all(x['admitted'] for x in results) else 'RED_ADMISSION',
  'limits':limits,'results':results,'failure':failure,'private_root':str(PRIVATE),'private_mode':oct(PRIVATE.stat().st_mode&0o777),
  'filesystem_device':PRIVATE.stat().st_dev,'workspace_device':ROOT.stat().st_dev,'concurrent_local_exec_commands':False,
  'native_host_acceptance':False,'local_docker_limit_certificate':False,'elapsed_seconds':time.monotonic()-started,
  'all_sixteen_full_audits_verified':len(receipts)==4 and all(len(v['ticks'])==4 for v in receipts.values())}
 (PRIVATE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 # No live worker remains. Historical exported file inode identities retain
 # the actual measured original values; this copy is not a live health read.
 shutil.copytree(PRIVATE,EXPORT)
 exported=[]
 for path in sorted(PRIVATE.rglob('*')):
  if not path.is_file():continue
  relative=path.relative_to(PRIVATE);h=hashlib.sha256()
  with path.open('rb') as stream:
   while block:=stream.read(65536):h.update(block)
  measured=h.hexdigest();target=EXPORT/relative;other=hashlib.sha256()
  with target.open('rb') as stream:
   while block:=stream.read(65536):other.update(block)
  assert other.hexdigest()==measured,('EXPORT_BYTE_MISMATCH',str(relative))
  st=path.stat();exported.append({'path':str(relative),'bytes':st.st_size,'sha256':measured,'original_inode':st.st_ino,'original_device':st.st_dev})
 (EXPORT/'EXPORT-MANIFEST.json').write_text(json.dumps({'schema':'rc6.immutable-historical-export.v1','original_root':str(PRIVATE),'files':exported,'all_bytes_verified':True,'live_runtime_claim':False},indent=2)+'\n')
 print(json.dumps({'phase':'FINAL','export':str(EXPORT),'export_files':len(exported),**summary}),flush=True)
raise SystemExit(0 if summary['status']=='GREEN_LOCAL_ONLY' else 2)
