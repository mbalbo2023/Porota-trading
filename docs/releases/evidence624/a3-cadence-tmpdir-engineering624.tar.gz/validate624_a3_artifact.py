"""Independent byte inspection of the frozen ZIP; never loads/rebuilds an image."""
import argparse,gzip,hashlib,json,math,re,shutil,subprocess,tarfile,xml.etree.ElementTree as ET,zipfile
from datetime import datetime,timedelta
from pathlib import Path,PurePosixPath

def sha_stream(stream):
    h=hashlib.sha256()
    while block:=stream.read(1048576):h.update(block)
    return h.hexdigest()
def sha(path):
    with Path(path).open('rb') as stream:return sha_stream(stream)
def junit(raw):
    root=ET.fromstring(raw);cases=list(root.iter('testcase'))
    return {'cases':len(cases),**{kind:sum(len(list(c.iter(kind))) for c in cases) for kind in ('failure','error','skipped')},
            'xml_sha256':hashlib.sha256(raw).hexdigest()}
def physical_cadence(value,mode,source,tree):
    """Independently recompute the physical source clock; never trust reported ages."""
    assert value['status']=='GREEN' and value['cadence_mode']==mode
    assert value['source_sha']==source and value['candidate_tree']==tree
    assert type(value['required_generations']) is int and value['required_generations']==12
    assert type(value['observed_publications']) is int and value['observed_publications']==12
    assert len(value['cuts'])==12 and value['catalog_count']==14611 and value['ready_fixture_count']==9902
    assert type(value['nice']) is int and value['nice']==10
    assert type(value['process_peak_rss_kib']) is int and 0<value['process_peak_rss_kib']<=192*1024
    assert type(value['real_orders_sent']) is int and value['real_orders_sent']==0
    assert type(value['provider_requests']) is int and value['provider_requests']==0
    assert value['real_routes']=='NOT_CALLED' and value['database_unchanged'] is True
    assert value['production_data_mounted'] is False and value['actual_market_acceptance'] is False
    assert value['native_host_acceptance'] is False
    db=value['fixture_database'];assert db['path'] and type(db['inode']) is int and db['inode']>0
    assert re.fullmatch('[0-9a-f]{64}',db['sha256'])
    start=value['measurement_started_monotonic'];elapsed=value['elapsed_seconds']
    assert type(start) in (int,float) and math.isfinite(start)
    assert type(elapsed) in (int,float) and math.isfinite(elapsed) and elapsed>=330
    origin=datetime.fromisoformat(value['source_origin']);assert origin.tzinfo is not None
    prior=None;ids=set();last_observed=None
    for cut in value['cuts']:
        at=datetime.fromisoformat(cut['as_of']);assert at.tzinfo is not None
        timing=cut['worker_timing'];assert type(timing['poll_seconds']) is int and timing['poll_seconds']==30
        tick=timing['tick_seconds'];assert type(tick) in (int,float) and 0<tick<=30
        budget=min(120,2*(30+tick));assert cut['freshness_budget_seconds']==budget
        gid=cut['generation_id'];manifest=cut['manifest_sha256']
        assert re.fullmatch('[0-9a-f]{64}',gid) and re.fullmatch('[0-9a-f]{64}',manifest)
        assert gid not in ids;ids.add(gid)
        audit=cut['cold_audit'];computed=audit['computed_report']
        assert audit['state']=='COMPLETE' and audit['source_as_of']==cut['as_of']
        assert type(audit['wall_seconds']) in (int,float) and math.isfinite(audit['wall_seconds']) and 0<=audit['wall_seconds']<=30
        assert type(computed['raw_bytes']) is int and computed['raw_bytes']==cut['computed_report_raw_bytes']>100*1024**2
        assert re.fullmatch('[0-9a-f]{64}',computed['sha256']) and computed['sha256']==cut['computed_report_sha256']
        pub=cut['actual_publication'];obs=cut['physical_observation']
        assert all(pub[k]==cut[k] for k in ('generation_id','sequence','manifest_sha256'))
        assert pub['source_as_of']==cut['as_of'] and obs['source_as_of']==cut['as_of']
        assert obs['freshness_budget_seconds']==budget
        before,after,observed=pub['before'],pub['after'],obs['observation_monotonic']
        assert all(type(v) in (int,float) and math.isfinite(v) for v in (before,after,observed,obs['publication_monotonic']))
        assert start<=before<=after==obs['publication_monotonic']<=observed<=start+elapsed+0.001
        p_age=(origin+timedelta(seconds=after-start)-at).total_seconds()
        o_age=(origin+timedelta(seconds=observed-start)-at).total_seconds()
        assert 0<=p_age<=o_age<=budget
        assert abs(obs['publication_source_age_seconds']-p_age)<1e-5
        assert abs(obs['observed_source_age_seconds']-o_age)<1e-5
        if prior is not None:
            previous_cut,previous_observed=prior
            previous_at=datetime.fromisoformat(previous_cut['as_of'])
            assert (at-previous_at).total_seconds()>=30
            assert cut['sequence']>previous_cut['sequence'] and after>previous_observed
            previous_age=(origin+timedelta(seconds=after-start)-previous_at).total_seconds()
            assert 0<=previous_age<=previous_cut['freshness_budget_seconds']<=120
            assert abs(obs['previous_age_at_publication_seconds']-previous_age)<1e-5
        else:
            assert 'previous_age_at_publication_seconds' not in obs
        prior=(cut,observed);last_observed=observed
    assert elapsed+0.001>=last_observed-start
    if mode=='legacy':
        seed=value['legacy_seed'];assert seed['standard_gzip'] is True
        assert seed['raw_before']==seed['raw_after'] and seed['raw_before']['bytes']>0
        assert re.fullmatch('[0-9a-f]{64}',seed['raw_before']['sha256'])
        assert value['first_checkpoint_reused'] is True
        assert origin==datetime.fromisoformat(seed['source_as_of'])+timedelta(seconds=30)
    return {'mode':mode,'source':source,'tree':tree,'cuts':len(ids),'elapsed_seconds':elapsed,
            'peak_rss_kib':value['process_peak_rss_kib'],'database':db,
            'last_observation_monotonic':last_observed,'last_sequence':prior[0]['sequence']}
def main():
    p=argparse.ArgumentParser();p.add_argument('--zip',type=Path,required=True);p.add_argument('--digest',required=True)
    p.add_argument('--sha',required=True);p.add_argument('--tree',required=True);p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--abi-reference',type=Path,required=True);p.add_argument('--codec-reference',type=Path,required=True);p.add_argument('--codec-control',type=Path,required=True);args=p.parse_args()
    digest=sha(args.zip);assert digest==args.digest.removeprefix('sha256:'),'ZIP_DIGEST_MISMATCH'
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    receipt={'schema':'rc6.frozen624.a3-independent-byte-validation.v2','candidate_sha':args.sha,'candidate_tree':args.tree,
             'zip_sha256':digest,'zip_bytes':args.zip.stat().st_size,'droplet_touched':False}
    with zipfile.ZipFile(args.zip) as archive:
        members=archive.infolist();assert len(members)<1000
        for m in members:
            path=PurePosixPath(m.filename);assert not path.is_absolute() and '..' not in path.parts
        def member(name):
            found=[m for m in members if PurePosixPath(m.filename).name==name and not m.is_dir()]
            assert len(found)==1,('MEMBER_CARDINALITY',name,len(found));return found[0]
        def read(name,limit=8*1024**2):
            m=member(name);assert m.file_size<=limit,('MEMBER_LIMIT',name,m.file_size)
            return archive.read(m)
        def data(name):return json.loads(read(name))
        frozen=data('porota-frozen-candidate.json');manifest=data('porota-deploy-bundle-v2-manifest.json')
        assert frozen['candidate_sha']==args.sha and frozen['candidate_tree_sha']==args.tree
        assert frozen['paper_mode_required']=='PRODUCTION_PAPER' and type(frozen['real_orders_sent_required']) is int and frozen['real_orders_sent_required']==0
        assert frozen['build_once'] is True and frozen['real_order_capability_required']=='BLOCKED'
        receipt['frozen']=frozen
        for name in ('porota-predeploy-image.tar.gz','porota-deploy-bundle-v2.tgz'):
            with archive.open(member(name)) as source,(out/name).open('wb') as target:shutil.copyfileobj(source,target,1048576)
        assert sha(out/'porota-predeploy-image.tar.gz')==frozen['image_tar_sha256']
        assert sha(out/'porota-deploy-bundle-v2.tgz')==manifest['bundle_sha256']
        governed=data('porota-governed-tests.json');root_xml=junit(read('porota-governed-tests.xml'))
        assert governed['discovered']==governed['executed']==root_xml['cases']>0
        assert all(governed[k]==0 for k in ('failures','errors','skipped','xfail'))
        assert all(root_xml[k]==0 for k in ('failure','error','skipped'))
        assert len(governed['exclusions'])==1
        receipt['governed_tests']=governed;receipt['root_junit']=root_xml
        receipt['native_bound']=junit(read('native-bound.xml'))
        native_names={x.attrib['name'] for x in ET.fromstring(read('native-bound.xml')).iter('testcase')}
        required_native={'test_storage_capture_has_one_actual_value_walk','test_soft_nonfit_restores_memo_after_encoding_actual_partial_values','test_batch_nonfit_restores_only_failed_item_and_keeps_accepted_prefix','test_mutable_capture_has_no_path_and_seal_links_same_inode',
            'test_anonymous_link_capability_for_current_uid_without_capabilities',
            'test_native_capability_probe_uses_only_its_owned_fixture_directory',
            'test_deferred_hot_profile_never_contains_previous_cold_encode_cost',
            'test_original_measured_pair_rejects_at_unchanged_120s_ceiling',
            'test_each_adverse_cut_revokes_whole_cadence_series'}
        required_native.add('test_owned_batch_materializes_only_retained_detail_hashes_and_same_full_state')
        assert required_native <= native_names, 'A3_NEW_NATIVE_CASES_REQUIRED'
        receipt['new_native_cases']=sorted(required_native)
        assert receipt['native_bound']['cases']>=120 and all(receipt['native_bound'][k]==0 for k in ('failure','error','skipped'))
        catalog=data('full-catalog.json');assert catalog['catalog_count']==14611 and catalog['ready_fixture_count']==9902
        assert len(catalog['cuts'])==2 and catalog['cuts'][1]['sequence']>catalog['cuts'][0]['sequence']
        assert catalog['process_peak_rss_kib']<=192*1024
        assert catalog['real_orders_sent']==catalog['provider_requests']==0
        for cut in catalog['cuts']:
            audit=cut['cold_audit']; assert audit['state']=='COMPLETE'
            assert audit['wall_seconds']<=30 and audit['source_as_of']==cut['as_of']
            assert cut['computed_report_raw_bytes']>100*1024**2
            assert audit['computed_report']['sha256']==cut['computed_report_sha256']
            assert audit['computed_report']['raw_bytes']==cut['computed_report_raw_bytes']
        receipt['native_catalog']=catalog
        fresh=data('cadence-fresh.json');legacy=data('cadence-legacy.json')
        fresh_verified=physical_cadence(fresh,'fresh',args.sha,args.tree)
        legacy_verified=physical_cadence(legacy,'legacy',args.sha,args.tree)
        assert fresh_verified['database']==legacy_verified['database'], 'PHYSICAL_STAGE_DATABASE_IDENTITY_CHANGED'
        assert fresh['legacy_seed'] is None and fresh['first_checkpoint_reused'] is False
        assert legacy['legacy_seed']['source_as_of']==fresh['cuts'][-1]['as_of'], 'LEGACY_NOT_SEEDED_FROM_FRESH_LAST_CUT'
        receipt['physical_cadence']={'fresh':fresh_verified,'legacy':legacy_verified,
            'status':'GREEN_24_ACTUAL_CUTS_EXACT_IMAGE_CI_ONLY_NOT_DROPLET'}
        stress=data('stress.json');assert stress['status']=='GREEN' and stress['smoke'] is False
        assert stress['session']['simulated_minutes']==405
        assert stress['session']['real_orders_sent']==stress['session']['provider_requests']==0
        expected={'sql_shadow_wal','publication_io_identity','signals_risk_exit_ledger','sources_readiness_network',
                  'scalping_capacity','treasury_caucion','dashboard_auth_52','scheduler_monitor_backup'}
        assert {row['name'] for row in stress['scenarios']}==expected and len(stress['scenarios'])==8
        groups=[]
        for row in stress['scenarios']:
            measured=junit(read(row['name']+'.xml'))
            assert measured['cases']==row['cases']>0 and measured['xml_sha256']==row['junit_sha256']
            assert row['exit_code']==0 and all(row[k]==measured[k]==0 for k in ('failure','error','skipped'))
            groups.append({'name':row['name'],**measured})
        receipt['exact_image_session']=stress;receipt['stress_groups']=groups;receipt['stress_cases']=sum(g['cases'] for g in groups)
        receipt['artifact_members']=[{'name':m.filename,'bytes':m.file_size} for m in members]
        for name in ('porota-frozen-candidate.json','porota-deploy-bundle-v2-manifest.json','porota-governed-tests.json',
                     'porota-governed-tests.xml','stress.json','full-catalog.json','native-bound.xml',
                     'cadence-fresh.json','cadence-legacy.json'):
            (out/name).write_bytes(read(name))
    with tarfile.open(out/'porota-deploy-bundle-v2.tgz','r:gz') as bundle:
        names={m.name for m in bundle.getmembers()};paths={r['path'] for r in manifest['files']}
        assert names==paths|{'POROTA_DEPLOY_BUNDLE_MANIFEST.json'} and manifest['file_count']==len(paths)==len(manifest['files'])
        embedded=json.load(bundle.extractfile('POROTA_DEPLOY_BUNDLE_MANIFEST.json'))
        assert embedded=={k:v for k,v in manifest.items() if k!='bundle_sha256'}
        for row in manifest['files']:
            item=bundle.getmember(row['path']);assert item.isfile() and item.size==row['bytes']
            assert sha_stream(bundle.extractfile(item))==row['sha256']
            assert sha(args.repo/row['path'])==row['sha256'],('CHECKOUT_MEMBER_MISMATCH',row['path'])
    receipt['bundle_file_count']=manifest['file_count'];receipt['bundle_sha256']=manifest['bundle_sha256'];receipt['all_bundle_members_verified']=True
    with tarfile.open(out/'porota-predeploy-image.tar.gz','r:gz') as image:
        manifest_image=json.load(image.extractfile('manifest.json'));assert len(manifest_image)==1
        entry=manifest_image[0];config_raw=image.extractfile(entry['Config']).read();config=json.loads(config_raw)
        assert 'sha256:'+hashlib.sha256(config_raw).hexdigest()==frozen['image_id'],'OCI_CONFIG_ID_MISMATCH'
        environ=dict(v.split('=',1) for v in config['config']['Env'] if '=' in v)
        assert environ['POROTA_BUILD_SHA']==args.sha and environ['POROTA_CANDIDATE_TREE_SHA']==args.tree
        assert environ.get('PYTHON_VERSION') == '3.11.16', 'CONTROLLED_PYTHON_ABI_CHANGED'
        layers=entry['Layers'];diff_ids=config['rootfs']['diff_ids'];assert len(layers)==len(diff_ids)
        layer_receipts=[]
        for name,expected in zip(layers,diff_ids):
            stream=image.extractfile(name);magic=stream.read(2);stream.seek(0)
            measured=sha_stream(gzip.GzipFile(fileobj=stream) if magic==b'\x1f\x8b' else stream)
            assert 'sha256:'+measured==expected,('OCI_LAYER_DIGEST_MISMATCH',name)
            layer_receipts.append({'name':name,'diff_id':expected})
        (out/'oci-config.raw.json').write_bytes(config_raw)
        # Recover the actual final extension by applying the immutable layer order.
        # Only the named regular file is read; no tar extraction or execution.
        native_raw=None; native_member='app/rc6_shadow_runtime/_rc6_json_bound.so'
        for layer_name in layers:
            with tarfile.open(fileobj=image.extractfile(layer_name),mode='r:*') as layer:
                for item in layer:
                    name=str(PurePosixPath(item.name.removeprefix('./')))
                    if name in {'app/rc6_shadow_runtime/.wh._rc6_json_bound.so','app/rc6_shadow_runtime/.wh..wh..opq'}: native_raw=None
                    if name==native_member:
                        assert item.isfile() and item.size<=1024**2, 'NATIVE_BINARY_LAYER_TYPE_OR_SIZE'
                        native_raw=layer.extractfile(item).read()
        assert native_raw is not None, 'NATIVE_BINARY_MISSING_FROM_IMAGE'
        binary=out/'_rc6_json_bound.so';binary.write_bytes(native_raw)
        needed=subprocess.check_output(['readelf','-d',str(binary)],text=True)
        versions=subprocess.check_output(['readelf','--version-info',str(binary)],text=True)
        symbols=subprocess.check_output(['readelf','--dyn-syms','--wide',str(binary)],text=True)
        undefined=[v.split()[7] for v in symbols.splitlines() if len(v.split())>=8 and v.split()[6]=='UND']
        assert 'NEEDED' not in needed and 'GLIBC_' not in versions
        assert undefined and all(v.startswith(('Py','_Py')) for v in undefined)
        receipt['native_binary']={'sha256':sha(binary),'bytes':len(native_raw),'needed':[],'glibc_versions':[],'undefined':undefined,'layer_member':native_member}
        receipt['oci']={'image_id':frozen['image_id'],'config_sha256':hashlib.sha256(config_raw).hexdigest(),
                        'source_sha_observed':environ['POROTA_BUILD_SHA'],'source_tree_observed':environ['POROTA_CANDIDATE_TREE_SHA'],
                        'architecture':config['architecture'],'os':config['os'],'layers':layer_receipts}
    baseline=json.loads(args.abi_reference.read_text())
    assert baseline['status']=='GREEN' and baseline['candidate_sha']=='202e49c750ab0a69b5ba6790fcb14cc0c0d9039f'
    baseline_config_raw=(args.abi_reference.parent/'oci-config.raw.json').read_bytes()
    assert hashlib.sha256(baseline_config_raw).hexdigest()==baseline['oci']['config_sha256'], 'BASELINE_CONFIG_DIGEST_MISMATCH'
    baseline_config=json.loads(baseline_config_raw)
    def base_layers(config_value):
        count=0
        for row in config_value['history']:
            if 'POROTA_BUILD_SHA' in row.get('created_by',''):
                return count
            if not row.get('empty_layer'):count+=1
        raise AssertionError('PROJECT_BASE_HISTORY_BOUNDARY_MISSING')
    base_count=base_layers(config)
    assert base_count==base_layers(baseline_config)==4, 'CONTROLLED_BASE_HISTORY_BOUNDARY_CHANGED'
    observed_prefix=[v['diff_id'] for v in receipt['oci']['layers'][:base_count]]
    baseline_prefix=[v['diff_id'] for v in baseline['oci']['layers'][:base_count]]
    assert observed_prefix==baseline_prefix and len(observed_prefix)==base_count, 'CONTROLLED_BASE_LAYER_PREFIX_CHANGED'
    assert (config['architecture'],config['os'])==(baseline_config['architecture'],baseline_config['os'])
    codec_control=json.loads(args.codec_control.read_text())
    assert codec_control['proof_kind']=='NATIVE_ABI_AND_SAFETY_ONLY_NOT_RELATIVE_CPU_ADMISSION'
    assert codec_control['native_abi_guards']=='GREEN' and codec_control['focal_cases']==425
    assert codec_control['release_or_native_acceptance'] is False
    assert codec_control['admission']=='FRESH_GREEN_LEGACY_RELATIVE_CPU_RED'
    assert codec_control['comparison']['status']=='RED_EXPERIMENT'
    assert all(codec_control[k]==0 for k in ('failure','error','skipped'))
    assert codec_control['source']=='5ed59faff3ace236098a05ecd777f07d444eddd1'
    assert codec_control['tree']=='ba7bd625ac262eebe38fe039a28647a596bbcde5'
    assert codec_control['artifact']==12139470508 and codec_control['zip_sha256']=='f8d1a1affa1fd4ad1dcc6aea7ad13038d2cd48ae858b11a8da3a4dfa10932bef'
    assert codec_control['c_source_sha256']=='4710a658bbdeae55dc71437c57be6a9766a892d759b5815a4c2d4029a831440f'
    assert codec_control['five_sandboxes_exit0_oom_false'] is True
    assert receipt['native_binary']['sha256']==codec_control['native_sha256'], 'FROZEN_COMPONENT_VS_RELEASE_NATIVE_BINARY_MISMATCH'
    receipt['exact_codec_control']={'kind':'ABI_ONLY_RELATIVE_CPU_ADMISSION_REMAINS_RED',
        'sha256':sha(args.codec_control),'reference_source':codec_control['source'],
        'native_sha256':codec_control['native_sha256'],'focal_cases':codec_control['focal_cases'],
        'current_candidate_admission':'OWN_EXACT_IMAGE_NATIVE_XML_AND_PHYSICAL_24_CUTS'}
    source_binding={}
    original_dockerfile=subprocess.check_output(['git','cat-file','blob',baseline['candidate_sha']+':Dockerfile'],cwd=args.repo)
    actual_dockerfile=(args.repo/'Dockerfile').read_bytes()
    from_lines=lambda raw:[v for v in raw.decode().splitlines() if v.startswith('FROM ')]
    assert from_lines(original_dockerfile)==from_lines(actual_dockerfile), 'PINNED_BUILD_AND_RUNTIME_BASES_CHANGED'
    original_lock=subprocess.check_output(['git','cat-file','blob',baseline['candidate_sha']+':requirements.lock.txt'],cwd=args.repo)
    assert (args.repo/'requirements.lock.txt').read_bytes()==original_lock, 'LOCK_CHANGED'
    for path in ('Dockerfile','requirements.lock.txt','rc6_shadow_runtime/_rc6_json_bound.c'):
        source_binding[path]=sha(args.repo/path)
    reference=args.codec_reference.read_bytes(); actual=(args.repo/'rc6_shadow_runtime/_rc6_json_bound.c').read_bytes()
    assert hashlib.sha256(reference).hexdigest()=='ccffd721c5b2f642d0447fd08b83b78ed2ee02f1a3613bb8c617c130f651ebf5', 'CODEC_REFERENCE_SOURCE_CHANGED'
    assert source_binding['rc6_shadow_runtime/_rc6_json_bound.c']=='4710a658bbdeae55dc71437c57be6a9766a892d759b5815a4c2d4029a831440f', 'FROZEN_A3_CODEC_CHANGED'
    marker=b'/* Durable audit input codec;'
    assert actual.split(marker)[0]==reference.split(marker)[0], 'SIZING_PREFIX_CHANGED'
    decoder=lambda value:value.split(b'typedef struct { const unsigned char *at,*end;')[1].split(b'/* Deterministic regression observable.')[0].split(b'static PyMethodDef methods')[0]
    assert decoder(actual)==decoder(reference), 'DECODER_BODY_CHANGED'
    receipt['controlled_abi_binding']={'status':'GREEN_SAME_PINNED_BASE_NEW_CODEC_CERTIFIED',
        'reference_image':baseline['oci']['image_id'],'reference_source':baseline['candidate_sha'],
        'python_version_observed':'3.11.16','base_layer_count':base_count,'base_boundary':'FIRST_POROTA_BUILD_SHA_HISTORY_ENTRY',
        'reference_config_sha256':baseline['oci']['config_sha256'],'base_layer_prefix':observed_prefix,
        'source_input_sha256':source_binding,'native_backend_validated_by_actual_xml':True,
        'sizing_prefix_unchanged':True,'decoder_unchanged':True,'new_codec_requires_own_native_certificate':True}
    receipt['status']='GREEN';(out/'byte-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':'GREEN','candidate_sha':args.sha,'zip_sha256':digest,'root_cases':root_xml['cases'],
                      'stress_cases':receipt['stress_cases'],'bundle_files':manifest['file_count'],'image_id':frozen['image_id']}))
if __name__=='__main__':main()
