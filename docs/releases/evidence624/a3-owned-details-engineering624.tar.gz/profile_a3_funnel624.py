import cProfile,hashlib,importlib.util,json,pstats,shutil,sys,tempfile,time
from pathlib import Path
root=Path('/workspace/scratch/88594b90c2a3');sys.path.insert(0,str(root/'fix10-624'))
binary=root/'a3-singlepass-native312624.so';spec=importlib.util.spec_from_file_location('rc6_shadow_runtime._rc6_json_bound',binary);n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n);sys.modules[spec.name]=n
from rc6_shadow_runtime import persistence as p
from rc6_shadow_runtime.checkpoint_parts import CheckpointParts
source=root/'a3-prefix-private-export624/fresh-candidate/shadow/checkpoint.json.gz';before=hashlib.sha256(source.read_bytes()).hexdigest();out=root/'a3-funnel-phase-profile624';out.mkdir(exist_ok=False)
with tempfile.TemporaryDirectory(prefix='a3-funnel-profile-',dir='/tmp') as folder:
 shutil.copyfile(source,Path(folder)/source.name)
 with p.EvidenceFiles(folder) as files:
  with CheckpointParts(files,p.checkpoint_ascii_chunks) as parts:funnel=parts.load('funnel')
 prof=cProfile.Profile();w=time.monotonic();c=time.process_time();prof.enable();result=p.checkpoint_metrics(funnel);prof.disable()
 result.update(local_cpu=time.process_time()-c,local_wall=time.monotonic()-w,scope='ONE_FROZEN_ACTUAL_FUNNEL_PHASE_PROFILE_NOT_ABI_OR_CAPACITY',source_checkpoint_sha256=before,source_unchanged=before==hashlib.sha256(source.read_bytes()).hexdigest(),shape={k:len(v) for k,v in funnel.items() if isinstance(v,(dict,list))})
 assert result['sha256']==funnel['checkpoint_sha256']
 prof.dump_stats(out/'metrics.prof')
 with (out/'metrics.txt').open('w') as target:pstats.Stats(prof,stream=target).strip_dirs().sort_stats('cumtime').print_stats(35)
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((out/'metrics.txt').read_text())
