import hashlib,json,xml.etree.ElementTree as E
from pathlib import Path
root=Path('/workspace/scratch/88594b90c2a3');r=root/'a3-singlepass-abi624';e=r/'_temp/ab624-evidence';build=r/'_temp/ab624-build'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'a3-singlepass-abi624.zip')=='2e1f6c1f4d232153056e0966c16679211fa46a2d4864babea1d1a2a4f6501ca6'
cases=list(E.parse(e/'focal.xml').getroot().iter('testcase'));assert len(cases)==388
assert not [c for c in cases if any(c.find(x)is not None for x in ['failure','error','skipped'])]
containers=[json.loads(p.read_text())[0] for p in e.glob('*-container.json')];assert len(containers)==5 and len({v['Image'] for v in containers})==1
for v in containers:
 h=v['HostConfig'];s=v['State'];assert h['Memory']==h['MemorySwap']==512*1024**2 and h['NanoCpus']==750000000 and h['PidsLimit']==128
 assert h['NetworkMode']=='none' and h['ReadonlyRootfs'] and set(h['CapDrop'])=={'ALL'} and v['Config']['User']=='1000:1000'
 assert s['ExitCode']==0 and not s['OOMKilled']
assert 'NEEDED' not in (build/'needed.txt').read_text() and 'GLIBC_' not in (build/'versions.txt').read_text()
symbols=[v.split()[7] for v in (build/'symbols.txt').read_text().splitlines() if len(v.split())>=8 and v.split()[6]=='UND'];assert all(v.startswith(('Py','_Py')) for v in symbols)
assert sha(build/'_rc6_json_bound.so')=='e75d99b260ee8af6af4147e6f0eb7c79d144ca1d9c9b312ac6499875cbe34c07'
manifest=json.loads((r/'Porota-trading/Porota-trading/candidate624/ab624-source-manifest.json').read_text());source={x['path']:x['sha256'] for x in manifest};assert source['rc6_shadow_runtime/_rc6_json_bound.c']=='4710a658bbdeae55dc71437c57be6a9766a892d759b5815a4c2d4029a831440f'
for p,h in source.items():
 if p.endswith('.so'):assert h==sha(build/'_rc6_json_bound.so')
 else:assert h==sha(root/'fix10-624'/p),p
compare=json.loads((e/'comparison.json').read_text());assert compare['status']=='RED_EXPERIMENT'
result={'schema':'rc6.a3-exact-abi-red-independent-inspection.v1','run':39131137482,'job':117686369644,'artifact':12138620150,'zip_bytes':164331,'zip_sha256':sha(root/'a3-singlepass-abi624.zip'),'source':'889c7b4dd50b0ac7dcf18acef109ac7aab126f5a','tree':'d3688924118fc6e4522fbdc870d97e0792884524','focal_cases':388,'failure':0,'error':0,'skipped':0,'five_sandboxes_exit0_oom_false':True,'native_sha256':sha(build/'_rc6_json_bound.so'),'undefined_symbols':symbols,'comparison':compare,'native_abi_guards':'GREEN','admission':'RED_HOT_CPU_BOTH_MODES','release_or_native_acceptance':False,'raw_log_sha256':sha(root/'a3-singlepass-abi624-raw.log'),'profiles':['a3-funnel-phase-profile624/receipt.json','a3-operational-funnel-profile624/receipt.json']}
(root/'a3-singlepass-abi-red624.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['artifact','focal_cases','native_sha256','native_abi_guards','admission','raw_log_sha256']}))
