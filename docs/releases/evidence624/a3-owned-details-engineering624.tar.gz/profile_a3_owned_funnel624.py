import cProfile,gzip,hashlib,importlib.util,json,pstats,shutil,sys,tempfile,time
from datetime import timedelta
from pathlib import Path
root=Path('/workspace/scratch/88594b90c2a3');sys.path.insert(0,str(root/'fix11-624'))
spec=importlib.util.spec_from_file_location('rc6_shadow_runtime._rc6_json_bound',root/'a3-singlepass-native312624.so');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n);sys.modules[spec.name]=n
from rc6_shadow_runtime import funnel,worker,cold_audit,persistence as p
from tests.test_rc6_shadow_runtime_wiring import PRE
export=root/'a3-operational-funnel-owned-profile624';assert not export.exists()
manifest={str(x.relative_to(root/'fix11-624')):hashlib.sha256(x.read_bytes()).hexdigest() for x in (root/'fix11-624').rglob('*.py')}
original=funnel.evaluate_runtime_funnel;prof=cProfile.Profile();data={'scope':'ONE_FROZEN_ACTUAL_FRESH_FUNNEL_PROFILE_NOT_PERFORMANCE_ADMISSION','source':'LOCAL_NEXT_BATCH_AFTER_889c7b4_NOT_FROZEN','calls':0}
def measured(*args,**kwargs):
 data['calls']+=1;wall=time.monotonic();cpu=time.process_time();prof.enable()
 try:return original(*args,**kwargs)
 finally:prof.disable();data.update(profile_cpu=time.process_time()-cpu,profile_wall=time.monotonic()-wall)
funnel.evaluate_runtime_funnel=measured
with tempfile.TemporaryDirectory(prefix='a3-funnel-onecut-',dir='/tmp') as folder:
 temp=Path(folder);runtime=worker.ShadowRuntime(root/'shared624.db',evidence_root=temp/'shadow',source_roots=[],spool_audit=True,defer_audit=True)
 report=runtime.tick(PRE);data['checkpoint_sha256']=report['operational_funnel']['checkpoint_sha256'];del report
 with runtime.files as files:
  done=cold_audit.drain(files);assert done['state']=='COMPLETE'
 data['full_audit']=done['computed_report'];data['calls_expected1']=data['calls']==1;assert data['calls']==1
 assert manifest=={str(x.relative_to(root/'fix11-624')):hashlib.sha256(x.read_bytes()).hexdigest() for x in (root/'fix11-624').rglob('*.py')}
 export.mkdir();prof.dump_stats(export/'funnel.prof')
 with (export/'funnel.txt').open('w') as out:pstats.Stats(prof,stream=out).strip_dirs().sort_stats('cumtime').print_stats(45)
 (export/'receipt.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data));print((export/'funnel.txt').read_text())
