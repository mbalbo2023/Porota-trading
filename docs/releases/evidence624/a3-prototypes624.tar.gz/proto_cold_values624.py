"""One frozen-value codec feasibility experiment, never a runtime certificate."""
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import pickle
import pickletools
import resource
import struct
import sys
import time

sys.path.insert(0, str(Path('fix6-624').resolve()))
from rc6_shadow_runtime.persistence import _small_json_tree, canonical_ascii_chunks
from rc6_shadow_runtime import _rc6_json_bound

SOURCE = Path('paired-private-views624-legacy-candidate/shadow/computed-0b2d9c329bd3564017e1ceb87e6d2b244c3d008838733bee0ab92e1f8f8497cd.json.gz')
RAW_SHA = '0b2d9c329bd3564017e1ceb87e6d2b244c3d008838733bee0ab92e1f8f8497cd'
RAW_BYTES = 265449928
HEADER = struct.Struct('!cI')
ENCODER = json.JSONEncoder(ensure_ascii=True, sort_keys=True, separators=(',', ':'),
                           allow_nan=False, default=str)
ALLOWED = frozenset(('PROTO', 'FRAME', 'STOP', 'MARK', 'NONE', 'NEWTRUE', 'NEWFALSE',
    'BININT', 'BININT1', 'BININT2', 'LONG1', 'LONG4', 'BINFLOAT', 'SHORT_BINUNICODE',
    'BINUNICODE', 'BINUNICODE8', 'EMPTY_LIST', 'EMPTY_DICT', 'EMPTY_TUPLE', 'TUPLE',
    'TUPLE1', 'TUPLE2', 'TUPLE3', 'APPEND', 'APPENDS', 'SETITEM', 'SETITEMS',
    'MEMOIZE', 'BINGET', 'LONG_BINGET'))


def sha_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        while block := source.read(65536):
            digest.update(block)
    return digest.hexdigest()


def pure(value):
    pending = [value]
    nodes = 0
    while pending:
        node = pending.pop()
        nodes += 1
        if nodes > 4096:
            return False
        kind = type(node)
        if kind is dict:
            if not all(type(key) is str for key in node):
                return False
            pending.extend(node.values())
        elif kind in (list, tuple):
            pending.extend(node)
        elif kind is float:
            if not math.isfinite(node):
                raise ValueError('NONFINITE_VALUE')
        elif kind is int:
            if node.bit_length() > 1024:
                ENCODER.encode(node)  # preserve the original integer limit
        elif kind not in (str, bool, type(None)):
            return False
    return True


class Restricted(pickle.Unpickler):
    def find_class(self, *_args):
        raise ValueError('GLOBALS_FORBIDDEN')

    def persistent_load(self, *_args):
        raise ValueError('PERSISTENT_IDS_FORBIDDEN')


def bounded_load(raw):
    if not 0 < len(raw) <= 131072:
        raise ValueError('PIECE_SIZE')
    memo = count = depth = 0
    end = None
    for opcode, argument, position in pickletools.genops(raw):
        count += 1
        if count > 32768 or opcode.name not in ALLOWED:
            raise ValueError('OPCODE_FORBIDDEN_OR_OVER_BUDGET')
        if opcode.name == 'PROTO' and argument != 5:
            raise ValueError('PROTOCOL')
        if opcode.name == 'FRAME' and argument > 131072:
            raise ValueError('FRAME_SIZE')
        if opcode.name == 'MEMOIZE':
            memo += 1
            if memo > 16384:
                raise ValueError('MEMO_SIZE')
        if opcode.name in {'BINGET', 'LONG_BINGET'} and not 0 <= argument < memo:
            raise ValueError('MEMO_INDEX')
        if opcode.name == 'MARK':
            depth += 1
            if depth > 512:
                raise ValueError('STACK_DEPTH')
        elif opcode.name in {'TUPLE', 'APPENDS', 'SETITEMS'}:
            depth -= 1
            if depth < 0:
                raise ValueError('STACK_MARK')
        if opcode.name == 'STOP':
            end = position + 1
    if end != len(raw):
        raise ValueError('TRAILING_OR_MISSING_STOP')
    value = Restricted(io.BytesIO(raw)).load()
    if not _small_json_tree(value) or not pure(value):
        raise ValueError('DECODED_VALUE_BOUND')
    return value


class Capture:
    def __init__(self, path):
        self.stream = path.open('xb')
        self.hasher = hashlib.sha256()
        self.records = self.maximum_payload = 0
        self.active = set()

    def record(self, kind, raw):
        if len(raw) > 131072:
            raise ValueError('CAPTURE_RECORD_BOUND')
        frame = HEADER.pack(kind, len(raw)) + hashlib.sha256(raw).digest() + raw
        self.stream.write(frame)
        self.hasher.update(frame)
        self.records += 1
        self.maximum_payload = max(self.maximum_payload, len(raw))

    def literal(self, text):
        raw = text.encode('ascii')
        for offset in range(0, len(raw), 65536):
            self.record(b'J', raw[offset:offset+65536])

    def value(self, value):
        if _small_json_tree(value) and pure(value):
            self.record(b'P', pickle.dumps(value, protocol=5))
            return
        if not isinstance(value, (dict, list, tuple)):
            self.literal(ENCODER.encode(value))
            return
        marker = id(value)
        if marker in self.active:
            raise ValueError('CYCLE')
        self.active.add(marker)
        try:
            if isinstance(value, dict):
                self.literal('{')
                for index, key in enumerate(sorted(value)):
                    if index:
                        self.literal(',')
                    key_object = ENCODER.encode({key: None})
                    self.literal(key_object[1:-len(':null}')]+':')
                    self.value(value[key])
                self.literal('}')
            else:
                self.literal('[')
                for offset in range(0, len(value), 16):
                    group = list(value[offset:offset+16])
                    if _small_json_tree(group) and pure(group):
                        if offset:
                            self.literal(',')
                        self.record(b'A', pickle.dumps(group, protocol=5))
                    else:
                        for index, item in enumerate(group, offset):
                            if index:
                                self.literal(',')
                            self.value(item)
                self.literal(']')
        finally:
            self.active.remove(marker)

    def finish(self):
        self.stream.flush()
        os.fsync(self.stream.fileno())
        self.stream.close()
        return self.hasher.hexdigest()


def expand(path, expected):
    if sha_file(path) != expected:
        raise ValueError('PACK_HASH')
    with path.open('rb') as source:
        while header := source.read(HEADER.size):
            if len(header) != HEADER.size:
                raise ValueError('TRUNCATED_HEADER')
            kind, size = HEADER.unpack(header)
            if not 0 < size <= 131072:
                raise ValueError('RECORD_LENGTH')
            digest, raw = source.read(32), source.read(size)
            if len(raw) != size or hashlib.sha256(raw).digest() != digest:
                raise ValueError('RECORD_HASH')
            if kind == b'J':
                if not raw.isascii():
                    raise ValueError('LITERAL_ASCII')
                yield raw
            elif kind in (b'P', b'A'):
                value = bounded_load(raw)
                encoded = ENCODER.encode(value).encode('ascii')
                yield encoded[1:-1] if kind == b'A' else encoded
            else:
                raise ValueError('RECORD_TYPE')


def sink(path, chunks):
    digest = hashlib.sha256()
    size = 0
    with path.open('xb') as stream:
        for block in chunks:
            stream.write(block)
            digest.update(block)
            size += len(block)
        stream.flush()
        os.fsync(stream.fileno())
    return {'bytes': size, 'sha256': digest.hexdigest()}


def main():
    for name in ('a3-codec624.pack', 'a3-codec624-baseline.raw', 'a3-codec624-cold.raw',
                 'a3-codec624-receipt.json'):
        assert not Path(name).exists(), 'NO_PRIOR_OUTPUT_REUSE'
    source_hash = sha_file(SOURCE)
    with gzip.open(SOURCE, 'rt') as source:
        value = json.load(source)
    result = {'schema': 'rc6.a3-codec624.feasibility.v1', 'scope': 'CODEC_ONLY_INPUT_LOADED_OUTSIDE_TIMING',
              'native_capacity_certificate': False, 'python': sys.version,
              'input_path': str(SOURCE), 'input_compressed_sha256': source_hash,
              'original_raw_sha256': RAW_SHA, 'original_raw_bytes': RAW_BYTES,
              'native_bound_sha256': sha_file(Path(_rc6_json_bound.__file__)),
              'limits': {'capture_cpu_ratio_max': .50, 'combined_cpu_ratio_max': 2.0,
                         'snapshot_raw_ratio_max': .50}}
    start, cpu = time.monotonic(), time.process_time()
    result['baseline'] = sink(Path('a3-codec624-baseline.raw'), canonical_ascii_chunks(value))
    result['baseline'].update(wall=time.monotonic()-start, cpu=time.process_time()-cpu)
    assert result['baseline']['sha256'] == RAW_SHA and result['baseline']['bytes'] == RAW_BYTES
    start, cpu = time.monotonic(), time.process_time()
    capture = Capture(Path('a3-codec624.pack'))
    capture.value(value)
    pack_sha = capture.finish()
    result['capture'] = {'wall': time.monotonic()-start, 'cpu': time.process_time()-cpu,
                         'bytes': Path('a3-codec624.pack').stat().st_size, 'sha256': pack_sha,
                         'records': capture.records, 'max_record_bytes': capture.maximum_payload}
    start, cpu = time.monotonic(), time.process_time()
    result['cold'] = sink(Path('a3-codec624-cold.raw'), expand(Path('a3-codec624.pack'), pack_sha))
    result['cold'].update(wall=time.monotonic()-start, cpu=time.process_time()-cpu)
    assert result['cold']['sha256'] == RAW_SHA and result['cold']['bytes'] == RAW_BYTES
    assert sha_file(SOURCE) == source_hash
    result['capture_cpu_ratio'] = result['capture']['cpu']/result['baseline']['cpu']
    result['combined_cpu_ratio'] = (result['capture']['cpu']+result['cold']['cpu'])/result['baseline']['cpu']
    result['snapshot_raw_ratio'] = result['capture']['bytes']/RAW_BYTES
    result['peak_rss_kib_includes_loaded_input'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    passed = (result['capture_cpu_ratio'] <= .5 and result['combined_cpu_ratio'] <= 2.0
              and result['snapshot_raw_ratio'] <= .5)
    result['status'] = 'GREEN_CODEC_FEASIBILITY_ONLY' if passed else 'RED_CODEC_HYPOTHESIS_INSUFFICIENT'
    Path('a3-codec624-receipt.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
