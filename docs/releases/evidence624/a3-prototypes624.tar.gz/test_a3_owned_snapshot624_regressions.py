"""Prototype failure regressions; original implementation is selectable before control."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HISTORICAL = os.environ.get('A3_HISTORICAL') == '1'
if HISTORICAL:
    spec = importlib.util.spec_from_file_location('_rc6_snapshot_codec624',
                Path('_rc6_snapshot_codec624-owned-first-executed.so').resolve())
    backend = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = backend
    spec.loader.exec_module(backend)
    spec = importlib.util.spec_from_file_location('owned_historical',
                Path('bench_owned_snapshot624-first-executed.py').resolve())
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
else:
    import bench_owned_snapshot624 as module

from rc6_shadow_runtime.persistence import FrozenJSONDict, _FrozenEmptyList
codec = module.codec


def reviewed_context():
    try:
        return codec.new_context(FrozenJSONDict, _FrozenEmptyList)
    except TypeError:
        # Only the historical before-control lacks the adapter arguments.
        assert HISTORICAL
        return codec.new_context()


def test_delimiter_framing_cannot_amplify_to_quota(tmp_path):
    capture = module.Capture(tmp_path/'data.pack')
    capture.range_offset = 0
    capture.range_hash = hashlib.sha256()
    capture.literal('[')
    for index in range(10000):
        if index:
            capture.literal(',')
        capture.literal('0')
    capture.literal(']')
    if hasattr(capture, 'flush_literals'):
        capture.flush_literals()
    capture.finish()
    assert (tmp_path/'data.pack').stat().st_size <= 20001+64


def test_readonly_values_supported_without_constructor_hint_authority():
    value = FrozenJSONDict({'status':'NO_VERIFICADO','value':None,'sources':[]})
    object.__setattr__(value,'_canonical_json','FORGED')
    captured = codec.encode({'field':value},reviewed_context())
    assert captured is not None
    actual = codec.decode(captured,codec.new_context())
    assert json.dumps(actual,sort_keys=True)==json.dumps({'field':value},sort_keys=True)


def test_changed_actual_value_is_not_replaced_by_old_hint():
    value = FrozenJSONDict({'value':None,'sources':[]})
    encoder,decoder = reviewed_context(),codec.new_context()
    first = codec.encode(value,encoder)
    assert first is not None
    assert codec.decode(first,decoder)['value'] is None
    dict.__setitem__(value,'value',7)
    second = codec.encode(value,encoder)
    assert second is not None
    assert codec.decode(second,decoder)['value']==7


def test_worker_missing_metadata_has_bounded_physical_capture(tmp_path):
    empty = FrozenJSONDict({'status':'NO_VERIFICADO','source':None,'source_at':None,
                           'received_at':None,'value':None,'valid':False,'sources':[]})
    value = [{'identity':str(index),'quote':empty,'metadata':empty} for index in range(5000)]
    canonical = json.dumps(value,sort_keys=True,separators=(',',':')).encode()
    capture = module.Capture(tmp_path/'data.pack')
    descriptor = capture.stage('family_values',value)
    capture.finish()
    reconstructed = b''.join(module.expand(tmp_path/'data.pack',descriptor))
    assert reconstructed==canonical
    assert (tmp_path/'data.pack').stat().st_size <= .5*len(canonical)


def test_corruption_cannot_become_cold_output(tmp_path):
    path=tmp_path/'data.pack'
    capture=module.Capture(path)
    descriptor=capture.stage('values',{'items':[1,2,3]})
    capture.finish()
    raw=bytearray(path.read_bytes());raw[-1]^=1;path.write_bytes(raw)
    import pytest
    with pytest.raises(ValueError,match='RANGE_HASH'):
        list(module.expand(path,descriptor))


def test_decoder_rejects_out_of_range_memo_and_poisoned_reuse():
    import pytest
    context=codec.new_context()
    with pytest.raises(ValueError):codec.decode(b'R\xff\xff\xff\xff',context)
    with pytest.raises(ValueError,match='CONTEXT_POISONED'):codec.decode(b'N',context)
