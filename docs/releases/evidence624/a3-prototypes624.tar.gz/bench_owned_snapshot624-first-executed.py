"""One paired serialization control on actual owned worker values, not runtime acceptance."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import sqlite3
import struct
import sys
import time

from proto_cold_values624_v2 import Capture as TypedCapture, codec, ENCODER, HEADER, sha_file
from rc6_shadow_runtime import worker as runtime
from rc6_shadow_runtime.audit_spool import AuditSpool, CanonicalJSONStream, SpoolValue
from rc6_shadow_runtime.persistence import EvidenceFiles
from tests.test_rc6_shadow_runtime_wiring import PRE

OUTPUT = Path('a3-owned-snapshot624').resolve()
DATABASE = Path('shared624.db').resolve()
REFERENCE = struct.Struct('!QQ32s')


class Capture(TypedCapture):
    def __init__(self, path):
        super().__init__(path)
        os.chmod(path, 0o600)
        self.range_hash = None
        self.references = {}
        self.ranges = []

    def record(self, kind, raw):
        if len(raw) > 131072:
            raise ValueError('RECORD_BOUND')
        frame = HEADER.pack(kind, len(raw))+hashlib.sha256(raw).digest()+raw
        if self.stream.tell()+len(frame)>512*1024**2:
            raise ValueError('PACK_QUOTA')
        self.stream.write(frame)
        self.hasher.update(frame)
        self.range_hash.update(frame)
        self.records += 1
        self.maximum_payload = max(self.maximum_payload, len(raw))

    def value(self, value):
        if isinstance(value, SpoolValue):
            key = (id(value.owner), value.offset, value.raw_bytes, value.sha256)
            reference = self.references[key]
            if reference['offset']+reference['length']>self.range_offset:
                raise ValueError('REFERENCE_NOT_BACKWARD')
            self.record(b'R', REFERENCE.pack(reference['offset'], reference['length'],
                                            bytes.fromhex(reference['sha256'])))
            return
        super().value(value)

    def stage(self, role, value):
        self.context = codec.new_context()
        self.active.clear()
        self.range_hash = hashlib.sha256()
        self.range_offset = self.stream.tell()
        self.value(value)
        self.stream.flush()
        os.fsync(self.stream.fileno())
        descriptor = {'role': role, 'offset': self.range_offset,
                      'length': self.stream.tell()-self.range_offset,
                      'sha256': self.range_hash.hexdigest()}
        self.ranges.append(descriptor)
        return descriptor


def expand(path, descriptor, depth=0):
    if depth>32:
        raise ValueError('REFERENCE_DEPTH')
    offset, length = descriptor['offset'], descriptor['length']
    if offset<0 or length<=0 or offset+length>path.stat().st_size:
        raise ValueError('RANGE_BOUND')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        stream.seek(offset)
        pending = length
        while pending:
            block = stream.read(min(pending, 65536))
            if not block:
                raise ValueError('RANGE_TRUNCATED')
            digest.update(block)
            pending -= len(block)
    if digest.hexdigest()!=descriptor['sha256']:
        raise ValueError('RANGE_HASH')
    context = codec.new_context()
    with path.open('rb') as stream:
        stream.seek(offset)
        end = offset+length
        while stream.tell()<end:
            header = stream.read(HEADER.size)
            if len(header)!=HEADER.size:
                raise ValueError('HEADER_TRUNCATED')
            kind, size = HEADER.unpack(header)
            if not 0<size<=131072 or stream.tell()+32+size>end:
                raise ValueError('FRAME_BOUND')
            expected, raw = stream.read(32), stream.read(size)
            if hashlib.sha256(raw).digest()!=expected:
                raise ValueError('FRAME_HASH')
            if kind==b'R':
                if size!=REFERENCE.size:
                    raise ValueError('REFERENCE_SHAPE')
                start, count, checksum = REFERENCE.unpack(raw)
                if start+count>offset:
                    raise ValueError('REFERENCE_NOT_BACKWARD')
                yield from expand(path, {'offset':start, 'length':count,
                                        'sha256':checksum.hex()}, depth+1)
            elif kind==b'J':
                if not raw.isascii():
                    raise ValueError('LITERAL_ASCII')
                yield raw
            elif kind in (b'P', b'A'):
                value = codec.decode(raw, context)
                if kind==b'A' and type(value) is not list:
                    raise ValueError('BATCH_TYPE')
                encoded = ENCODER.encode(value).encode('ascii')
                yield encoded[1:-1] if kind==b'A' else encoded
            else:
                raise ValueError('FRAME_TYPE')


class Value(CanonicalJSONStream):
    def __init__(self, path, descriptor):
        self.path, self.descriptor = path, descriptor

    def iter_bytes(self):
        yield from expand(self.path, self.descriptor)


def verified_computed(root, record):
    digest, size = hashlib.sha256(), 0
    with gzip.open(root/record['file'], 'rb') as stream:
        while block:=stream.read(65536):
            digest.update(block)
            size += len(block)
    assert size==record['raw_bytes'] and size>100*1024**2
    assert digest.hexdigest()==record['sha256']
    return {'bytes':size,'sha256':digest.hexdigest()}


def main():
    OUTPUT.mkdir(mode=0o700, exist_ok=False)
    source_root = Path(runtime.__file__).resolve().parents[1]
    assert source_root.name=='fix6-624'
    source_hashes = {str(p.relative_to(source_root)):sha_file(p)
                     for p in source_root.rglob('*.py')}
    before_sha, inode = sha_file(DATABASE), DATABASE.stat().st_ino
    result = {'schema':'rc6.a3-owned-values624.paired-topology.v1',
              'scope':'ACTUAL_PRODUCER_SERIALIZATION_INTERPOSITION_NOT_CAPACITY_CERTIFICATE',
              'native_host_acceptance':False,'local_cgroup_certificate':False,
              'database':str(DATABASE),'database_sha256':before_sha,'database_inode':inode,
              'source_clock':PRE.isoformat(),'python':sys.version,
              'prototype_c_sha256':sha_file(Path('proto_snapshot_codec624.c')),
              'prototype_binary_sha256':sha_file(Path(codec.__file__)),
              'limits':{'capture_cpu_ratio_max':.5,'combined_cpu_ratio_max':2.0,
                        'snapshot_raw_ratio_max':.5},'roles':[]}
    capture = Capture(OUTPUT/'input.pack')
    old_stage, old_write = AuditSpool.stage, EvidenceFiles.write_streamed_report
    original_connect = sqlite3.connect
    forbid_db = [False]

    def guarded_connect(*args, **kwargs):
        if forbid_db[0]:
            raise AssertionError('COLD_MUST_NOT_READ_LATER_DATABASE')
        return original_connect(*args, **kwargs)

    def paired_stage(owner, role, chunks):
        assert chunks.gi_code.co_name=='canonical_ascii_chunks'
        value = chunks.gi_frame.f_locals['payload']
        wall, cpu = time.monotonic(), time.process_time()
        descriptor = capture.stage(role, value)
        candidate = {'cpu':time.process_time()-cpu,'wall':time.monotonic()-wall,
                     'pack_bytes':descriptor['length']}
        wall, cpu = time.monotonic(), time.process_time()
        original = old_stage(owner, role, chunks)
        baseline = {'cpu':time.process_time()-cpu,'wall':time.monotonic()-wall,
                    'raw_bytes':original.raw_bytes,'sha256':original.sha256}
        capture.references[(id(owner),original.offset,original.raw_bytes,original.sha256)] = descriptor
        result['roles'].append({'role':role,'candidate_capture':candidate,'baseline':baseline,
                                'descriptor':descriptor})
        return original

    def paired_write(files, payload, **kwargs):
        assert not result.get('root'), 'ONE_ACTUAL_FULL_CUT_ONLY'
        wall, cpu = time.monotonic(), time.process_time()
        descriptor = capture.stage('full_computed_root', payload)
        pack_sha = capture.finish()
        candidate = {'cpu':time.process_time()-cpu,'wall':time.monotonic()-wall}
        assert pack_sha==sha_file(OUTPUT/'input.pack')
        wall, cpu = time.monotonic(), time.process_time()
        baseline = old_write(files, payload, **kwargs)
        measured = {'cpu':time.process_time()-cpu,'wall':time.monotonic()-wall,
                    'computed':baseline}
        candidate_files = EvidenceFiles(OUTPUT/'cold-output')
        wall, cpu = time.monotonic(), time.process_time()
        forbid_db[0] = True
        try:
            with candidate_files as owned:
                cold = old_write(owned, Value(OUTPUT/'input.pack',descriptor))
        finally:
            forbid_db[0] = False
        cold_measure = {'cpu':time.process_time()-cpu,'wall':time.monotonic()-wall,
                        'computed':cold}
        assert cold['sha256']==baseline['sha256'] and cold['raw_bytes']==baseline['raw_bytes']
        result['root']={'baseline':measured,'candidate_capture':candidate,
                        'cold':cold_measure,'descriptor':descriptor,
                        'pack_sha256':pack_sha,'pack_bytes':(OUTPUT/'input.pack').stat().st_size}
        return baseline

    AuditSpool.stage = paired_stage
    EvidenceFiles.write_streamed_report = paired_write
    sqlite3.connect = guarded_connect
    try:
        worker = runtime.ShadowRuntime(DATABASE,evidence_root=OUTPUT/'baseline',
                                       source_roots=[],spool_audit=True)
        returned = worker.tick(PRE)
        del returned
    finally:
        AuditSpool.stage = old_stage
        EvidenceFiles.write_streamed_report = old_write
        sqlite3.connect = original_connect
    root = result['root']
    result['baseline_verified'] = verified_computed(OUTPUT/'baseline',root['baseline']['computed'])
    result['cold_verified'] = verified_computed(OUTPUT/'cold-output',root['cold']['computed'])
    for row in result['roles']:
        digest, size = hashlib.sha256(), 0
        for chunk in expand(OUTPUT/'input.pack', row['descriptor']):
            digest.update(chunk); size += len(chunk)
        assert digest.hexdigest()==row['baseline']['sha256'] and size==row['baseline']['raw_bytes']
        row['independent_role_parity']={'bytes':size,'sha256':digest.hexdigest()}
    baseline_cpu = sum(r['baseline']['cpu'] for r in result['roles'])+root['baseline']['cpu']
    capture_cpu = sum(r['candidate_capture']['cpu'] for r in result['roles'])+root['candidate_capture']['cpu']
    result.update(baseline_serialization_cpu=baseline_cpu,candidate_capture_cpu=capture_cpu,
                  cold_cpu=root['cold']['cpu'],capture_cpu_ratio=capture_cpu/baseline_cpu,
                  combined_cpu_ratio=(capture_cpu+root['cold']['cpu'])/baseline_cpu,
                  snapshot_raw_ratio=root['pack_bytes']/root['baseline']['computed']['raw_bytes'],
                  peak_rss_kib_interposed_not_capacity=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    assert sha_file(DATABASE)==before_sha and DATABASE.stat().st_ino==inode
    assert source_hashes=={str(p.relative_to(source_root)):sha_file(p) for p in source_root.rglob('*.py')}
    passed = result['capture_cpu_ratio']<=.5 and result['combined_cpu_ratio']<=2.0 and result['snapshot_raw_ratio']<=.5
    result['status'] = 'GREEN_OWNED_SERIALIZATION_TOPOLOGY_ONLY' if passed else 'RED_TOPOLOGY_HYPOTHESIS_INSUFFICIENT'
    (OUTPUT/'source-manifest.json').write_text(json.dumps(source_hashes,sort_keys=True)+'\n')
    (OUTPUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    return 0 if passed else 2


if __name__=='__main__':
    raise SystemExit(main())
