"""One fixed-primitive native-codec experiment; no runtime/capacity claim."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import _rc6_snapshot_codec624 as codec
from proto_cold_values624 import (SOURCE, RAW_SHA, RAW_BYTES, HEADER, ENCODER,
                                  sha_file, sink, Capture as OriginalCapture)


class Capture(OriginalCapture):
    def __init__(self, path):
        super().__init__(path)
        self.context = codec.new_context()

    def value(self, value):
        captured = codec.encode(value, self.context)
        if captured is not None:
            self.record(b'P', captured)
            return
        if not isinstance(value, (dict, list, tuple)):
            self.literal(ENCODER.encode(value))
            return
        marker = id(value)
        if marker in self.active:
            raise ValueError('CYCLE')
        self.active.add(marker)
        try:
            if isinstance(value, dict):
                self.literal('{')
                for index, key in enumerate(sorted(value)):
                    if index:
                        self.literal(',')
                    encoded_key = ENCODER.encode({key: None})
                    self.literal(encoded_key[1:-len(':null}')]+':')
                    self.value(value[key])
                self.literal('}')
            else:
                self.literal('[')
                for offset in range(0, len(value), 16):
                    group = list(value[offset:offset+16])
                    captured = codec.encode(group, self.context)
                    if captured is not None:
                        if offset:
                            self.literal(',')
                        self.record(b'A', captured)
                    else:
                        for index, item in enumerate(group, offset):
                            if index:
                                self.literal(',')
                            self.value(item)
                self.literal(']')
        finally:
            self.active.remove(marker)


def expand(path, expected):
    if sha_file(path) != expected:
        raise ValueError('PACK_HASH')
    context = codec.new_context()
    with path.open('rb') as source:
        while header := source.read(HEADER.size):
            if len(header) != HEADER.size:
                raise ValueError('TRUNCATED_HEADER')
            kind, size = HEADER.unpack(header)
            if not 0 < size <= 131072:
                raise ValueError('RECORD_LENGTH')
            digest, raw = source.read(32), source.read(size)
            if len(raw) != size or hashlib.sha256(raw).digest() != digest:
                raise ValueError('RECORD_HASH')
            if kind == b'J':
                if not raw.isascii():
                    raise ValueError('LITERAL_ASCII')
                yield raw
            elif kind in (b'P', b'A'):
                value = codec.decode(raw, context)
                if kind == b'A' and type(value) is not list:
                    raise ValueError('BATCH_TYPE')
                encoded = ENCODER.encode(value).encode('ascii')
                yield encoded[1:-1] if kind == b'A' else encoded
            else:
                raise ValueError('RECORD_TYPE')


def main():
    for name in ('a3-codec2-624.pack', 'a3-codec2-624-baseline.raw',
                 'a3-codec2-624-cold.raw', 'a3-codec2-624-receipt.json'):
        assert not Path(name).exists(), 'NO_PRIOR_OUTPUT_REUSE'
    source_hash = sha_file(SOURCE)
    with gzip.open(SOURCE, 'rt') as source:
        value = json.load(source)
    from rc6_shadow_runtime.persistence import canonical_ascii_chunks
    result = {'schema': 'rc6.a3-codec624.fixed-native-feasibility.v1',
              'scope': 'CODEC_ONLY_INPUT_LOADED_OUTSIDE_TIMING',
              'native_capacity_certificate': False, 'python': sys.version,
              'input_path': str(SOURCE), 'input_compressed_sha256': source_hash,
              'original_raw_sha256': RAW_SHA, 'original_raw_bytes': RAW_BYTES,
              'prototype_c_source_sha256': sha_file(Path('proto_snapshot_codec624.c')),
              'prototype_binary_sha256': sha_file(Path(codec.__file__)),
              'existing_bound_source_sha256': sha_file(Path('fix9-624/rc6_shadow_runtime/_rc6_json_bound.c')),
              'memo_limits': {'strings': 4096, 'utf8_bytes': 262144},
              'limits': {'capture_cpu_ratio_max': .50, 'combined_cpu_ratio_max': 2.0,
                         'snapshot_raw_ratio_max': .50}}
    start, cpu = time.monotonic(), time.process_time()
    result['baseline'] = sink(Path('a3-codec2-624-baseline.raw'), canonical_ascii_chunks(value))
    result['baseline'].update(wall=time.monotonic()-start, cpu=time.process_time()-cpu)
    assert result['baseline']['sha256'] == RAW_SHA and result['baseline']['bytes'] == RAW_BYTES
    start, cpu = time.monotonic(), time.process_time()
    capture = Capture(Path('a3-codec2-624.pack'))
    capture.value(value)
    pack_sha = capture.finish()
    result['capture'] = {'wall': time.monotonic()-start, 'cpu': time.process_time()-cpu,
                         'bytes': Path('a3-codec2-624.pack').stat().st_size, 'sha256': pack_sha,
                         'records': capture.records, 'max_record_bytes': capture.maximum_payload}
    start, cpu = time.monotonic(), time.process_time()
    result['cold'] = sink(Path('a3-codec2-624-cold.raw'), expand(Path('a3-codec2-624.pack'), pack_sha))
    result['cold'].update(wall=time.monotonic()-start, cpu=time.process_time()-cpu)
    assert result['cold']['sha256'] == RAW_SHA and result['cold']['bytes'] == RAW_BYTES
    assert sha_file(SOURCE) == source_hash
    result['capture_cpu_ratio'] = result['capture']['cpu']/result['baseline']['cpu']
    result['combined_cpu_ratio'] = (result['capture']['cpu']+result['cold']['cpu'])/result['baseline']['cpu']
    result['snapshot_raw_ratio'] = result['capture']['bytes']/RAW_BYTES
    result['peak_rss_kib_includes_loaded_input'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    passed = (result['capture_cpu_ratio'] <= .5 and result['combined_cpu_ratio'] <= 2.0
              and result['snapshot_raw_ratio'] <= .5)
    result['status'] = 'GREEN_CODEC_FEASIBILITY_ONLY' if passed else 'RED_CODEC_HYPOTHESIS_INSUFFICIENT'
    Path('a3-codec2-624-receipt.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
