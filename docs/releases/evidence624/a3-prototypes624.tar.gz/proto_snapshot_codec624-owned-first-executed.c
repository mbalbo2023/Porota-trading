/* Scratch feasibility codec. Fixed JSON primitives only; no object VM. */
#define module original_bound_module
#define methods original_bound_methods
#define PyInit__rc6_json_bound ignored_original_bound_init
#include "fix9-624/rc6_shadow_runtime/_rc6_json_bound.c"
#undef module
#undef methods
#undef PyInit__rc6_json_bound
#include <math.h>
#include <stdint.h>
#include <string.h>

#define PIECE_MAX 131072
#define MEMO_MAX 4096
#define MEMO_BYTES 262144
typedef struct { char data[PIECE_MAX]; Py_ssize_t used; } Buffer;
typedef struct { PyObject *enc, *dec; Py_ssize_t enc_bytes, dec_bytes; int bad; Buffer *buffer; } Context;
static PyTypeObject Sentinel = {
    PyVarObject_HEAD_INIT(NULL, 0)
    .tp_name="_rc6_snapshot_codec624.UnconstructibleSentinel",
    .tp_basicsize=sizeof(PyObject), .tp_flags=Py_TPFLAGS_DEFAULT
};
static const char *context_name = "rc6.snapshot624.context.v1";

static void context_free(PyObject *capsule) {
    Context *ctx = PyCapsule_GetPointer(capsule, context_name);
    if (!ctx) { PyErr_Clear(); return; }
    Py_XDECREF(ctx->enc); Py_XDECREF(ctx->dec); PyMem_Free(ctx->buffer); PyMem_Free(ctx);
}
static PyObject *new_context(PyObject *self, PyObject *unused) {
    (void)self; (void)unused;
    Context *ctx = PyMem_Calloc(1, sizeof(Context));
    if (!ctx) return PyErr_NoMemory();
    ctx->enc = PyDict_New(); ctx->dec = PyList_New(0);
    ctx->buffer = PyMem_Malloc(sizeof(Buffer));
    if (!ctx->enc || !ctx->dec || !ctx->buffer) {
        Py_XDECREF(ctx->enc); Py_XDECREF(ctx->dec); PyMem_Free(ctx->buffer); PyMem_Free(ctx);
        if (!PyErr_Occurred()) PyErr_NoMemory();
        return NULL;
    }
    PyObject *result = PyCapsule_New(ctx, context_name, context_free);
    if (!result) { Py_DECREF(ctx->enc); Py_DECREF(ctx->dec); PyMem_Free(ctx->buffer); PyMem_Free(ctx); }
    return result;
}
static Context *context_get(PyObject *capsule) {
    Context *ctx = PyCapsule_GetPointer(capsule, context_name);
    if (ctx && ctx->bad) {
        PyErr_SetString(PyExc_ValueError, "SNAPSHOT_CONTEXT_POISONED"); return NULL;
    }
    return ctx;
}
static int small(PyObject *value) {
    PyObject *args = Py_BuildValue("OOnn", value, (PyObject *)&Sentinel,
                                   (Py_ssize_t)65536, (Py_ssize_t)4096);
    if (!args) return -1;
    PyObject *result = is_small(NULL, args); Py_DECREF(args);
    if (!result) return -1;
    int yes = result == Py_True; Py_DECREF(result); return yes;
}
static int pure(PyObject *value) {
    if (Py_EnterRecursiveCall(" in snapshot primitive validation")) return -1;
    int result = 1;
    if (PyDict_CheckExact(value)) {
        Py_ssize_t pos=0; PyObject *key, *child;
        while (PyDict_Next(value, &pos, &key, &child)) {
            if (!PyUnicode_CheckExact(key)) { result=0; break; }
            result=pure(child); if (result!=1) break;
        }
    } else if (PyList_CheckExact(value) || PyTuple_CheckExact(value)) {
        Py_ssize_t n=PySequence_Fast_GET_SIZE(value);
        for (Py_ssize_t i=0;i<n;i++) {
            result=pure(PySequence_Fast_GET_ITEM(value,i)); if (result!=1) break;
        }
    } else if (PyFloat_CheckExact(value)) {
        if (!isfinite(PyFloat_AS_DOUBLE(value))) {
            PyErr_SetString(PyExc_ValueError,"SNAPSHOT_NONFINITE"); result=-1;
        }
    } else if (!(PyUnicode_CheckExact(value) || PyLong_CheckExact(value) ||
                 value==Py_None || PyBool_Check(value))) result=0;
    Py_LeaveRecursiveCall(); return result;
}
static int append(Buffer *buffer, const void *data, Py_ssize_t n) {
    Py_ssize_t old=buffer->used;
    if (n<0 || n>PIECE_MAX-old) {
        PyErr_SetString(PyExc_ValueError,"SNAPSHOT_ENCODE_BOUND"); return -1;
    }
    if (n) memcpy(buffer->data+old,data,(size_t)n);
    buffer->used=old+n;
    return 0;
}
static int tag(Buffer *b, char t) { return append(b,&t,1); }
static int u32(Buffer *b, uint32_t n) {
    unsigned char raw[4]={(unsigned char)(n>>24),(unsigned char)(n>>16),
                          (unsigned char)(n>>8),(unsigned char)n};
    return append(b,raw,4);
}
static int encode_value(Context *ctx, Buffer *buffer, PyObject *value) {
    if (Py_EnterRecursiveCall(" in snapshot primitive capture")) return -1;
    int result=-1;
    if (value==Py_None) result=tag(buffer,'N');
    else if (value==Py_True) result=tag(buffer,'T');
    else if (value==Py_False) result=tag(buffer,'F');
    else if (PyUnicode_CheckExact(value)) {
        PyObject *index=PyDict_GetItemWithError(ctx->enc,value);
        if (index) {
            Py_ssize_t n=PyLong_AsSsize_t(index);
            if (n>=0 && tag(buffer,'R')==0) result=u32(buffer,(uint32_t)n);
        } else if (!PyErr_Occurred()) {
            PyObject *raw=PyUnicode_AsEncodedString(value,"utf-8","surrogatepass");
            if (raw) {
                Py_ssize_t n=PyBytes_GET_SIZE(raw), count=PyDict_Size(ctx->enc);
                int memo=count<MEMO_MAX && n<=MEMO_BYTES-ctx->enc_bytes;
                if (tag(buffer,memo?'S':'U')==0 && u32(buffer,(uint32_t)n)==0 &&
                    append(buffer,PyBytes_AS_STRING(raw),n)==0) {
                    result=0;
                    if (memo) {
                        PyObject *number=PyLong_FromSsize_t(count);
                        if (!number || PyDict_SetItem(ctx->enc,value,number)<0) result=-1;
                        else ctx->enc_bytes+=n;
                        Py_XDECREF(number);
                    }
                }
                Py_DECREF(raw);
            }
        }
    } else if (PyLong_CheckExact(value)) {
        PyObject *text=PyObject_Str(value);
        PyObject *raw=text?PyUnicode_AsASCIIString(text):NULL; Py_XDECREF(text);
        if (raw) {
            Py_ssize_t n=PyBytes_GET_SIZE(raw);
            if (tag(buffer,'I')==0 && u32(buffer,(uint32_t)n)==0)
                result=append(buffer,PyBytes_AS_STRING(raw),n);
            Py_DECREF(raw);
        }
    } else if (PyFloat_CheckExact(value)) {
        double number=PyFloat_AS_DOUBLE(value); uint64_t bits;
        unsigned char raw[8]; memcpy(&bits,&number,8);
        for (int i=0;i<8;i++) raw[i]=(unsigned char)(bits>>(56-8*i));
        if (tag(buffer,'D')==0) result=append(buffer,raw,8);
    } else if (PyDict_CheckExact(value)) {
        Py_ssize_t n=PyDict_Size(value),pos=0; PyObject *key,*child;
        if (tag(buffer,'O')==0 && u32(buffer,(uint32_t)n)==0) {
            result=0;
            while (PyDict_Next(value,&pos,&key,&child)) {
                if (encode_value(ctx,buffer,key)<0 || encode_value(ctx,buffer,child)<0) {
                    result=-1; break;
                }
            }
        }
    } else if (PyList_CheckExact(value) || PyTuple_CheckExact(value)) {
        Py_ssize_t n=PySequence_Fast_GET_SIZE(value);
        if (tag(buffer,'L')==0 && u32(buffer,(uint32_t)n)==0) {
            result=0;
            for (Py_ssize_t i=0;i<n;i++) {
                if (encode_value(ctx,buffer,PySequence_Fast_GET_ITEM(value,i))<0) {
                    result=-1; break;
                }
            }
        }
    } else PyErr_SetString(PyExc_ValueError,"SNAPSHOT_UNSUPPORTED_AFTER_PREFLIGHT");
    Py_LeaveRecursiveCall(); return result;
}
static PyObject *capture(PyObject *self, PyObject *args) {
    (void)self; PyObject *value,*capsule;
    if (!PyArg_ParseTuple(args,"OO:encode",&value,&capsule)) return NULL;
    Context *ctx=context_get(capsule); if (!ctx) return NULL;
    int fit=small(value); if (fit<0) return NULL;
    if (!fit) Py_RETURN_NONE;
    fit=pure(value); if (fit<0) {ctx->bad=1; return NULL;}
    if (!fit) Py_RETURN_NONE;
    Buffer *buffer=ctx->buffer;
    buffer->used=0;
    PyObject *result=NULL;
    if (encode_value(ctx,buffer,value)==0)
        result=PyBytes_FromStringAndSize(buffer->data,buffer->used);
    if (!result) ctx->bad=1;
    return result;
}
typedef struct { const unsigned char *at,*end; Context *ctx; Py_ssize_t nodes; } Reader;
static int error(const char *message) { PyErr_SetString(PyExc_ValueError,message); return -1; }
static int need(Reader *r, Py_ssize_t n) {
    if (n<0 || n>r->end-r->at) return error("SNAPSHOT_TRUNCATED");
    return 0;
}
static int read32(Reader *r, uint32_t *n) {
    if (need(r,4)<0) return -1;
    *n=((uint32_t)r->at[0]<<24)|((uint32_t)r->at[1]<<16)|
       ((uint32_t)r->at[2]<<8)|r->at[3]; r->at+=4; return 0;
}
static PyObject *decode_value(Reader *r) {
    if (--r->nodes<0) {error("SNAPSHOT_NODE_BUDGET"); return NULL;}
    if (need(r,1)<0 || Py_EnterRecursiveCall(" in snapshot primitive decode")) return NULL;
    char t=(char)*r->at++; PyObject *result=NULL; uint32_t n;
    if (t=='N') result=Py_NewRef(Py_None);
    else if (t=='T') result=Py_NewRef(Py_True);
    else if (t=='F') result=Py_NewRef(Py_False);
    else if (t=='R') {
        if (read32(r,&n)==0) {
            if (n>=(uint32_t)PyList_GET_SIZE(r->ctx->dec)) error("SNAPSHOT_MEMO_INDEX");
            else result=Py_NewRef(PyList_GET_ITEM(r->ctx->dec,n));
        }
    } else if (t=='S' || t=='U') {
        if (read32(r,&n)==0 && n<=PIECE_MAX && need(r,(Py_ssize_t)n)==0) {
            if (t=='S' && (PyList_GET_SIZE(r->ctx->dec)>=MEMO_MAX ||
                          n>(uint32_t)(MEMO_BYTES-r->ctx->dec_bytes))) error("SNAPSHOT_MEMO_BUDGET");
            else {
                result=PyUnicode_DecodeUTF8((const char*)r->at,n,"surrogatepass"); r->at+=n;
                if (result && t=='S') {
                    if (PyList_Append(r->ctx->dec,result)<0) Py_CLEAR(result);
                    else r->ctx->dec_bytes+=n;
                }
            }
        } else if (!PyErr_Occurred()) error("SNAPSHOT_STRING_BOUND");
    } else if (t=='I') {
        if (read32(r,&n)==0 && n>0 && n<=65536 && need(r,n)==0) {
            uint32_t first=(r->at[0]=='-'); int valid=first<n;
            if (valid && r->at[first]=='0' && (n-first>1 || first)) valid=0;
            for (uint32_t i=first;i<n && valid;i++)
                if (r->at[i]<'0' || r->at[i]>'9') valid=0;
            if (!valid) error("SNAPSHOT_INTEGER_SYNTAX");
            else {
                PyObject *text=PyBytes_FromStringAndSize((const char*)r->at,n);
                if (text) { result=PyLong_FromString(PyBytes_AS_STRING(text),NULL,10); Py_DECREF(text); }
                r->at+=n;
            }
        } else if (!PyErr_Occurred()) error("SNAPSHOT_INTEGER_BOUND");
    } else if (t=='D') {
        if (need(r,8)==0) {
            uint64_t bits=0; double number;
            for (int i=0;i<8;i++) bits=(bits<<8)|r->at[i];
            r->at+=8;
            memcpy(&number,&bits,8);
            if (!isfinite(number)) error("SNAPSHOT_NONFINITE");
            else result=PyFloat_FromDouble(number);
        }
    } else if (t=='L' || t=='O') {
        if (read32(r,&n)==0 && n<=256 && n<=(uint32_t)r->nodes/(t=='O'?2:1)) {
            result=(t=='L')?PyList_New(n):PyDict_New();
            if (result) for (uint32_t i=0;i<n;i++) {
                PyObject *key=NULL,*value=NULL;
                if (t=='O') {
                    key=decode_value(r);
                    if (!key) {Py_CLEAR(result); break;}
                    if (!PyUnicode_CheckExact(key)) {
                        Py_DECREF(key); error("SNAPSHOT_KEY_TYPE"); Py_CLEAR(result); break;
                    }
                    int present=PyDict_Contains(result,key);
                    if (present) {
                        Py_DECREF(key); if (present>0) error("SNAPSHOT_DUPLICATE_KEY");
                        Py_CLEAR(result); break;
                    }
                }
                value=decode_value(r);
                if (!value) {Py_XDECREF(key); Py_CLEAR(result); break;}
                if (t=='L') PyList_SET_ITEM(result,i,value);
                else {
                    int inserted=PyDict_SetItem(result,key,value);
                    Py_DECREF(key); Py_DECREF(value);
                    if (inserted<0) {Py_CLEAR(result); break;}
                }
            }
        } else if (!PyErr_Occurred()) error("SNAPSHOT_CONTAINER_BOUND");
    } else error("SNAPSHOT_TAG");
    Py_LeaveRecursiveCall(); return result;
}
static PyObject *restore(PyObject *self, PyObject *args) {
    (void)self; PyObject *raw,*capsule;
    if (!PyArg_ParseTuple(args,"OO:decode",&raw,&capsule)) return NULL;
    Context *ctx=context_get(capsule); if (!ctx) return NULL;
    if (!PyBytes_CheckExact(raw) || PyBytes_GET_SIZE(raw)<1 || PyBytes_GET_SIZE(raw)>PIECE_MAX) {
        error("SNAPSHOT_PIECE_BOUND"); ctx->bad=1; return NULL;
    }
    Reader r={(const unsigned char*)PyBytes_AS_STRING(raw),
              (const unsigned char*)PyBytes_AS_STRING(raw)+PyBytes_GET_SIZE(raw),ctx,8192};
    PyObject *value=decode_value(&r);
    if (value && r.at!=r.end) {error("SNAPSHOT_TRAILING_BYTES"); Py_CLEAR(value);}
    if (value) {
        int fit=small(value);
        if (fit!=1) {if (fit==0) error("SNAPSHOT_DECODED_JSON_BOUND"); Py_CLEAR(value);}
    }
    if (!value) ctx->bad=1;
    return value;
}
static PyMethodDef snapshot_methods[]={
    {"new_context",new_context,METH_NOARGS,"New bounded cut-local string context."},
    {"encode",capture,METH_VARARGS,"Capture bounded actual JSON primitives, or None."},
    {"decode",restore,METH_VARARGS,"Decode fixed primitives with bounds before allocation."},
    {NULL,NULL,0,NULL}
};
static struct PyModuleDef snapshot_module={PyModuleDef_HEAD_INIT,"_rc6_snapshot_codec624",NULL,-1,snapshot_methods,NULL,NULL,NULL,NULL};
PyMODINIT_FUNC PyInit__rc6_snapshot_codec624(void) {
    _Static_assert(sizeof(double)==8,"IEEE64 double required");
    if (PyType_Ready(&Sentinel)<0) return NULL;
    return PyModule_Create(&snapshot_module);
}
